/**
 * HOME-3B motion. Transform and opacity only. Content stays visible if this
 * file never runs. prefers-reduced-motion and panel switches both disable.
 */
( function () {
	'use strict';

	var config = ( window.mahMotion && window.mahMotion.fx ) ? window.mahMotion.fx : {};
	var reduce = window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches;
	var fine = window.matchMedia( '(pointer: fine)' ).matches;
	var root = document.documentElement;
	var viewSupports = typeof CSS !== 'undefined' && CSS.supports && CSS.supports( 'animation-timeline: view()' );

	function level( key ) {
		if ( reduce ) {
			return 'off';
		}
		return config[ key ] || 'off';
	}

	function on( key ) {
		return 'off' !== level( key );
	}

	function subtle( key ) {
		return 'subtle' === level( key );
	}

	function onScroll( fn ) {
		var ticking = false;
		function run() {
			ticking = false;
			fn();
		}
		window.addEventListener( 'scroll', function () {
			if ( ! ticking ) {
				ticking = true;
				window.requestAnimationFrame( run );
			}
		}, { passive: true } );
		fn();
	}

	function isArabicDoc() {
		var lang = ( document.documentElement.lang || '' ).toLowerCase();
		return lang.indexOf( 'ar' ) === 0;
	}

	function splitTextNodes( node, byChar ) {
		if ( ! node || isArabicDoc() ) {
			return;
		}
		if ( byChar ) {
			return;
		}
	}

	function ready() {
		var key;
		root.classList.add( 'mah-motion-on' );
		if ( isArabicDoc() ) {
			root.classList.add( 'mah-lang-ar' );
		}
		splitTextNodes( document.querySelector( '.mah-hero__name-text' ), true );
		for ( key in config ) {
			if ( Object.prototype.hasOwnProperty.call( config, key ) && on( key ) ) {
				root.classList.add( 'mah-fx-' + key );
				root.classList.add( 'mah-fx-' + key + '-' + level( key ) );
			}
		}
	}

	function heroEntrance() {
		if ( ! on( 'hero' ) ) {
			return;
		}
		var nodes = document.querySelectorAll( '[data-mah-stage]' );
		var gap = subtle( 'hero' ) ? 50 : 70;
		var i;
		var staged = 0;
		for ( i = 0; i < nodes.length; i++ ) {
			( function ( node, delay ) {
				var immediate = node.getAttribute( 'data-mah-stage' ) === 'name' || node.getAttribute( 'data-mah-stage' ) === 'portrait';
				if ( immediate ) {
					node.classList.add( 'is-in' );
					return;
				}
				window.setTimeout( function () {
					node.classList.add( 'is-in' );
				}, delay );
			} )( nodes[ i ], 80 + staged * gap );
			if ( nodes[ i ].getAttribute( 'data-mah-stage' ) !== 'name' && nodes[ i ].getAttribute( 'data-mah-stage' ) !== 'portrait' ) {
				staged += 1;
			}
		}
	}

	var REVEAL_ITEMS = '.mah-sec__head, .mah-svc__item, .mah-rev__card, .mah-about__card, .mah-proc__step, .mah-viewport, .mah-proof__item, .mah-footer';

	function markIn( node, delay ) {
		if ( ! node || node.classList.contains( 'is-in' ) ) {
			return;
		}
		if ( delay ) {
			node.style.transitionDelay = delay;
		}
		node.classList.add( 'is-in' );
		if ( node.classList.contains( 'mah-viewport--rail' ) ) {
			var rail = node.closest( '[data-mah-rail]' ) || node.parentNode;
			var sibs;
			var s;
			if ( rail ) {
				sibs = rail.querySelectorAll( '.mah-viewport' );
				for ( s = 0; s < sibs.length; s++ ) {
					if ( sibs[ s ] !== node ) {
						markIn( sibs[ s ], delay );
					}
				}
			}
		}
	}

	function revealAll() {
		var nodes = document.querySelectorAll( '[data-mah-reveal], [data-mah-reveal] ' + REVEAL_ITEMS );
		var i;
		root.classList.add( 'mah-reveal-failsafe' );
		for ( i = 0; i < nodes.length; i++ ) {
			markIn( nodes[ i ], '' );
		}
	}

	function alreadyInView( el ) {
		return el.getBoundingClientRect().top < window.innerHeight * 0.9;
	}

	function revealDelay( el ) {
		var parent = el.parentNode;
		var gap = subtle( 'reveals' ) ? 50 : 80;
		var i;
		var siblings;
		if ( ! parent ) {
			return '0ms';
		}
		siblings = parent.querySelectorAll( REVEAL_ITEMS );
		for ( i = 0; i < siblings.length; i++ ) {
			if ( siblings[ i ] === el ) {
				return ( Math.min( i, 8 ) * gap ) + 'ms';
			}
		}
		return '0ms';
	}

	function reveals() {
		if ( ! on( 'reveals' ) ) {
			return;
		}

		window.addEventListener( 'beforeprint', revealAll );

		if ( ! ( 'IntersectionObserver' in window ) ) {
			revealAll();
			return;
		}

		var items = document.querySelectorAll( '[data-mah-reveal] ' + REVEAL_ITEMS );
		var pending = [];
		var obs = new IntersectionObserver(
			function ( entries ) {
				entries.forEach( function ( entry ) {
					if ( ! entry.isIntersecting && entry.boundingClientRect.top >= window.innerHeight * 0.9 ) {
						return;
					}
					markIn( entry.target, revealDelay( entry.target ) );
					obs.unobserve( entry.target );
				} );
			},
			{
				threshold: 0,
				rootMargin: '0px 100% -10% 100%',
			}
		);

		function flushVisible() {
			var i;
			var node;
			var still = [];
			for ( i = 0; i < pending.length; i++ ) {
				node = pending[ i ];
				if ( node.classList.contains( 'is-in' ) ) {
					continue;
				}
				if ( alreadyInView( node ) ) {
					markIn( node, revealDelay( node ) );
					obs.unobserve( node );
				} else {
					still.push( node );
				}
			}
			pending = still;
		}

		var i;
		for ( i = 0; i < items.length; i++ ) {
			if ( alreadyInView( items[ i ] ) ) {
				markIn( items[ i ], revealDelay( items[ i ] ) );
			} else {
				pending.push( items[ i ] );
				obs.observe( items[ i ] );
			}
		}
		onScroll( flushVisible );
		window.addEventListener( 'resize', flushVisible );
	}

	function parseCount( raw ) {
		var match = String( raw ).match( /([\d.]+)/ );
		return match ? parseFloat( match[ 1 ] ) : 0;
	}

	function suffixOf( raw ) {
		return String( raw ).replace( /[\d.]+/, '' );
	}

	function countUp() {
		if ( ! on( 'stats' ) || ! ( 'IntersectionObserver' in window ) ) {
			return;
		}
		var nodes = document.querySelectorAll( '[data-mah-count]' );
		var obs = new IntersectionObserver(
			function ( entries ) {
				entries.forEach( function ( entry ) {
					if ( ! entry.isIntersecting ) {
						return;
					}
					var el = entry.target;
					var visual = el.querySelector( '[aria-hidden="true"]' );
					var raw = el.getAttribute( 'data-mah-count' ) || '';
					var end = parseCount( raw );
					var suffix = suffixOf( raw );
					var start = performance.now();
					var dur = subtle( 'stats' ) ? 700 : 1100;
					function tick( now ) {
						var t = Math.min( 1, ( now - start ) / dur );
						var eased = 1 - Math.pow( 1 - t, 3 );
						var value = end * eased;
						if ( visual ) {
							visual.textContent = ( String( raw ).indexOf( '.' ) !== -1 ? value.toFixed( 1 ) : Math.round( value ) ) + suffix;
						}
						if ( t < 1 ) {
							window.requestAnimationFrame( tick );
						} else if ( visual ) {
							visual.textContent = raw;
						}
					}
					window.requestAnimationFrame( tick );
					obs.unobserve( el );
				} );
			},
			{ threshold: 0.2 }
		);
		var i;
		for ( i = 0; i < nodes.length; i++ ) {
			obs.observe( nodes[ i ] );
		}
	}

	function workPan() {
		if ( ! on( 'work' ) || viewSupports ) {
			return;
		}
		var frame = document.querySelector( '.mah-viewport--featured .mah-frame__img' );
		var section = document.getElementById( 'work' );
		if ( ! frame || ! section ) {
			return;
		}
		function update() {
			var rect = section.getBoundingClientRect();
			var span = rect.height + window.innerHeight;
			var progress = 1 - ( rect.bottom / span );
			progress = Math.max( 0, Math.min( 1, progress ) );
			var max = subtle( 'work' ) ? 6 : 12;
			frame.style.transform = 'translateY(' + ( -progress * max ) + '%)';
		}
		onScroll( update );
	}

	function railProgress() {
		var rail = document.querySelector( '[data-mah-rail]' );
		var bar = document.querySelector( '.mah-work__rail-progress span' );
		if ( ! rail || ! bar ) {
			return;
		}
		function update() {
			var max = rail.scrollWidth - rail.clientWidth;
			var p = max > 0 ? rail.scrollLeft / max : 0;
			bar.style.transform = 'scaleX(' + p + ')';
		}
		var railTick = false;
		rail.addEventListener( 'scroll', function () {
			if ( railTick ) {
				return;
			}
			railTick = true;
			window.requestAnimationFrame( function () {
				railTick = false;
				update();
			} );
		}, { passive: true } );
		update();
	}

	function processLine() {
		if ( ! on( 'process' ) ) {
			return;
		}
		var grid = document.querySelector( '[data-mah-process]' );
		if ( ! grid ) {
			return;
		}
		var dots = grid.querySelectorAll( '[data-mah-step-dot]' );
		function update() {
			var rect = grid.getBoundingClientRect();
			var start = window.innerHeight * 0.85;
			var end = window.innerHeight * 0.2;
			var p = ( start - rect.top ) / ( start - end + rect.height * 0.4 );
			p = Math.max( 0, Math.min( 1, p ) );
			if ( ! viewSupports ) {
				grid.style.setProperty( '--mah-process-progress', String( p ) );
			}
			var i;
			var n = dots.length;
			for ( i = 0; i < n; i++ ) {
				if ( p >= ( i + 0.15 ) / n ) {
					dots[ i ].classList.add( 'is-on' );
				}
			}
		}
		onScroll( update );
	}

	function marqueeSpeed() {
		if ( ! on( 'marquee' ) ) {
			return;
		}
		var track = document.querySelector( '.mah-marquee__track' );
		if ( ! track ) {
			return;
		}
		var lastY = window.scrollY;
		var lastT = performance.now();
		var current = subtle( 'marquee' ) ? 28 : 22;
		function update() {
			var now = performance.now();
			var y = window.scrollY;
			var dt = Math.max( 16, now - lastT );
			var v = Math.abs( y - lastY ) / dt;
			lastY = y;
			lastT = now;
			var target = Math.max( 12, Math.min( 48, ( subtle( 'marquee' ) ? 32 : 24 ) - v * 40 ) );
			current = current + ( target - current ) * 0.12;
			track.style.animationDuration = current.toFixed( 2 ) + 's';
		}
		onScroll( update );
	}

	function headerMotion() {
		if ( ! on( 'header' ) ) {
			return;
		}
		var header = document.querySelector( '[data-mah-header]' );
		if ( ! header ) {
			return;
		}
		var last = window.scrollY;
		var hero = document.getElementById( 'top' );
		var heroH = 0;
		var viewH = window.innerHeight;
		function measure() {
			heroH = hero ? hero.offsetHeight : 0;
			viewH = window.innerHeight;
		}
		measure();
		window.addEventListener( 'resize', measure );
		function update() {
			var y = window.scrollY;
			header.classList.remove( 'is-away' );
			last = y;
			header.classList.toggle( 'is-compact', y > 24 );
			var max = document.documentElement.scrollHeight - viewH;
			var p = max > 0 ? y / max : 0;
			header.style.setProperty( '--mah-scroll-progress', String( p ) );
		}
		onScroll( update );
	}

	function magnetic() {
		if ( ! on( 'magnetic' ) || ! fine ) {
			return;
		}
		var strength = subtle( 'magnetic' ) ? 10 : 18;
		var ctas = document.querySelectorAll( '[data-mah-magnetic]' );
		var i;
		function bind( node ) {
			node.addEventListener( 'pointermove', function ( event ) {
				var box = node.getBoundingClientRect();
				var x = ( event.clientX - box.left - box.width / 2 ) / ( box.width / 2 );
				var y = ( event.clientY - box.top - box.height / 2 ) / ( box.height / 2 );
				node.style.transform = 'translate(' + ( x * strength ) + 'px, ' + ( y * strength ) + 'px)';
			} );
			node.addEventListener( 'pointerleave', function () {
				node.style.transform = '';
			} );
		}
		for ( i = 0; i < ctas.length; i++ ) {
			bind( ctas[ i ] );
		}

		var cards = document.querySelectorAll( '.mah-svc__item, .mah-rev__card, .mah-viewport--rail, .mah-about__card' );
		function glow( node ) {
			node.addEventListener( 'pointermove', function ( event ) {
				var box = node.getBoundingClientRect();
				node.style.setProperty( '--mah-mx', ( ( event.clientX - box.left ) / box.width ) * 100 + '%' );
				node.style.setProperty( '--mah-my', ( ( event.clientY - box.top ) / box.height ) * 100 + '%' );
				node.classList.add( 'has-glow' );
			} );
			node.addEventListener( 'pointerleave', function () {
				node.classList.remove( 'has-glow' );
			} );
		}
		for ( i = 0; i < cards.length; i++ ) {
			glow( cards[ i ] );
		}
	}

	function portraitParallax() {
		if ( ! on( 'hero' ) ) {
			return;
		}
		var fig = document.querySelector( '[data-mah-parallax]' );
		if ( ! fig ) {
			return;
		}
		var amt = subtle( 'hero' ) ? 8 : 16;
		function update() {
			if ( window.innerWidth < 1024 ) {
				fig.style.transform = '';
				fig.style.setProperty( '--mah-glow-shift', '0px' );
				return;
			}
			var y = window.scrollY;
			var shift = Math.max( -amt, Math.min( amt, y * 0.04 ) );
			fig.style.transform = 'translateY(' + shift + 'px)';
			fig.style.setProperty( '--mah-glow-shift', shift + 'px' );
		}
		onScroll( update );
	}

	ready();
	if ( document.readyState === 'loading' ) {
		document.addEventListener( 'DOMContentLoaded', boot );
	} else {
		boot();
	}

	function shuffleReviews() {
		var grids = document.querySelectorAll( '[data-mah-reviews-shuffle="1"]' );
		var g;
		for ( g = 0; g < grids.length; g++ ) {
			var grid = grids[ g ];
			var cards = Array.prototype.slice.call( grid.children );
			var i;
			for ( i = cards.length - 1; i > 0; i-- ) {
				var j = Math.floor( Math.random() * ( i + 1 ) );
				var swap = cards[ i ];
				cards[ i ] = cards[ j ];
				cards[ j ] = swap;
			}
			for ( i = 0; i < cards.length; i++ ) {
				grid.appendChild( cards[ i ] );
			}
		}
	}

	function boot() {
		heroEntrance();
		reveals();
		countUp();
		workPan();
		railProgress();
		processLine();
		marqueeSpeed();
		headerMotion();
		magnetic();
		portraitParallax();
		statsPin();
		shuffleReviews();
	}

	function statsPin() {
		if ( ! on( 'stats' ) ) {
			return;
		}
		var section = document.querySelector( '.mah-home--stats' );
		if ( ! section ) {
			return;
		}
		var bar = section.querySelector( '.mah-pin-progress' );
		if ( bar ) {
			bar.removeAttribute( 'hidden' );
		}
		function update() {
			var box = section.getBoundingClientRect();
			var view = window.innerHeight || 1;
			var span = box.height + view;
			var seen = view - box.top;
			var p = span > 0 ? seen / span : 0;
			if ( p < 0 ) {
				p = 0;
			}
			if ( p > 1 ) {
				p = 1;
			}
			section.style.setProperty( '--mah-pin-progress', p.toFixed( 4 ) );
		}
		onScroll( update );
	}
} )();
