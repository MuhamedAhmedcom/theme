/**
 * Keyboard scrolling for Living Viewport screens and the project rail.
 *
 * Native overflow does not reliably move from arrow keys. This only runs when
 * the focused node is a screen or the rail itself, and never traps Tab.
 */
( function () {
	'use strict';

	var DOWN = { ArrowDown: 1, PageDown: 1, ' ': 1 };
	var UP = { ArrowUp: 1, PageUp: 1 };

	/**
	 * @param {Element} el
	 * @param {string}  key
	 * @return {number}
	 */
	function delta( el, key ) {
		var height = el.clientHeight || 0;
		if ( 'PageDown' === key || 'PageUp' === key ) {
			return height * 0.9;
		}
		if ( ' ' === key ) {
			return height * 0.85;
		}
		return Math.max( 48, height * 0.2 );
	}

	/**
	 * @param {Element} el
	 * @param {number}  dir
	 * @return {boolean}
	 */
	function canScroll( el, dir ) {
		if ( dir > 0 ) {
			return el.scrollTop + el.clientHeight < el.scrollHeight - 1;
		}
		return el.scrollTop > 1;
	}

	/**
	 * @param {KeyboardEvent} event
	 * @return {void}
	 */
	function onScreenKey( event ) {
		var el = event.currentTarget;
		var key = event.key;

		if ( 'Tab' === key ) {
			return;
		}

		if ( 'Home' === key ) {
			if ( el.scrollTop > 0 ) {
				event.preventDefault();
				el.scrollTop = 0;
			}
			return;
		}

		if ( 'End' === key ) {
			if ( canScroll( el, 1 ) ) {
				event.preventDefault();
				el.scrollTop = el.scrollHeight;
			}
			return;
		}

		if ( DOWN[ key ] ) {
			if ( ! canScroll( el, 1 ) ) {
				return;
			}
			event.preventDefault();
			el.scrollBy( { top: delta( el, key ) } );
			return;
		}

		if ( UP[ key ] ) {
			if ( ! canScroll( el, -1 ) ) {
				return;
			}
			event.preventDefault();
			el.scrollBy( { top: -delta( el, key ) } );
		}
	}

	/**
	 * @param {KeyboardEvent} event
	 * @return {void}
	 */
	function onRailKey( event ) {
		var rail, card, width, dir;

		if ( 'ArrowLeft' !== event.key && 'ArrowRight' !== event.key ) {
			return;
		}

		if ( event.target !== event.currentTarget ) {
			return;
		}

		rail = event.currentTarget;
		card = rail.querySelector( '.mah-viewport--rail' );
		width = card ? card.getBoundingClientRect().width : rail.clientWidth * 0.8;
		dir = 'ArrowRight' === event.key ? 1 : -1;
		event.preventDefault();
		rail.scrollBy( { left: dir * ( width + 16 ) } );
	}

	/**
	 * @return {void}
	 */
	/**
	 * @param {Element} wrap
	 * @param {number}  dir
	 * @return {void}
	 */
	function scrollRail( wrap, dir ) {
		var rail = wrap.querySelector( '.mah-work__rail' );
		var card, width;

		if ( ! rail ) {
			return;
		}

		card = rail.querySelector( '.mah-viewport--rail' );
		width = card ? card.getBoundingClientRect().width : rail.clientWidth * 0.8;
		rail.scrollBy( { left: dir * ( width + 16 ), behavior: 'smooth' } );
	}

	function bind() {
		var screens = document.querySelectorAll( '.mah-frame__screen' );
		var rails = document.querySelectorAll( '.mah-work__rail' );
		var wraps = document.querySelectorAll( '.mah-work__rail-wrap' );
		var i;

		for ( i = 0; i < screens.length; i++ ) {
			screens[ i ].addEventListener( 'keydown', onScreenKey );
		}

		for ( i = 0; i < rails.length; i++ ) {
			rails[ i ].addEventListener( 'keydown', onRailKey );
		}

		for ( i = 0; i < wraps.length; i++ ) {
			( function ( wrap ) {
				var prev = wrap.querySelector( '[data-mah-rail-prev]' );
				var next = wrap.querySelector( '[data-mah-rail-next]' );

				if ( prev ) {
					prev.addEventListener( 'click', function () {
						scrollRail( wrap, -1 );
					} );
				}

				if ( next ) {
					next.addEventListener( 'click', function () {
						scrollRail( wrap, 1 );
					} );
				}
			}( wraps[ i ] ) );
		}
	}

	if ( 'loading' === document.readyState ) {
		document.addEventListener( 'DOMContentLoaded', bind );
	} else {
		bind();
	}
}() );
