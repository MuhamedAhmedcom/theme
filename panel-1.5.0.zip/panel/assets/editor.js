/**
 * Editor script for the Muhamed Ahmed blocks.
 *
 * Every block gets a Design panel in the sidebar. Content stays native, so
 * this only exposes what core blocks cannot: the image, the height, and the
 * section rhythm.
 */
( function ( blocks, element, blockEditor, components, i18n ) {
	'use strict';

	var el = element.createElement;
	var Fragment = element.Fragment;
	var __ = i18n.__;
	var InspectorControls = blockEditor.InspectorControls;
	var PanelBody = components.PanelBody;
	var SelectControl = components.SelectControl;
	var TextControl = components.TextControl;
	var RangeControl = components.RangeControl;
	var ToggleControl = components.ToggleControl;
	var MediaUpload = blockEditor.MediaUpload;
	var MediaUploadCheck = blockEditor.MediaUploadCheck;
	var Button = components.Button;

	/**
	 * Build a sidebar control from a descriptor.
	 *
	 * @param {Object}   c           Control descriptor.
	 * @param {Object}   attributes  Current attributes.
	 * @param {Function} setAttributes Setter.
	 * @return {Object} Element.
	 */
	function control( c, attributes, setAttributes ) {
		var value = attributes[ c.name ];

		function patch( v ) {
			var p = {};
			p[ c.name ] = v;
			setAttributes( p );
		}

		switch ( c.type ) {
			case 'select':
				return el( SelectControl, {
					key: c.name,
					label: c.label,
					value: value,
					options: c.options,
					__nextHasNoMarginBottom: true,
					onChange: patch,
				} );

			case 'range':
				return el( RangeControl, {
					key: c.name,
					label: c.label,
					value: value,
					min: c.min,
					max: c.max,
					__nextHasNoMarginBottom: true,
					onChange: patch,
				} );

			case 'toggle':
				return el( ToggleControl, {
					key: c.name,
					label: c.label,
					checked: !! value,
					__nextHasNoMarginBottom: true,
					onChange: patch,
				} );

			default:
				return el( TextControl, {
					key: c.name,
					label: c.label,
					value: value || '',
					__nextHasNoMarginBottom: true,
					onChange: patch,
				} );
		}
	}

	/**
	 * Image picker backed by the media library.
	 *
	 * Uses core MediaUpload rather than a custom modal so the client's images
	 * stay reusable and the UI matches the rest of the editor.
	 *
	 * @param {Object}   attributes    Current attributes.
	 * @param {Function} setAttributes Setter.
	 * @return {Object} Element.
	 */
	function imagePicker( attributes, setAttributes ) {
		var id = attributes.portrait || 0;

		return el(
			MediaUploadCheck,
			null,
			el(
				MediaUpload,
				{
					allowedTypes: [ 'image' ],
					value: id,
					onSelect: function ( media ) {
						setAttributes( { portrait: media.id } );
					},
					render: function ( props ) {
						if ( ! id ) {
							return el(
								Button,
								{
									onClick: props.open,
									variant: 'secondary',
								},
								__( 'Choose image', 'muhamedahmed' )
							);
						}

						return el(
							'div',
							{ className: 'mah-media-row' },
							el( 'img', {
								src: ( props.media && props.media.url ) || '',
								alt: '',
								style: { maxWidth: '100%', borderRadius: '8px' },
							} ),
							el(
								'div',
								{ className: 'mah-media-actions' },
								el(
									Button,
									{ onClick: props.open, variant: 'secondary' },
									__( 'Replace', 'muhamedahmed' )
								),
								el(
									Button,
									{
										onClick: function () {
											setAttributes( { portrait: 0 } );
										},
										variant: 'tertiary',
										isDestructive: true,
									},
									__( 'Remove', 'muhamedahmed' )
								)
							)
						);
					},
				}
			)
		);
	}

	/**
	 * Wrap the sidebar panel.
	 *
	 * @param {Array}    controls    Control descriptors.
	 * @param {Object}   attributes  Current attributes.
	 * @param {Function} setAttributes Setter.
	 * @param {Object}   extra       Extra elements to append.
	 * @return {Object} Element.
	 */
	function panel( controls, attributes, setAttributes, extra ) {
		var children = controls.map( function ( c ) {
			return control( c, attributes, setAttributes );
		} );

		if ( extra ) {
			children.push( extra );
		}

		return el(
			InspectorControls,
			{ group: 'mah-design' },
			el( PanelBody, { title: __( 'Design', 'muhamedahmed' ), initialOpen: true }, children )
		);
	}

	/* ---- Hero ---- */

	blocks.registerBlockType( 'muhamedahmed/hero', {
		edit: function ( props ) {
			var a = props.attributes;
			var inner = blockEditor.useBlockProps( {
				className: 'mah-hero',
			} );

			var extra = el(
				'div',
				{ style: { marginTop: '16px' } },
				el(
					'p',
					{ className: 'mah-panel-label' },
					__( 'Portrait override', 'muhamedahmed' )
				),
				imagePicker( a, props.setAttributes )
			);

			return el(
				Fragment,
				null,
				panel( [], a, props.setAttributes, extra ),
				el(
					'div',
					inner,
					el(
						'p',
						{ className: 'mah-editor-note' },
						__( 'Hero copy, buttons and portrait come from Site Content. Use the override only to pick a different image on this block.', 'muhamedahmed' )
					)
				)
			);
		},
		save: function () {
			return null;
		},
	} );

	/* ---- Section ---- */

	blocks.registerBlockType( 'muhamedahmed/section', {
		edit: function ( props ) {
			var inner = blockEditor.useBlockProps();
			var a = props.attributes;

			var controls = [
				{
					name: 'layout',
					type: 'select',
					label: __( 'Background', 'muhamedahmed' ),
					options: [
						{ label: __( 'Ground (grey)', 'muhamedahmed' ), value: 'ground' },
						{ label: __( 'Paper (white)', 'muhamedahmed' ), value: 'paper' },
						{ label: __( 'Band (near black)', 'muhamedahmed' ), value: 'band' },
						{ label: __( 'Accent (lime)', 'muhamedahmed' ), value: 'accent' },
					],
				},
				{ name: 'eyebrow', label: __( 'Eyebrow label', 'muhamedahmed' ) },
				/*
				 * `anchor` is the attribute the core anchor support uses, so this
				 * field and the core HTML anchor field write the same value and
				 * the section ends up with one id.
				 */
				{ name: 'anchor', label: __( 'Anchor ID', 'muhamedahmed' ) },
				{
					name: 'align',
					type: 'select',
					label: __( 'Inner width', 'muhamedahmed' ),
					options: [
						{ label: __( 'Content width', 'muhamedahmed' ), value: 'wide' },
						{ label: __( 'Full bleed', 'muhamedahmed' ), value: 'flush' },
					],
				},
				{ name: 'tone', type: 'toggle', label: __( 'Muted text', 'muhamedahmed' ) },
				{ name: 'rule', type: 'toggle', label: __( 'Top hairline', 'muhamedahmed' ) },
			];

			return el(
				Fragment,
				null,
				panel( controls, a, props.setAttributes ),
				el( 'section', { className: 'mah-sec mah-sec--' + a.layout }, props.children )
			);
		},
		save: function () {
			return null;
		},
	} );

	/* ---- Marquee ---- */

	blocks.registerBlockType( 'muhamedahmed/marquee', {
		edit: function ( props ) {
			var a = props.attributes;
			var blockProps = blockEditor.useBlockProps();

			var controls = [
				{ name: 'text', label: __( 'Phrases (separate with •)', 'muhamedahmed' ) },
				{
					name: 'tone',
					type: 'select',
					label: __( 'Band colour', 'muhamedahmed' ),
					options: [
						{ label: __( 'Accent (lime)', 'muhamedahmed' ), value: 'accent' },
						{ label: __( 'Near black', 'muhamedahmed' ), value: 'band' },
					],
				},
				{ name: 'speed', type: 'range', label: __( 'Loop seconds', 'muhamedahmed' ), min: 8, max: 60 },
			];

			var parts = ( a.text || '' ).split( '•' ).map( function ( s ) {
				return s.trim();
			} ).filter( Boolean );

			var preview = el(
				'div',
				{ className: 'mah-marquee mah-marquee--' + a.tone },
				el(
					'div',
					{ className: 'mah-marquee__track' },
					el(
						'div',
						{ className: 'mah-marquee__group' },
						parts.length
							? parts.map( function ( p, i ) {
									return el(
										Fragment,
										{ key: i },
										el( 'span', { className: 'mah-marquee__item' }, p ),
										el( 'span', { className: 'mah-marquee__sep', 'aria-hidden': 'true' } )
									);
								} )
							: el( 'span', { className: 'mah-marquee__item' }, __( 'Add phrases…', 'muhamedahmed' ) )
					)
				)
			);

			return el( Fragment, null, panel( controls, a, props.setAttributes ), el( 'div', blockProps, preview ) );
		},
		save: function () {
			return null;
		},
	} );

	/* ---- Stats ---- */

	blocks.registerBlockType( 'muhamedahmed/stats', {
		edit: function ( props ) {
			var inner = blockEditor.useBlockProps( {
				className: 'mah-stats',
			} );

			return el(
				Fragment,
				null,
				el(
					InspectorControls,
					{ group: 'mah-design' },
					el(
						PanelBody,
						{ title: __( 'Design', 'muhamedahmed' ), initialOpen: true },
						el(
							'p',
							{ className: 'mah-editor-note' },
							__( 'Figures come from Site Content. Each item is the value stacked over its label.', 'muhamedahmed' )
						)
					)
				),
				el(
					'div',
					inner,
					el(
						'p',
						{ className: 'mah-editor-note' },
						__( 'Statistics', 'muhamedahmed' )
					)
				)
			);
		},
		save: function () {
			return null;
		},
	} );

	/* ---- About ---- */

	blocks.registerBlockType( 'muhamedahmed/about', {
		edit: function ( props ) {
			var inner = blockEditor.useBlockProps( {
				className: 'mah-sec mah-sec--paper mah-about',
			} );

			return el(
				Fragment,
				null,
				el(
					InspectorControls,
					{ group: 'mah-design' },
					el(
						PanelBody,
						{ title: __( 'Design', 'muhamedahmed' ), initialOpen: true },
						el(
							'p',
							{ className: 'mah-editor-note' },
							__( 'Heading, story, bio and points come from Site Content. The section is omitted when those fields are empty.', 'muhamedahmed' )
						)
					)
				),
				el(
					'section',
					inner,
					el(
						'p',
						{ className: 'mah-editor-note' },
						__( 'About', 'muhamedahmed' )
					)
				)
			);
		},
		save: function () {
			return null;
		},
	} );

	/* ---- Work index ---- */

	blocks.registerBlockType( 'muhamedahmed/work', {
		edit: function ( props ) {
			var inner = blockEditor.useBlockProps( {
				className: 'mah-work',
			} );
			var a = props.attributes;

			var controls = [
				{ name: 'count', type: 'range', label: __( 'Count', 'muhamedahmed' ), min: 1, max: 12 },
			];

			return el(
				Fragment,
				null,
				panel( controls, a, props.setAttributes ),
				el(
					'div',
					inner,
					el(
						'p',
						{ className: 'mah-editor-note' },
						__( 'Projects come from the Projects post type as living viewports. This block has no inner content.', 'muhamedahmed' )
					)
				)
			);
		},
		save: function () {
			return null;
		},
	} );
} )(
	window.wp.blocks,
	window.wp.element,
	window.wp.blockEditor,
	window.wp.components,
	window.wp.i18n
);