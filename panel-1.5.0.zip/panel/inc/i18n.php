<?php
/**
 * WPML readiness helpers. No-ops when WPML is absent.
 *
 * @package ProWPSite
 */

if ( ! defined( 'ABSPATH' ) && ! defined( 'MUHAMEDAHMED_I18N_STANDALONE' ) ) {
	exit;
}

/**
 * String Translation context. Stable; do not rename.
 *
 * @return string
 */
function muhamedahmed_i18n_context() {
	return 'Muhamed Ahmed Panel';
}

/**
 * Plugin text domain.
 *
 * @return string
 */
function muhamedahmed_i18n_textdomain() {
	return 'prowpsite-panel';
}

/**
 * Integer helper that works in CLI stubs.
 *
 * @param mixed $value Raw value.
 * @return int
 */
function muhamedahmed_i18n_absint( $value ) {
	if ( function_exists( 'absint' ) ) {
		return absint( $value );
	}

	return abs( (int) $value );
}

/**
 * Remember a string name for the admin registry count.
 *
 * @param string $name  Stable string name.
 * @param string $value Current value.
 * @return void
 */
function muhamedahmed_i18n_remember( $name, $value ) {
	if ( ! isset( $GLOBALS['muhamedahmed_i18n_registry'] ) || ! is_array( $GLOBALS['muhamedahmed_i18n_registry'] ) ) {
		$GLOBALS['muhamedahmed_i18n_registry'] = array();
	}

	$GLOBALS['muhamedahmed_i18n_registry'][ (string) $name ] = (string) $value;
}

/**
 * How many unique string names the helper has seen this request.
 *
 * @return int
 */
function muhamedahmed_i18n_registered_count() {
	if ( function_exists( 'muhamedahmed_i18n_register_all' ) ) {
		muhamedahmed_i18n_register_all();
	}

	$reg = isset( $GLOBALS['muhamedahmed_i18n_registry'] ) && is_array( $GLOBALS['muhamedahmed_i18n_registry'] )
		? $GLOBALS['muhamedahmed_i18n_registry']
		: array();

	return count( $reg );
}

/**
 * Translate a stored panel string. Falls back to $value when WPML is absent.
 *
 * @param string $value Source text.
 * @param string $name  Stable name derived from the option key.
 * @return string
 */
function muhamedahmed_t( $value, $name ) {
	$value = is_scalar( $value ) ? (string) $value : '';
	$name  = is_scalar( $name ) ? (string) $name : '';

	if ( '' === $name ) {
		return $value;
	}

	muhamedahmed_i18n_remember( $name, $value );

	if ( '' === $value ) {
		return '';
	}

	$context = muhamedahmed_i18n_context();

	if ( function_exists( 'do_action' ) ) {
		do_action( 'wpml_register_single_string', $context, $name, $value );
	}

	if ( function_exists( 'apply_filters' ) ) {
		return (string) apply_filters( 'wpml_translate_single_string', $value, $context, $name );
	}

	return $value;
}

/**
 * Map a stored post/term/attachment ID to the current language.
 *
 * @param int    $id               Stored ID.
 * @param string $type             WPML object type (post type, taxonomy, or attachment).
 * @param bool   $return_original  Pass true so a missing translation keeps the original.
 * @return int
 */
function muhamedahmed_object_id( $id, $type = 'post', $return_original = true ) {
	$id = muhamedahmed_i18n_absint( $id );

	if ( $id < 1 ) {
		return 0;
	}

	if ( ! function_exists( 'apply_filters' ) ) {
		return $id;
	}

	$mapped = apply_filters( 'wpml_object_id', $id, $type, (bool) $return_original );

	$mapped = muhamedahmed_i18n_absint( $mapped );

	if ( $mapped > 0 ) {
		return $mapped;
	}

	return $return_original ? $id : 0;
}

/**
 * Filter a site permalink through WPML. Leaves mailto/tel/hash/external as-is
 * unless WPML's filter changes them.
 *
 * @param string $url URL.
 * @return string
 */
function muhamedahmed_permalink( $url ) {
	if ( ! is_scalar( $url ) ) {
		return '';
	}

	$url = trim( (string) $url );

	if ( '' === $url ) {
		return '';
	}

	if ( 0 === strpos( $url, '#' ) || 0 === strpos( $url, 'mailto:' ) || 0 === strpos( $url, 'tel:' ) || 0 === strpos( $url, 'sms:' ) ) {
		return $url;
	}

	if ( function_exists( 'apply_filters' ) ) {
		return (string) apply_filters( 'wpml_permalink', $url );
	}

	return $url;
}

/**
 * Whether WPML (or a compatible stub) is active.
 *
 * @return bool
 */
function muhamedahmed_wpml_is_active() {
	if ( defined( 'ICL_SITEPRESS_VERSION' ) ) {
		return true;
	}

	if ( function_exists( 'has_filter' ) && has_filter( 'wpml_active_languages' ) ) {
		return true;
	}

	if ( function_exists( 'has_action' ) && has_action( 'wpml_register_single_string' ) ) {
		return true;
	}

	return false;
}

/**
 * Current language code. Empty when WPML is absent.
 *
 * @return string
 */
function muhamedahmed_current_language() {
	$code = '';

	if ( function_exists( 'apply_filters' ) ) {
		$filtered = apply_filters( 'wpml_current_language', null );
		if ( is_string( $filtered ) && '' !== $filtered ) {
			$code = $filtered;
		}
	}

	if ( '' === $code && defined( 'ICL_LANGUAGE_CODE' ) && is_string( ICL_LANGUAGE_CODE ) ) {
		$code = ICL_LANGUAGE_CODE;
	}

	return $code;
}

/**
 * Scalar option keys whose front-end values are translatable copy.
 *
 * @return array<int,string>
 */
function muhamedahmed_i18n_text_option_keys() {
	$keys = array(
		'mah_full_name',
		'mah_role',
		'mah_tagline',
		'mah_bio',
		'mah_location',
		'mah_response_time',
		'mah_availability',
		'mah_cta_label',
		'mah_cta_secondary',
		'mah_about_eyebrow',
		'mah_about_heading',
		'mah_about_body',
		'mah_years_experience',
		'mah_years_experience_label',
		'mah_working_worldwide',
		'mah_proof_projects_label',
		'mah_proof_reviews_label',
		'mah_footer_headline',
		'mah_home_hero_kicker',
		'mah_home_hero_cta_label',
		'mah_home_hero_alt',
		'mah_home_work_case_label',
		'mah_nav_work',
		'mah_nav_services',
		'mah_nav_process',
		'mah_nav_about',
		'mah_nav_reviews',
	);

	$sections = array( 'hero', 'marquee', 'stats', 'services', 'work', 'process', 'about', 'reviews', 'contact' );

	foreach ( $sections as $section ) {
		$keys[] = 'mah_home_' . $section . '_eyebrow';
		$keys[] = 'mah_home_' . $section . '_heading';
		$keys[] = 'mah_home_' . $section . '_intro';
	}

	return $keys;
}

/**
 * Identity array keys that hold translatable copy.
 *
 * @return array<int,string>
 */
function muhamedahmed_i18n_identity_text_keys() {
	return array(
		'full_name',
		'role',
		'tagline',
		'bio',
		'location',
		'response_time',
		'availability',
		'cta_label',
	);
}

/**
 * Translate an identity field when it is copy, not a contact handle.
 *
 * @param string $key   Identity key.
 * @param string $value Stored value.
 * @return string
 */
function muhamedahmed_i18n_identity_value( $key, $value ) {
	$key   = is_scalar( $key ) ? (string) $key : '';
	$value = is_scalar( $value ) ? (string) $value : '';

	if ( 'cta_target' === $key ) {
		return muhamedahmed_permalink( $value );
	}

	if ( in_array( $key, muhamedahmed_i18n_identity_text_keys(), true ) ) {
		return muhamedahmed_t( $value, 'mah_identity.' . $key );
	}

	return $value;
}

/**
 * Register every known panel string once. Does not write options.
 *
 * @return void
 */
function muhamedahmed_i18n_register_all( $force = false ) {
	static $ran = false;

	if ( $ran && ! $force ) {
		return;
	}

	$ran = true;

	if ( ! function_exists( 'get_option' ) ) {
		return;
	}

	foreach ( muhamedahmed_i18n_text_option_keys() as $key ) {
		$raw = get_option( $key, '' );
		if ( is_scalar( $raw ) && '' !== trim( (string) $raw ) ) {
			muhamedahmed_t( (string) $raw, $key );
		} else {
			muhamedahmed_i18n_remember( $key, '' );
		}
	}

	$identity = get_option( 'mah_identity', array() );
	if ( is_array( $identity ) ) {
		foreach ( muhamedahmed_i18n_identity_text_keys() as $ikey ) {
			$val = isset( $identity[ $ikey ] ) && is_scalar( $identity[ $ikey ] ) ? (string) $identity[ $ikey ] : '';
			if ( '' !== trim( $val ) ) {
				muhamedahmed_t( $val, 'mah_identity.' . $ikey );
			} else {
				muhamedahmed_i18n_remember( 'mah_identity.' . $ikey, '' );
			}
		}
	}

	muhamedahmed_i18n_register_rows( 'mah_stats', array( '0', '1' ) );
	muhamedahmed_i18n_register_rows( 'mah_process', array( '0', '1' ) );
	muhamedahmed_i18n_register_list( 'mah_marquee_phrases' );
	muhamedahmed_i18n_register_list( 'mah_about_points' );

	$links = get_option( 'mah_section_links', array() );
	if ( is_array( $links ) ) {
		foreach ( $links as $index => $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}
			$label = isset( $row['label'] ) && is_scalar( $row['label'] ) ? (string) $row['label'] : '';
			if ( '' !== $label ) {
				muhamedahmed_t( $label, 'mah_section_links.' . (int) $index . '.label' );
			}
		}
	}

	$panel = get_option( 'muhamed_ahmed_panel', array() );
	if ( is_array( $panel ) ) {
		foreach ( muhamedahmed_i18n_text_option_keys() as $key ) {
			if ( ! isset( $panel[ $key ] ) || ! is_scalar( $panel[ $key ] ) ) {
				continue;
			}
			$val = (string) $panel[ $key ];
			if ( '' !== trim( $val ) ) {
				muhamedahmed_t( $val, $key );
			}
		}
	}
}

/**
 * Register repeating two-column option rows.
 *
 * @param string        $option Option name.
 * @param array<int,string> $cols  Column keys.
 * @return void
 */
function muhamedahmed_i18n_register_rows( $option, array $cols ) {
	$rows = get_option( $option, array() );

	if ( ! is_array( $rows ) ) {
		return;
	}

	foreach ( $rows as $index => $row ) {
		if ( ! is_array( $row ) ) {
			continue;
		}

		foreach ( $cols as $col ) {
			$val = '';
			if ( isset( $row[ $col ] ) && is_scalar( $row[ $col ] ) ) {
				$val = (string) $row[ $col ];
			}
			if ( '' !== trim( $val ) ) {
				muhamedahmed_t( $val, $option . '.' . (int) $index . '.' . $col );
			}
		}
	}
}

/**
 * Register a string list option.
 *
 * @param string $option Option name.
 * @return void
 */
function muhamedahmed_i18n_register_list( $option ) {
	$rows = get_option( $option, array() );

	if ( is_string( $rows ) ) {
		$rows = preg_split( '/\r\n|\r|\n/', $rows );
	}

	if ( ! is_array( $rows ) ) {
		return;
	}

	foreach ( $rows as $index => $row ) {
		if ( is_array( $row ) ) {
			$row = isset( $row['phrase'] ) ? $row['phrase'] : ( isset( $row[0] ) ? $row[0] : '' );
		}
		if ( ! is_scalar( $row ) ) {
			continue;
		}
		$val = trim( (string) $row );
		if ( '' !== $val ) {
			muhamedahmed_t( $val, $option . '.' . (int) $index );
		}
	}
}

/**
 * Switcher position: header, footer, or both.
 *
 * @return string
 */
function muhamedahmed_lang_switcher_position() {
	$pos = 'header';

	if ( function_exists( 'get_option' ) ) {
		$stored = get_option( 'mah_lang_switcher_position', 'header' );
		$raw    = is_scalar( $stored ) ? strtolower( (string) $stored ) : 'header';
		$pos    = function_exists( 'sanitize_key' ) ? sanitize_key( $raw ) : preg_replace( '/[^a-z0-9_\-]/', '', $raw );
	}

	return in_array( $pos, array( 'header', 'footer', 'both' ), true ) ? $pos : 'header';
}

/**
 * Whether the language switcher is enabled. Default on.
 *
 * @return bool
 */
function muhamedahmed_lang_switcher_enabled() {
	if ( function_exists( 'muhamedahmed_option_is_on' ) ) {
		return muhamedahmed_option_is_on( 'mah_lang_switcher', true );
	}

	if ( ! function_exists( 'get_option' ) ) {
		return true;
	}

	$raw = get_option( 'mah_lang_switcher', '1' );

	if ( '0' === (string) $raw || 0 === $raw || false === $raw ) {
		return false;
	}

	return true;
}

/**
 * Language switcher markup, or an empty string (no wrapper) when hidden.
 *
 * @param string $location header or footer.
 * @return string
 */
function muhamedahmed_language_switcher_markup( $location = 'header' ) {
	$location = ( 'footer' === $location ) ? 'footer' : 'header';

	if ( ! muhamedahmed_lang_switcher_enabled() ) {
		return '';
	}

	$position = muhamedahmed_lang_switcher_position();

	if ( 'both' !== $position && $position !== $location ) {
		return '';
	}

	if ( ! function_exists( 'apply_filters' ) ) {
		return '';
	}

	$langs = apply_filters( 'wpml_active_languages', null, 'skip_missing=0' );

	if ( ! is_array( $langs ) || count( $langs ) < 2 ) {
		return '';
	}

	$current = muhamedahmed_current_language();
	$domain  = muhamedahmed_i18n_textdomain();
	$label   = function_exists( '__' ) ? __( 'Languages', $domain ) : 'Languages';
	$html    = '<nav class="mah-langs mah-langs--' . ( function_exists( 'sanitize_html_class' ) ? sanitize_html_class( $location ) : $location ) . '" aria-label="' . ( function_exists( 'esc_attr' ) ? esc_attr( $label ) : $label ) . '">';
	$html   .= '<ul class="mah-langs__list">';

	foreach ( $langs as $code => $lang ) {
		if ( ! is_array( $lang ) ) {
			continue;
		}

		$code     = is_scalar( $code ) ? (string) $code : ( isset( $lang['code'] ) ? (string) $lang['code'] : '' );
		$native   = isset( $lang['native_name'] ) ? (string) $lang['native_name'] : ( isset( $lang['translated_name'] ) ? (string) $lang['translated_name'] : $code );
		$url      = isset( $lang['url'] ) ? (string) $lang['url'] : '';
		$active   = ! empty( $lang['active'] ) || ( '' !== $current && $code === $current );
		$hreflang = isset( $lang['code'] ) ? (string) $lang['code'] : $code;
		$item_lang = isset( $lang['tag'] ) ? (string) $lang['tag'] : $hreflang;

		if ( '' === $code || '' === $url ) {
			continue;
		}

		$esc_url  = function_exists( 'esc_url' ) ? esc_url( $url ) : $url;
		$esc_name = function_exists( 'esc_html' ) ? esc_html( $native ) : $native;
		$esc_lang = function_exists( 'esc_attr' ) ? esc_attr( $item_lang ) : $item_lang;
		$aria     = $active ? ' aria-current="true"' : '';

		$html .= '<li class="mah-langs__item' . ( $active ? ' is-current' : '' ) . '">';
		$html .= '<a class="mah-langs__link" href="' . $esc_url . '" lang="' . $esc_lang . '" hreflang="' . ( function_exists( 'esc_attr' ) ? esc_attr( $hreflang ) : $hreflang ) . '"' . $aria . '>' . $esc_name . '</a>';
		$html .= '</li>';
	}

	$html .= '</ul></nav>';

	if ( false === strpos( $html, 'mah-langs__item' ) ) {
		return '';
	}

	return $html;
}

/**
 * Read-only Languages status HTML for Site Content.
 *
 * @return string
 */
function muhamedahmed_languages_status_html() {
	$domain = muhamedahmed_i18n_textdomain();
	$active = muhamedahmed_wpml_is_active();
	$yes    = function_exists( '__' ) ? __( 'yes', $domain ) : 'yes';
	$no     = function_exists( '__' ) ? __( 'no', $domain ) : 'no';
	$title  = function_exists( '__' ) ? __( 'Languages', $domain ) : 'Languages';
	$wpml   = function_exists( '__' ) ? __( 'WPML active', $domain ) : 'WPML active';
	$list_l = function_exists( '__' ) ? __( 'Active languages', $domain ) : 'Active languages';
	$none   = function_exists( '__' ) ? __( 'none', $domain ) : 'none';
	$reg_l  = function_exists( '__' ) ? __( 'Strings registered', $domain ) : 'Strings registered';
	$note   = function_exists( '__' )
		? __( 'Translate panel texts in WPML > String Translation > context Muhamed Ahmed Panel', $domain )
		: 'Translate panel texts in WPML > String Translation > context Muhamed Ahmed Panel';

	$codes = array();
	if ( function_exists( 'apply_filters' ) ) {
		$langs = apply_filters( 'wpml_active_languages', null, 'skip_missing=0' );
		if ( is_array( $langs ) ) {
			foreach ( $langs as $code => $lang ) {
				if ( is_array( $lang ) && isset( $lang['code'] ) ) {
					$codes[] = (string) $lang['code'];
				} elseif ( is_scalar( $code ) ) {
					$codes[] = (string) $code;
				}
			}
		}
	}

	$count = muhamedahmed_i18n_registered_count();
	$list  = $codes ? implode( ', ', $codes ) : $none;
	$esc   = function_exists( 'esc_html' ) ? 'esc_html' : null;

	$out  = '<div class="mah-lang-status">';
	$out .= '<p><strong>' . ( $esc ? $esc( $title ) : $title ) . '</strong></p>';
	$out .= '<p>' . ( $esc ? $esc( $wpml ) : $wpml ) . ': ' . ( $esc ? $esc( $active ? $yes : $no ) : ( $active ? $yes : $no ) ) . '</p>';
	$out .= '<p>' . ( $esc ? $esc( $list_l ) : $list_l ) . ': ' . ( $esc ? $esc( $list ) : $list ) . '</p>';
	$out .= '<p>' . ( $esc ? $esc( $reg_l ) : $reg_l ) . ': ' . (int) $count . '</p>';
	$out .= '<p>' . ( $esc ? $esc( $note ) : $note ) . '</p>';
	$out .= '</div>';

	return $out;
}
