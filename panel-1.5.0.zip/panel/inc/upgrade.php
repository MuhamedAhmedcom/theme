<?php
/**
 * Version-gated panel upgrades. Runs on plugins_loaded / admin_init, not
 * only on activation, so a zip overwrite is enough.
 *
 * @package ProWPSite
 */

defined( 'ABSPATH' ) || exit;

/**
 * Stored schema version for builder seed and featured-flag migration.
 *
 * @return string
 */
function prowp_panel_db_version() {
	return '1.5.0';
}

/**
 * Option that records the last applied panel DB version.
 *
 * @return string
 */
function prowp_panel_db_version_option() {
	return 'prowp_panel_db_version';
}

/**
 * Option that records the one-time featured-flag copy from the panel select.
 *
 * @return string
 */
function prowp_panel_featured_migrated_option() {
	return 'prowp_panel_featured_migrated';
}

/**
 * Builder definitions for mah_project. Used to seed the CPT / taxonomy /
 * metabox store without touching the lawyer demo.
 *
 * @return array{cpt:array<string,mixed>,taxonomy:array<string,mixed>,metabox:array<string,mixed>}
 */
function prowp_panel_project_builder_seed() {
	return array(
		'cpt'      => array(
			'name'          => 'mah_project',
			'singular'      => 'Project',
			'plural'        => 'Projects',
			'slug'          => 'work',
			'menu_icon'     => 'dashicons-portfolio',
			'menu_position' => 26,
			'supports'      => array( 'title', 'editor', 'thumbnail', 'excerpt', 'page-attributes', 'revisions' ),
			'hierarchical'  => '',
			'has_archive'   => '',
			'public'        => '1',
			'show_in_rest'  => '1',
		),
		'taxonomy' => array(
			'name'              => 'mah_project_cat',
			'singular'          => 'Project category',
			'plural'            => 'Project categories',
			'slug'              => 'work-type',
			'post_types'        => array( 'mah_project' ),
			'hierarchical'      => '1',
			'show_admin_column' => '1',
			'show_in_rest'      => '1',
		),
		'metabox'  => array(
			'metabox_id'         => 'mah_project_fields',
			'metabox_title'      => 'Project details',
			'metabox_post_types' => array( 'mah_project' ),
			'metabox_priority'   => 'high',
			'metabox_context'    => 'normal',
			'metabox_fields'     => array(
				array(
					'field_id'    => '_mah_featured',
					'field_type'  => 'switcher',
					'field_title' => 'Featured on home page',
					'field_desc'  => 'On: this project can appear as the home featured piece. Lower Priority shows first.',
					'field_default' => '',
				),
				array(
					'field_id'      => '_mah_priority',
					'field_type'    => 'number',
					'field_title'   => 'Priority (lower number shows first)',
					'field_default' => 0,
				),
				array(
					'field_id'    => '_mah_client',
					'field_type'  => 'text',
					'field_title' => 'Client',
				),
				array(
					'field_id'    => '_mah_url',
					'field_type'  => 'url',
					'field_title' => 'Project URL',
				),
				array(
					'field_id'    => '_mah_tags_line',
					'field_type'  => 'text',
					'field_title' => 'Services / tags',
				),
				array(
					'field_id'    => '_mah_services',
					'field_type'  => 'text',
					'field_title' => 'Services',
				),
				array(
					'field_id'    => '_mah_role',
					'field_type'  => 'textarea',
					'field_title' => 'My role',
				),
				array(
					'field_id'    => '_mah_challenge',
					'field_type'  => 'textarea',
					'field_title' => 'The challenge',
				),
				array(
					'field_id'    => '_mah_outcome',
					'field_type'  => 'textarea',
					'field_title' => 'The outcome',
				),
			),
		),
	);
}

/**
 * Builder definitions for mah_review. Quote is the post content.
 *
 * @return array{cpt:array<string,mixed>,taxonomy:array<string,mixed>,metabox:array<string,mixed>}
 */
function prowp_panel_review_builder_seed() {
	return array(
		'cpt'      => array(
			'name'          => 'mah_review',
			'singular'      => 'Review',
			'plural'        => 'Reviews',
			'slug'          => 'review',
			'menu_icon'     => 'dashicons-format-quote',
			'menu_position' => 27,
			'supports'      => array( 'title', 'editor', 'page-attributes', 'revisions' ),
			'hierarchical'  => '',
			'has_archive'   => '',
			'public'        => '',
			'show_in_rest'  => '1',
		),
		'taxonomy' => array(),
		'metabox'  => array(
			'metabox_id'         => 'mah_review_fields',
			'metabox_title'      => 'Review details',
			'metabox_post_types' => array( 'mah_review' ),
			'metabox_priority'   => 'high',
			'metabox_context'    => 'normal',
			'metabox_fields'     => array(
				array(
					'field_id'       => '_mah_author',
					'field_type'     => 'text',
					'field_title'    => 'Reviewer name',
					'field_desc'     => 'Required on the front end. Empty or whitespace names are never shown.',
					'field_required' => '1',
				),
				array(
					'field_id'    => '_mah_role',
					'field_type'  => 'text',
					'field_title' => 'Role / company',
				),
				array(
					'field_id'    => '_mah_rating',
					'field_type'  => 'number',
					'field_title' => 'Rating (1–5, empty = no stars)',
					'min'         => 1,
					'max'         => 5,
					'field_desc'  => 'Leave empty for no stars. Never stored as 5 unless you type 5.',
				),
				array(
					'field_id'               => '_mah_project',
					'field_type'             => 'select',
					'field_title'            => 'Related project',
					'field_placeholder'      => 'None',
					'field_query_post_type'  => 'mah_project',
				),
				array(
					'field_id'    => '_mah_source',
					'field_type'  => 'url',
					'field_title' => 'Source URL',
					'field_desc'  => 'Rendered only when the URL is http or https.',
				),
				array(
					'field_id'      => '_mah_priority',
					'field_type'    => 'number',
					'field_title'   => 'Priority (lower number shows first)',
					'field_default' => 0,
				),
				array(
					'field_id'      => '_mah_show_home',
					'field_type'    => 'switcher',
					'field_title'   => 'Show on home page',
					'field_default' => '1',
				),
			),
		),
	);
}

/**
 * Whether a builder group row already owns this slug/id.
 *
 * @param array<int,mixed> $rows Group rows.
 * @param string           $key  Row key.
 * @param string           $want Expected value.
 * @return bool
 */
function prowp_panel_builder_row_exists( array $rows, $key, $want ) {
	$want = (string) $want;

	foreach ( $rows as $row ) {
		if ( ! is_array( $row ) ) {
			continue;
		}

		if ( isset( $row[ $key ] ) && (string) $row[ $key ] === $want ) {
			return true;
		}
	}

	return false;
}

/**
 * Merge the mah_project seed into a panel options array.
 *
 * Idempotent: existing CPT / taxonomy / metabox rows with the same slug are
 * left untouched so owner edits win. The lawyer demo is never removed.
 *
 * @param array<string,mixed> $options Stored muhamed_ahmed_panel value.
 * @return array{options:array<string,mixed>,changed:bool}
 */
function prowp_panel_merge_builder_seed( array $options, array $seed ) {
	$changed = false;

	if ( empty( $options['custom_post_types'] ) || ! is_array( $options['custom_post_types'] ) ) {
		$options['custom_post_types'] = array();
	}

	if ( empty( $options['custom_taxonomies'] ) || ! is_array( $options['custom_taxonomies'] ) ) {
		$options['custom_taxonomies'] = array();
	}

	if ( empty( $options['custom_metaboxes'] ) || ! is_array( $options['custom_metaboxes'] ) ) {
		$options['custom_metaboxes'] = array();
	}

	if ( ! empty( $seed['cpt']['name'] ) && ! prowp_panel_builder_row_exists( $options['custom_post_types'], 'name', $seed['cpt']['name'] ) ) {
		$options['custom_post_types'][] = $seed['cpt'];
		$changed                        = true;
	}

	if ( ! empty( $seed['taxonomy']['name'] ) && ! prowp_panel_builder_row_exists( $options['custom_taxonomies'], 'name', $seed['taxonomy']['name'] ) ) {
		$options['custom_taxonomies'][] = $seed['taxonomy'];
		$changed                        = true;
	}

	$metabox_id = isset( $seed['metabox']['metabox_id'] ) ? (string) $seed['metabox']['metabox_id'] : '';
	$metabox_i  = null;

	if ( '' !== $metabox_id ) {
		foreach ( $options['custom_metaboxes'] as $index => $row ) {
			if ( is_array( $row ) && isset( $row['metabox_id'] ) && $metabox_id === (string) $row['metabox_id'] ) {
				$metabox_i = (int) $index;
				break;
			}
		}

		if ( null === $metabox_i ) {
			$options['custom_metaboxes'][] = $seed['metabox'];
			$changed                       = true;
		} elseif ( ! empty( $seed['metabox']['metabox_fields'] ) && is_array( $seed['metabox']['metabox_fields'] ) ) {
			$fields = isset( $options['custom_metaboxes'][ $metabox_i ]['metabox_fields'] ) && is_array( $options['custom_metaboxes'][ $metabox_i ]['metabox_fields'] )
				? $options['custom_metaboxes'][ $metabox_i ]['metabox_fields']
				: array();

			foreach ( $seed['metabox']['metabox_fields'] as $field ) {
				if ( prowp_panel_builder_row_exists( $fields, 'field_id', $field['field_id'] ) ) {
					continue;
				}

				$fields[] = $field;
				$changed  = true;
			}

			$options['custom_metaboxes'][ $metabox_i ]['metabox_fields'] = $fields;
		}
	}

	return array(
		'options' => $options,
		'changed' => $changed,
	);
}

/**
 * Merge the mah_project seed into a panel options array.
 *
 * Idempotent: existing CPT / taxonomy / metabox rows with the same slug are
 * left untouched so owner edits win. The lawyer demo is never removed.
 *
 * @param array<string,mixed> $options Stored muhamed_ahmed_panel value.
 * @return array{options:array<string,mixed>,changed:bool}
 */
function prowp_panel_merge_project_builder( array $options ) {
	return prowp_panel_merge_builder_seed( $options, prowp_panel_project_builder_seed() );
}

/**
 * Merge the mah_review seed into a panel options array.
 *
 * @param array<string,mixed> $options Stored muhamed_ahmed_panel value.
 * @return array{options:array<string,mixed>,changed:bool}
 */
function prowp_panel_merge_review_builder( array $options ) {
	return prowp_panel_merge_builder_seed( $options, prowp_panel_review_builder_seed() );
}

/**
 * Builder definitions for mah_service highlight switcher.
 *
 * @return array{cpt:array<string,mixed>,taxonomy:array<string,mixed>,metabox:array<string,mixed>}
 */
function prowp_panel_service_builder_seed() {
	return array(
		'cpt'      => array(
			'name'          => 'mah_service',
			'singular'      => 'Service',
			'plural'        => 'Services',
			'slug'          => 'service',
			'menu_icon'     => 'dashicons-hammer',
			'menu_position' => 28,
			'supports'      => array( 'title', 'editor', 'excerpt', 'page-attributes', 'revisions' ),
			'hierarchical'  => '',
			'has_archive'   => '',
			'public'        => '',
			'show_in_rest'  => '1',
		),
		'taxonomy' => array(),
		'metabox'  => array(
			'metabox_id'         => 'mah_service_fields',
			'metabox_title'      => 'Service details',
			'metabox_post_types' => array( 'mah_service' ),
			'metabox_priority'   => 'high',
			'metabox_context'    => 'side',
			'metabox_fields'     => array(
				array(
					'field_id'      => '_mah_highlight',
					'field_type'    => 'switcher',
					'field_title'   => 'Highlight',
					'field_desc'    => 'On: this service uses the single lime highlight. Default off.',
					'field_default' => '',
				),
			),
		),
	);
}

/**
 * Merge the mah_service seed into a panel options array.
 *
 * @param array<string,mixed> $options Stored muhamed_ahmed_panel value.
 * @return array{options:array<string,mixed>,changed:bool}
 */
function prowp_panel_merge_service_builder( array $options ) {
	return prowp_panel_merge_builder_seed( $options, prowp_panel_service_builder_seed() );
}

/**
 * Seed mah_project into the builder store without overwriting owner rows.
 *
 * @return bool Whether the option was written.
 */
function prowp_panel_seed_project_builder() {
	return prowp_panel_seed_builder_types();
}

/**
 * Seed mah_project and mah_review into the builder store without overwriting owner rows.
 *
 * @return bool Whether the option was written.
 */
function prowp_panel_seed_builder_types() {
	$stored  = get_option( 'muhamed_ahmed_panel', array() );
	$stored  = is_array( $stored ) ? $stored : array();
	$project = prowp_panel_merge_project_builder( $stored );
	$review  = prowp_panel_merge_review_builder( $project['options'] );
	$service = prowp_panel_merge_service_builder( $review['options'] );
	$changed = $project['changed'] || $review['changed'] || $service['changed'];

	if ( ! $changed ) {
		return false;
	}

	update_option( 'muhamed_ahmed_panel', $service['options'], false );

	return true;
}

/**
 * Attachment id of the owner portrait already in the media library.
 *
 * Source of truth is option mah_portrait_id (Site Content → Portrait).
 * Filename candidates match snapshot.json when that option is empty.
 *
 * @return int
 */
function prowp_panel_find_portrait_attachment_id() {
	$current = absint( get_option( 'mah_portrait_id', 0 ) );

	if ( $current > 0 && function_exists( 'wp_attachment_is_image' ) && wp_attachment_is_image( $current ) ) {
		return $current;
	}

	$names = array(
		'Me1.jpg',
		'Me1.jpeg',
		'336719916_610093031025106_2089673755479430871_n.jpg',
		'portrait.jpg',
	);

	foreach ( $names as $name ) {
		$found = get_posts(
			array(
				'post_type'      => 'attachment',
				'post_status'    => 'inherit',
				'posts_per_page' => 1,
				'fields'         => 'ids',
				'no_found_rows'  => true,
				'meta_query'     => array(
					array(
						'key'     => '_wp_attached_file',
						'value'   => $name,
						'compare' => 'LIKE',
					),
				),
			)
		);

		if ( ! empty( $found[0] ) ) {
			return absint( $found[0] );
		}
	}

	return 0;
}

/**
 * Copy the current portrait into the hero image option when it is empty.
 *
 * Idempotent: never overwrites a set hero image.
 *
 * @return void
 */
function prowp_panel_migrate_hero_image() {
	$existing = absint( get_option( 'mah_home_hero_image', 0 ) );

	if ( $existing > 0 && function_exists( 'wp_attachment_is_image' ) && wp_attachment_is_image( $existing ) ) {
		return;
	}

	$found = prowp_panel_find_portrait_attachment_id();

	if ( $found > 0 ) {
		update_option( 'mah_home_hero_image', $found, false );
	}
}

/**
 * Copy mah_home_featured_project onto _mah_featured once, if nothing is featured.
 *
 * @return void
 */
function prowp_panel_migrate_featured_flag() {
	if ( get_option( prowp_panel_featured_migrated_option() ) ) {
		return;
	}

	$fallback = absint( get_option( 'mah_home_featured_project', 0 ) );

	if ( $fallback > 0 && function_exists( 'muhamedahmed_projects_has_featured_flag' ) && ! muhamedahmed_projects_has_featured_flag() ) {
		$post = get_post( $fallback );

		if ( $post instanceof WP_Post && 'mah_project' === $post->post_type ) {
			update_post_meta( $fallback, '_mah_featured', 1 );

			if ( ! metadata_exists( 'post', $fallback, '_mah_priority' ) ) {
				update_post_meta( $fallback, '_mah_priority', 0 );
			}
		}
	}

	update_option( prowp_panel_featured_migrated_option(), prowp_panel_db_version() );
}

/**
 * Apply pending DB upgrades. Safe to call on every request; no-ops when current.
 *
 * @return void
 */
function prowp_panel_maybe_upgrade() {
	$current = (string) get_option( prowp_panel_db_version_option(), '' );

	if ( $current !== prowp_panel_db_version() ) {
		prowp_panel_seed_project_builder();
		prowp_panel_fill_home6_defaults();
		update_option( prowp_panel_db_version_option(), prowp_panel_db_version() );
	}

	prowp_panel_migrate_featured_flag();
	prowp_panel_migrate_hero_image();

	if ( function_exists( 'muhamedahmed_i18n_register_all' ) ) {
		muhamedahmed_i18n_register_all();
	}
}

/**
 * Fill empty HOME-6 copy options. Never overwrites a stored value.
 *
 * @return void
 */
function prowp_panel_fill_home6_defaults() {
	$defaults = array(
		'mah_home_hero_heading'     => 'WordPress websites that look sharp, load fast, and convert.',
		'mah_cta_secondary'         => 'Explore selected work',
		'mah_home_work_case_label'  => 'View case study',
		'mah_nav_work'              => 'Work',
		'mah_nav_services'          => 'Services',
		'mah_nav_process'           => 'Process',
		'mah_nav_about'             => 'About',
		'mah_nav_reviews'           => 'Reviews',
		'mah_home_hero_visual'      => 'both',
		'mah_home_strip_style'      => 'facts',
	);

	foreach ( $defaults as $key => $value ) {
		if ( function_exists( 'muhamedahmed_home_fill_empty_option' ) ) {
			muhamedahmed_home_fill_empty_option( $key, $value );
			continue;
		}

		$current = get_option( $key, '' );

		if ( is_scalar( $current ) && '' !== trim( (string) $current ) ) {
			continue;
		}

		update_option( $key, $value );
	}
}

/**
 * Service highlight meta even if the content module was skipped this request.
 *
 * @return void
 */
function prowp_panel_register_service_highlight_meta() {
	if ( ! function_exists( 'register_post_meta' ) ) {
		return;
	}

	register_post_meta(
		'mah_service',
		'_mah_highlight',
		array(
			'type'              => 'boolean',
			'single'            => true,
			'show_in_rest'      => true,
			'sanitize_callback' => 'rest_sanitize_boolean',
			'auth_callback'     => function_exists( 'mah_project_meta_auth' ) ? 'mah_project_meta_auth' : null,
			'default'           => false,
		)
	);
}
add_action( 'init', 'prowp_panel_register_service_highlight_meta', 12 );
