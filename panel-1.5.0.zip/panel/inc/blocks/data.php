<?php
/**
 * Panel and CPT readers for homepage blocks.
 *
 * Wraps mah-content helpers when they exist so option keys are not read twice.
 * Same option keys as the panel / mah-content store. Never invents copy.
 *
 * @package MuhamedAhmed_Blocks
 */

defined( 'ABSPATH' ) || exit;

/**
 * Identity field defaults used when mah-content is not loaded.
 *
 * @return array<string,string>
 */
function muhamedahmed_identity_fields() {
	return array(
		'full_name'     => '',
		'role'          => '',
		'tagline'       => '',
		'bio'           => '',
		'email'         => '',
		'phone'         => '',
		'whatsapp'      => '',
		'location'      => '',
		'response_time' => '',
		'availability'  => '',
		'available'     => '',
		'cta_label'     => '',
		'cta_action'    => 'mailto',
		'cta_target'    => '',
	);
}

/**
 * Read one identity field.
 *
 * @param string $key Field key.
 * @return string
 */
function muhamedahmed_identity( $key ) {
	if ( function_exists( 'mah_content_identity' ) ) {
		$value = mah_content_identity( $key );

		return is_scalar( $value ) ? (string) $value : '';
	}

	$stored = get_option( 'mah_identity', array() );

	if ( ! is_array( $stored ) ) {
		$stored = array();
	}

	$fields = muhamedahmed_identity_fields();

	if ( isset( $stored[ $key ] ) && '' !== $stored[ $key ] && null !== $stored[ $key ] ) {
		$value = is_scalar( $stored[ $key ] ) ? (string) $stored[ $key ] : '';
	} else {
		$value = isset( $fields[ $key ] ) ? (string) $fields[ $key ] : '';
	}

	if ( function_exists( 'muhamedahmed_i18n_identity_value' ) ) {
		return muhamedahmed_i18n_identity_value( $key, $value );
	}

	return $value;
}

/**
 * Display name, falling back to the WordPress site title.
 *
 * @return string
 */
function muhamedahmed_name() {
	if ( function_exists( 'mah_identity_name' ) ) {
		return mah_identity_name();
	}

	$name = muhamedahmed_identity( 'full_name' );

	return $name ? $name : get_bloginfo( 'name', 'display' );
}

/**
 * Tagline from identity only. Never falls back to the site description.
 *
 * @return string
 */
function muhamedahmed_tagline() {
	return muhamedahmed_identity( 'tagline' );
}

/**
 * Whether the availability pill should render.
 *
 * Requires both a non-empty availability string and a truthy available flag.
 *
 * @return bool
 */
function muhamedahmed_is_available() {
	$text = muhamedahmed_identity( 'availability' );

	if ( '' === $text ) {
		return false;
	}

	$flag = strtolower( muhamedahmed_identity( 'available' ) );

	return '' !== $flag && '0' !== $flag && 'false' !== $flag;
}

/**
 * Primary CTA URI from stored identity.
 *
 * @return string
 */
function muhamedahmed_primary_uri() {
	if ( function_exists( 'mah_content_primary_uri' ) ) {
		return mah_content_primary_uri();
	}

	$action = muhamedahmed_identity( 'cta_action' );

	switch ( $action ) {
		case 'tel':
			$phone = preg_replace( '/[^0-9+]/', '', muhamedahmed_identity( 'phone' ) );

			return $phone ? 'tel:' . $phone : '';

		case 'wa':
			$wa = preg_replace( '/[^0-9]/', '', muhamedahmed_identity( 'whatsapp' ) );

			return $wa ? 'https://wa.me/' . $wa : '';

		case 'link':
			$target = muhamedahmed_identity( 'cta_target' );

			return function_exists( 'muhamedahmed_permalink' ) ? muhamedahmed_permalink( $target ) : $target;

		case 'mailto':
		default:
			$email = muhamedahmed_identity( 'email' );

			return $email ? 'mailto:' . $email : '';
	}
}

/**
 * Section jump links.
 *
 * @return array<int,array{label:string,href:string}>
 */
function muhamedahmed_section_links() {
	if ( function_exists( 'mah_content_section_links' ) ) {
		return mah_content_section_links();
	}

	$links = get_option( 'mah_section_links', array() );

	if ( ! is_array( $links ) || ! $links ) {
		return array();
	}

	$clean = array();

	foreach ( $links as $link ) {
		if ( ! is_array( $link ) ) {
			continue;
		}

		$label = isset( $link['label'] ) ? sanitize_text_field( $link['label'] ) : '';
		$href  = isset( $link['href'] ) ? esc_url_raw( $link['href'] ) : '';

		if ( '' === $label ) {
			continue;
		}

		$idx = count( $clean );

		if ( function_exists( 'muhamedahmed_t' ) ) {
			$label = muhamedahmed_t( $label, 'mah_section_links.' . $idx . '.label' );
		}

		if ( function_exists( 'muhamedahmed_permalink' ) ) {
			$href = muhamedahmed_permalink( $href );
		}

		$clean[] = array(
			'label' => $label,
			'href'  => $href,
		);
	}

	return $clean;
}

/**
 * Process steps from mah_process.
 *
 * @return array<int,array{title:string,text:string}>
 */
function muhamedahmed_process_steps() {
	if ( function_exists( 'mah_content_process_steps' ) ) {
		return mah_content_process_steps();
	}

	$rows = get_option( 'mah_process', array() );

	if ( ! is_array( $rows ) || ! $rows ) {
		return array();
	}

	$clean = array();

	foreach ( $rows as $row ) {
		$title = '';
		$text  = '';

		if ( is_array( $row ) ) {
			$title = isset( $row['title'] ) ? $row['title'] : ( isset( $row[0] ) ? $row[0] : '' );
			$text  = isset( $row['text'] ) ? $row['text'] : ( isset( $row[1] ) ? $row[1] : '' );
		}

		if ( '' === trim( (string) $title ) ) {
			continue;
		}

		$title = sanitize_text_field( $title );
		$text  = sanitize_textarea_field( $text );
		$idx   = count( $clean );

		if ( function_exists( 'muhamedahmed_t' ) ) {
			$title = muhamedahmed_t( $title, 'mah_process.' . $idx . '.0' );
			$text  = muhamedahmed_t( $text, 'mah_process.' . $idx . '.1' );
		}

		$clean[] = array(
			'title' => $title,
			'text'  => $text,
		);
	}

	return $clean;
}

/**
 * Stored statistics. Empty option stays empty — never seeded here.
 *
 * @return array<int,array{value:string,label:string}>
 */
function muhamedahmed_stats() {
	if ( function_exists( 'mah_content_stats' ) ) {
		return mah_content_stats();
	}

	$rows = get_option( 'mah_stats', array() );

	if ( ! is_array( $rows ) || ! $rows ) {
		return array();
	}

	$clean = array();

	foreach ( $rows as $row ) {
		$value = '';
		$label = '';

		if ( is_array( $row ) ) {
			$value = isset( $row['value'] ) ? $row['value'] : ( isset( $row[0] ) ? $row[0] : '' );
			$label = isset( $row['label'] ) ? $row['label'] : ( isset( $row[1] ) ? $row[1] : '' );
		}

		if ( '' === trim( (string) $value ) ) {
			continue;
		}

		$value = sanitize_text_field( $value );
		$label = sanitize_textarea_field( $label );
		$idx   = count( $clean );

		if ( function_exists( 'muhamedahmed_t' ) ) {
			$value = muhamedahmed_t( $value, 'mah_stats.' . $idx . '.0' );
			$label = muhamedahmed_t( $label, 'mah_stats.' . $idx . '.1' );
		}

		$clean[] = array(
			'value' => $value,
			'label' => $label,
		);
	}

	return $clean;
}

/**
 * Normalise a stored string or row list into trimmed phrases.
 *
 * @param mixed $rows Option value.
 * @return array<int,string>
 */
function muhamedahmed_string_list( $rows ) {
	if ( is_string( $rows ) ) {
		$rows = preg_split( '/\r\n|\r|\n/', $rows );
	}

	if ( ! is_array( $rows ) ) {
		return array();
	}

	$clean = array();

	foreach ( $rows as $row ) {
		if ( is_array( $row ) ) {
			$row = isset( $row['phrase'] ) ? $row['phrase'] : ( isset( $row[0] ) ? $row[0] : '' );
		}

		$row = sanitize_text_field( (string) $row );

		if ( '' !== $row ) {
			$clean[] = $row;
		}
	}

	return $clean;
}

/**
 * Marquee phrases from mah_marquee_phrases.
 *
 * @return array<int,string>
 */
function muhamedahmed_marquee_phrases() {
	$phrases = muhamedahmed_string_list( get_option( 'mah_marquee_phrases', array() ) );

	if ( ! function_exists( 'muhamedahmed_t' ) ) {
		return $phrases;
	}

	$out = array();

	foreach ( $phrases as $index => $phrase ) {
		$out[] = muhamedahmed_t( $phrase, 'mah_marquee_phrases.' . (int) $index );
	}

	return $out;
}

/**
 * About points, one per line.
 *
 * @return array<int,string>
 */
function muhamedahmed_about_points() {
	$points = muhamedahmed_string_list( get_option( 'mah_about_points', array() ) );

	if ( ! function_exists( 'muhamedahmed_t' ) ) {
		return $points;
	}

	$out = array();

	foreach ( $points as $index => $point ) {
		$out[] = muhamedahmed_t( $point, 'mah_about_points.' . (int) $index );
	}

	return $out;
}

/**
 * Scalar option as sanitised text.
 *
 * @param string $key      Option name.
 * @param bool   $textarea Use textarea sanitising.
 * @return string
 */
function muhamedahmed_option_text( $key, $textarea = false ) {
	$raw = get_option( $key, '' );

	if ( ! is_scalar( $raw ) ) {
		return '';
	}

	$text = (string) $raw;
	$text = $textarea ? sanitize_textarea_field( $text ) : sanitize_text_field( $text );

	if ( function_exists( 'muhamedahmed_t' ) && function_exists( 'muhamedahmed_i18n_text_option_keys' ) && in_array( $key, muhamedahmed_i18n_text_option_keys(), true ) ) {
		return muhamedahmed_t( $text, $key );
	}

	return $text;
}

/**
 * Published posts of one of our types, bounded.
 *
 * @param string $type  Post type.
 * @param int    $count Max count.
 * @return array<int,WP_Post>
 */
function muhamedahmed_posts( $type, $count ) {
	$count = max( 1, min( 40, (int) $count ) );

	if ( 'mah_project' === $type && function_exists( 'muhamedahmed_projects_query_args' ) ) {
		$posts = get_posts(
			muhamedahmed_projects_query_args(
				array(
					'posts_per_page' => $count,
					'no_found_rows'  => true,
				)
			)
		);

		return is_array( $posts ) ? $posts : array();
	}

	return get_posts(
		array(
			'post_type'        => $type,
			'posts_per_page'   => $count,
			'orderby'          => 'menu_order',
			'order'            => 'ASC',
			'post_status'      => 'publish',
			'no_found_rows'    => true,
			'suppress_filters' => false,
		)
	);
}

/**
 * Read a _mah_* meta string.
 *
 * @param int    $post_id Post id.
 * @param string $key     Key without the _mah_ prefix.
 * @return string
 */
function muhamedahmed_meta( $post_id, $key ) {
	$value = get_post_meta( (int) $post_id, '_mah_' . $key, true );
	$value = is_scalar( $value ) ? (string) $value : '';

	if ( 'url' === $key && function_exists( 'muhamedahmed_permalink' ) ) {
		return muhamedahmed_permalink( $value );
	}

	if ( 'project' === $key && function_exists( 'muhamedahmed_object_id' ) ) {
		return (string) muhamedahmed_object_id( $value, 'mah_project', true );
	}

	return $value;
}

/**
 * Decode a stored meta line that was double-encoded or saved as mojibake.
 *
 * Featured tags used a UTF-8 middle dot that had been re-read as Latin-1
 * (`Â·`). Decode entities first, then replace that sequence with U+00B7.
 *
 * @param string $text Raw meta.
 * @return string
 */
function muhamedahmed_plain_meta_line( $text ) {
	$text = html_entity_decode( (string) $text, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
	$text = str_replace(
		array( "\xC3\x82\xC2\xB7", "\xC3\x82·", 'Â·' ),
		"\xC2\xB7",
		$text
	);

	return trim( $text );
}

/**
 * Logo markup, or empty.
 *
 * @param string $class Image class.
 * @return string
 */
function muhamedahmed_logo_html( $class = '' ) {
	if ( function_exists( 'mah_content_logo' ) ) {
		return mah_content_logo( 'full', $class );
	}

	$id = (int) get_option( 'mah_logo_id', 0 );

	if ( function_exists( 'muhamedahmed_object_id' ) ) {
		$id = muhamedahmed_object_id( $id, 'attachment', true );
	}

	if ( ! $id || ! wp_attachment_is_image( $id ) ) {
		return '';
	}

	return wp_get_attachment_image(
		$id,
		'full',
		false,
		array(
			'class'    => $class,
			'alt'      => muhamedahmed_name(),
			'loading'  => 'eager',
			'decoding' => 'async',
		)
	);
}

/**
 * Resolved portrait attachment id. Block override wins when greater than 0.
 *
 * @param int $override Block attribute.
 * @return int
 */
function muhamedahmed_portrait_id( $override = 0 ) {
	$override = (int) $override;

	if ( $override > 0 ) {
		$id = $override;
	} else {
		$id = (int) get_option( 'mah_portrait_id', 0 );
	}

	if ( function_exists( 'muhamedahmed_object_id' ) ) {
		$id = muhamedahmed_object_id( $id, 'attachment', true );
	}

	return $id;
}

/**
 * Clamp a focal-point percent to 0–100.
 *
 * @param mixed $value Raw value.
 * @param int   $fallback Default when empty.
 * @return int
 */
function muhamedahmed_focal_percent( $value, $fallback = 50 ) {
	if ( '' === $value || null === $value || false === $value ) {
		return max( 0, min( 100, (int) $fallback ) );
	}

	return max( 0, min( 100, absint( $value ) ) );
}

/**
 * Whether the hero image switcher is on. Default on.
 *
 * @return bool
 */
function muhamedahmed_home_hero_image_enabled() {
	$raw = get_option( 'mah_home_hero_show_image', '1' );

	if ( '0' === (string) $raw || 0 === $raw || false === $raw ) {
		return false;
	}

	return true;
}

/**
 * Hero image resolution: set (panel field), fallback (mah_portrait_id), or none.
 *
 * @return array{id:int,state:string,label:string}
 */
function muhamedahmed_home_hero_image_state() {
	$none = array(
		'id'    => 0,
		'state' => 'none',
		'label' => __( 'none', 'prowpsite-panel' ),
	);

	if ( ! muhamedahmed_home_hero_image_enabled() ) {
		return $none;
	}

	$set = absint( get_option( 'mah_home_hero_image', 0 ) );

	if ( function_exists( 'muhamedahmed_object_id' ) ) {
		$set = muhamedahmed_object_id( $set, 'attachment', true );
	}

	if ( $set > 0 && wp_attachment_is_image( $set ) ) {
		return array(
			'id'    => $set,
			'state' => 'set',
			'label' => __( 'set', 'prowpsite-panel' ),
		);
	}

	$fallback = muhamedahmed_portrait_id( 0 );

	if ( $fallback > 0 && wp_attachment_is_image( $fallback ) ) {
		return array(
			'id'    => $fallback,
			'state' => 'fallback',
			'label' => __( 'fallback', 'prowpsite-panel' ),
		);
	}

	return $none;
}

/**
 * Alt text for the hero image. Empty field uses the identity/site name.
 *
 * @return string
 */
function muhamedahmed_home_hero_image_alt() {
	$stored = get_option( 'mah_home_hero_alt', '' );
	$stored = is_scalar( $stored ) ? trim( (string) $stored ) : '';

	if ( '' !== $stored ) {
		return function_exists( 'muhamedahmed_t' ) ? muhamedahmed_t( $stored, 'mah_home_hero_alt' ) : $stored;
	}

	return muhamedahmed_name();
}

/**
 * object-position string from stored focal X/Y (default 50 / 35).
 *
 * @return string
 */
function muhamedahmed_home_hero_object_position() {
	$x = muhamedahmed_focal_percent( get_option( 'mah_home_hero_focal_x', 50 ), 50 );
	$y = muhamedahmed_focal_percent( get_option( 'mah_home_hero_focal_y', 35 ), 35 );

	return $x . '% ' . $y . '%';
}

/**
 * Portrait / hero image markup. Never a placeholder.
 *
 * @param string $class         Image class.
 * @param string $size          Image size.
 * @param int    $attachment_id Override id, or 0 to use the option.
 * @param string $alt           Alt text. Empty uses the identity name.
 * @param string $object_pos    CSS object-position. Empty uses the stored focal point.
 * @return string
 */
function muhamedahmed_portrait_html( $class = '', $size = 'large', $attachment_id = 0, $alt = '', $object_pos = '' ) {
	$id = (int) $attachment_id;

	if ( $id < 1 ) {
		$id = muhamedahmed_portrait_id( 0 );
	}

	if ( ! $id || ! wp_attachment_is_image( $id ) ) {
		return '';
	}

	$chosen = function_exists( 'muhamedahmed_usable_image_size' )
		? muhamedahmed_usable_image_size( $id, $size )
		: $size;
	$alt    = is_scalar( $alt ) ? trim( (string) $alt ) : '';

	if ( '' === $alt ) {
		$alt = muhamedahmed_name();
	}

	$object_pos = is_scalar( $object_pos ) ? trim( (string) $object_pos ) : '';

	if ( '' === $object_pos && function_exists( 'muhamedahmed_home_hero_object_position' ) ) {
		$object_pos = muhamedahmed_home_hero_object_position();
	}

	$attr = array(
		'class'         => $class,
		'alt'           => $alt,
		'loading'       => 'eager',
		'decoding'      => 'async',
		'fetchpriority' => 'high',
		'sizes'         => '(min-width: 1024px) 480px, min(100vw, 360px)',
	);

	if ( '' !== $object_pos ) {
		$attr['style'] = 'object-position: ' . $object_pos;
	}

	return wp_get_attachment_image( $id, $chosen, false, $attr );
}

/**
 * Published project count from the CPT.
 *
 * @return int
 */
function muhamedahmed_project_publish_count() {
	$counts = wp_count_posts( 'mah_project' );

	if ( ! $counts || ! isset( $counts->publish ) ) {
		return 0;
	}

	return (int) $counts->publish;
}

/**
 * Select options for the featured project field.
 *
 * @return array<string,string>
 */
function muhamedahmed_project_choices() {
	$choices = array(
		'0' => __( 'First published project', 'prowpsite-panel' ),
	);

	if ( ! post_type_exists( 'mah_project' ) ) {
		return $choices;
	}

	$posts = function_exists( 'muhamedahmed_projects_query_args' )
		? get_posts(
			muhamedahmed_projects_query_args(
				array(
					'posts_per_page' => 40,
					'no_found_rows'  => true,
				)
			)
		)
		: get_posts(
			array(
				'post_type'        => 'mah_project',
				'posts_per_page'   => 40,
				'orderby'          => 'menu_order',
				'order'            => 'ASC',
				'post_status'      => 'publish',
				'no_found_rows'    => true,
				'suppress_filters' => false,
			)
		);

	foreach ( $posts as $project ) {
		$title = get_the_title( $project );

		if ( '' === $title ) {
			continue;
		}

		$choices[ (string) $project->ID ] = $title;
	}

	return $choices;
}

/**
 * Projects archive URL, or empty when the type has no archive.
 *
 * @return string
 */
function muhamedahmed_work_archive_url() {
	$url = get_post_type_archive_link( 'mah_project' );

	return is_string( $url ) ? $url : '';
}
