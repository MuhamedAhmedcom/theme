<?php
/**
 * Front-page home renderer and one-time copy migration.
 *
 * The child theme calls muhamedahmed_render_home(). Blocks keep the same
 * inner markup functions so old page content still renders.
 *
 * @package MuhamedAhmed_Blocks
 */

defined( 'ABSPATH' ) || exit;

/**
 * Option that records the HOME-3 copy migration.
 *
 * @return string
 */
function muhamedahmed_home_migration_option() {
	return 'mah_home_copy_migrated';
}

/**
 * Section keys in the default order.
 *
 * @return array<int,string>
 */
function muhamedahmed_home_section_keys() {
	return array(
		'hero',
		'marquee',
		'stats',
		'services',
		'work',
		'process',
		'about',
		'reviews',
		'contact',
	);
}

/**
 * Admin labels for the sorter. UI chrome, not business copy.
 *
 * @return array<string,string>
 */
function muhamedahmed_home_section_labels() {
	return array(
		'hero'     => __( 'Hero', 'prowpsite-panel' ),
		'marquee'  => __( 'Marquee', 'prowpsite-panel' ),
		'stats'    => __( 'Stats', 'prowpsite-panel' ),
		'services' => __( 'Services', 'prowpsite-panel' ),
		'work'     => __( 'Work', 'prowpsite-panel' ),
		'process'  => __( 'Process', 'prowpsite-panel' ),
		'about'    => __( 'About', 'prowpsite-panel' ),
		'reviews'  => __( 'Reviews', 'prowpsite-panel' ),
		'contact'  => __( 'Contact', 'prowpsite-panel' ),
	);
}

/**
 * Default sorter value: every section enabled, in spec order.
 *
 * @return array{enabled:array<string,string>,disabled:array<string,string>}
 */
function muhamedahmed_home_layout_default() {
	return array(
		'enabled'  => muhamedahmed_home_section_labels(),
		'disabled' => array(),
	);
}

/**
 * Sanitize a sorter payload. Unknown keys are dropped; missing keys go to disabled.
 *
 * @param mixed $raw Stored value.
 * @return array{enabled:array<string,string>,disabled:array<string,string>}
 */
function muhamedahmed_sanitize_home_layout( $raw ) {
	$labels = muhamedahmed_home_section_labels();
	$keys   = array_keys( $labels );
	$out    = array(
		'enabled'  => array(),
		'disabled' => array(),
	);

	if ( ! is_array( $raw ) ) {
		return muhamedahmed_home_layout_default();
	}

	foreach ( array( 'enabled', 'disabled' ) as $bucket ) {
		if ( empty( $raw[ $bucket ] ) || ! is_array( $raw[ $bucket ] ) ) {
			continue;
		}

		foreach ( $raw[ $bucket ] as $key => $label ) {
			$key = sanitize_key( (string) $key );

			if ( ! in_array( $key, $keys, true ) ) {
				continue;
			}

			$out[ $bucket ][ $key ] = isset( $labels[ $key ] ) ? $labels[ $key ] : sanitize_text_field( (string) $label );
		}
	}

	foreach ( $keys as $key ) {
		if ( isset( $out['enabled'][ $key ] ) || isset( $out['disabled'][ $key ] ) ) {
			continue;
		}

		if ( isset( $raw['enabled'] ) && is_array( $raw['enabled'] ) ) {
			$out['disabled'][ $key ] = $labels[ $key ];
		} else {
			$out['enabled'][ $key ] = $labels[ $key ];
		}
	}

	if ( ! $out['enabled'] && ! $out['disabled'] ) {
		return muhamedahmed_home_layout_default();
	}

	return $out;
}

/**
 * Stored layout, or the default.
 *
 * @return array{enabled:array<string,string>,disabled:array<string,string>}
 */
function muhamedahmed_home_layout() {
	return muhamedahmed_sanitize_home_layout( get_option( 'mah_home_layout', array() ) );
}

/**
 * Enabled section keys in display order.
 *
 * @return array<int,string>
 */
function muhamedahmed_home_enabled_sections() {
	$layout = muhamedahmed_home_layout();
	$keys   = array();

	foreach ( array_keys( $layout['enabled'] ) as $key ) {
		$keys[] = $key;
	}

	return $keys;
}

/**
 * Map a block anchor to a home section key.
 *
 * @param string $anchor Block anchor.
 * @return string
 */
function muhamedahmed_home_anchor_key( $anchor ) {
	$anchor = sanitize_key( $anchor );
	$map    = array(
		'top'     => 'hero',
		'hero'    => 'hero',
		'marquee' => 'marquee',
		'proof'   => 'stats',
		'numbers' => 'stats',
		'stats'   => 'stats',
		'services'=> 'services',
		'work'    => 'work',
		'process' => 'process',
		'about'   => 'about',
		'reviews' => 'reviews',
		'contact' => 'contact',
	);

	return isset( $map[ $anchor ] ) ? $map[ $anchor ] : '';
}

/**
 * HTML id for a home section.
 *
 * @param string $key Section key.
 * @return string
 */
function muhamedahmed_home_section_id( $key ) {
	$ids = array(
		'hero'     => 'top',
		'marquee'  => 'marquee',
		'stats'    => 'proof',
		'services' => 'services',
		'work'     => 'work',
		'process'  => 'process',
		'about'    => 'about',
		'reviews'  => 'reviews',
		'contact'  => 'contact',
	);

	return isset( $ids[ $key ] ) ? $ids[ $key ] : sanitize_html_class( $key );
}

/**
 * Panel copy for one section. Empty strings mean "do not render".
 *
 * @param string $key Section key.
 * @return array{eyebrow:string,heading:string,intro:string}
 */
function muhamedahmed_home_copy( $key ) {
	$key = sanitize_key( $key );

	return array(
		'eyebrow' => muhamedahmed_option_text( 'mah_home_' . $key . '_eyebrow' ),
		'heading' => muhamedahmed_option_text( 'mah_home_' . $key . '_heading' ),
		'intro'   => muhamedahmed_option_text( 'mah_home_' . $key . '_intro', true ),
	);
}

/**
 * Write an option only when it is currently empty.
 *
 * @param string $key   Option name.
 * @param string $value New value.
 * @return void
 */
function muhamedahmed_home_fill_empty_option( $key, $value ) {
	$value = trim( (string) $value );

	if ( '' === $value ) {
		return;
	}

	$current = get_option( $key, '' );

	if ( is_scalar( $current ) && '' !== trim( (string) $current ) ) {
		return;
	}

	update_option( $key, sanitize_text_field( $value ) );
}

/**
 * Walk parsed blocks and copy eyebrows/headings into empty home-copy options.
 *
 * @param array  $blocks Parsed blocks.
 * @param string $key    Current section key.
 * @return void
 */
function muhamedahmed_home_migrate_blocks( array $blocks, $key = '' ) {
	foreach ( $blocks as $block ) {
		if ( ! is_array( $block ) ) {
			continue;
		}

		$name  = isset( $block['blockName'] ) ? (string) $block['blockName'] : '';
		$attrs = isset( $block['attrs'] ) && is_array( $block['attrs'] ) ? $block['attrs'] : array();
		$inner = isset( $block['innerBlocks'] ) && is_array( $block['innerBlocks'] ) ? $block['innerBlocks'] : array();
		$next  = $key;

		if ( 'muhamedahmed/section' === $name ) {
			$anchor = isset( $attrs['anchor'] ) ? (string) $attrs['anchor'] : '';
			$mapped = muhamedahmed_home_anchor_key( $anchor );
			$next   = $mapped ? $mapped : $key;

			if ( $next && ! empty( $attrs['eyebrow'] ) ) {
				muhamedahmed_home_fill_empty_option( 'mah_home_' . $next . '_eyebrow', (string) $attrs['eyebrow'] );
			}
		} elseif ( 'muhamedahmed/about' === $name ) {
			$next = 'about';

			if ( ! empty( $attrs['eyebrow'] ) ) {
				muhamedahmed_home_fill_empty_option( 'mah_home_about_eyebrow', (string) $attrs['eyebrow'] );
			}
		} elseif ( 'muhamedahmed/hero' === $name ) {
			$next = 'hero';

			if ( ! empty( $attrs['eyebrow'] ) ) {
				muhamedahmed_home_fill_empty_option( 'mah_home_hero_eyebrow', (string) $attrs['eyebrow'] );
			}
		} elseif ( 'core/heading' === $name && $key ) {
			$html = isset( $block['innerHTML'] ) ? (string) $block['innerHTML'] : '';
			$text = trim( wp_strip_all_tags( $html ) );

			if ( '' !== $text ) {
				muhamedahmed_home_fill_empty_option( 'mah_home_' . $key . '_heading', $text );
			}
		}

		if ( $inner ) {
			muhamedahmed_home_migrate_blocks( $inner, $next );
		}
	}
}

/**
 * One-time migration from the static front page's block markup.
 *
 * Never overwrites a home-copy option that already has a value. Runs once
 * per install after the panel version that introduced HOME-3.
 *
 * @return void
 */
function muhamedahmed_migrate_home_copy() {
	if ( get_option( muhamedahmed_home_migration_option() ) ) {
		return;
	}

	$page_id = (int) get_option( 'page_on_front', 0 );

	if ( $page_id <= 0 ) {
		return;
	}

	$page = get_post( $page_id );

	if ( ! $page instanceof WP_Post || ! $page->post_content ) {
		return;
	}

	$blocks = parse_blocks( $page->post_content );

	if ( is_array( $blocks ) ) {
		muhamedahmed_home_migrate_blocks( $blocks, '' );
	}

	update_option( muhamedahmed_home_migration_option(), defined( 'PROWP_VERSION' ) ? PROWP_VERSION : '1.3.0' );
}
add_action( 'init', 'muhamedahmed_migrate_home_copy', 30 );

/**
 * Section header: eyebrow, heading, intro. Empty heading is omitted.
 *
 * @param string $key Section key.
 * @return string
 */
function muhamedahmed_home_head_markup( $key ) {
	$copy = muhamedahmed_home_copy( $key );

	if ( '' === $copy['eyebrow'] && '' === $copy['heading'] && '' === $copy['intro'] ) {
		return '';
	}

	$html = '<header class="mah-sec__head">';

	if ( '' !== $copy['eyebrow'] ) {
		$html .= '<p class="mah-eyebrow">' . esc_html( $copy['eyebrow'] ) . '</p>';
	}

	if ( '' !== $copy['heading'] ) {
		$html .= sprintf(
			'<h2 id="mah-%s-title">%s</h2>',
			esc_attr( $key ),
			esc_html( $copy['heading'] )
		);
	}

	if ( '' !== $copy['intro'] ) {
		$html .= '<p class="mah-sec__intro">' . esc_html( $copy['intro'] ) . '</p>';
	}

	$html .= '</header>';

	return $html;
}

/**
 * Open a home section shell.
 *
 * @param string $key     Section key.
 * @param string $layout  band|ground|paper.
 * @param string $classes Extra classes.
 * @return string
 */
function muhamedahmed_home_section_open( $key, $layout, $classes = '' ) {
	$copy     = muhamedahmed_home_copy( $key );
	$id       = muhamedahmed_home_section_id( $key );
	$layout   = sanitize_html_class( $layout );
	$class    = trim( 'mah-sec mah-sec--' . $layout . ' mah-home mah-home--' . sanitize_html_class( $key ) . ' ' . $classes );
	$labelled = '';

	if ( '' !== $copy['heading'] ) {
		$labelled = ' aria-labelledby="mah-' . esc_attr( $key ) . '-title"';
	}

	return '<section id="' . esc_attr( $id ) . '" class="' . esc_attr( $class ) . '"' . $labelled . ' data-mah-section="' . esc_attr( $id ) . '" data-mah-reveal><div class="mah-shell">' . muhamedahmed_home_head_markup( $key );
}

/**
 * Close a home section shell.
 *
 * @return string
 */
function muhamedahmed_home_section_close() {
	return '</div></section>';
}

/**
 * Hero proof chips: first three stored stats.
 *
 * @return string
 */
function muhamedahmed_hero_proof_markup() {
	$stats = array_slice( muhamedahmed_stats(), 0, 3 );

	if ( ! $stats ) {
		return '';
	}

	$html = '<ul class="mah-hero__proof" aria-label="' . esc_attr__( 'Verified figures', 'prowpsite-panel' ) . '">';

	foreach ( $stats as $stat ) {
		$html .= '<li class="mah-hero__chip">';
		$html .= '<span class="mah-hero__chip-value">' . esc_html( $stat['value'] ) . '</span>';

		if ( '' !== $stat['label'] ) {
			$html .= '<span class="mah-hero__chip-label">' . esc_html( $stat['label'] ) . '</span>';
		}

		$html .= '</li>';
	}

	$html .= '</ul>';

	return $html;
}

/**
 * Featured project id: per-project Featured checkbox, else the panel fallback.
 *
 * @return int
 */
function muhamedahmed_home_featured_project_id() {
	if ( function_exists( 'muhamedahmed_projects_featured_id' ) ) {
		return muhamedahmed_projects_featured_id();
	}

	$id = absint( get_option( 'mah_home_featured_project', 0 ) );

	if ( function_exists( 'muhamedahmed_object_id' ) ) {
		$id = muhamedahmed_object_id( $id, 'mah_project', true );
	}

	return $id;
}

/**
 * Why the home renderer is active or not. Shown in Site Content > Home layout.
 *
 * @return array{active:bool,label:string,why:string}
 */
function muhamedahmed_home_renderer_status() {
	$active = function_exists( 'muhamedahmed_render_home' );
	$why    = array();

	if ( $active ) {
		$why[] = __( 'muhamedahmed_render_home is loaded and will replace the static front-page blocks after cache is purged.', 'prowpsite-panel' );
	} else {
		$why[] = __( 'muhamedahmed_render_home is not loaded.', 'prowpsite-panel' );
	}

	if ( function_exists( 'prowp_legacy_blocks_active' ) && prowp_legacy_blocks_active() ) {
		$why[] = __( 'Standalone plugin muhamed-ahmed-blocks is still active. Deactivate it so Panel owns the home blocks.', 'prowpsite-panel' );
	}

	if ( function_exists( 'prowp_legacy_content_active' ) && prowp_legacy_content_active() ) {
		$why[] = __( 'Standalone plugin mah-content is still active.', 'prowpsite-panel' );
	}

	if ( ! is_readable( get_stylesheet_directory() . '/front-page.php' ) ) {
		$why[] = __( 'Child theme front-page.php is missing; the_content filter will still swap the front page.', 'prowpsite-panel' );
	}

	if ( function_exists( 'muhamedahmed_home_hero_image_state' ) ) {
		$hero_state = muhamedahmed_home_hero_image_state();
		$why[]      = sprintf(
			/* translators: %s: set, fallback, or none. */
			__( 'Hero image: %s.', 'prowpsite-panel' ),
			$hero_state['label']
		);
	}

	return array(
		'active' => $active,
		'label'  => $active ? __( 'active', 'prowpsite-panel' ) : __( 'inactive', 'prowpsite-panel' ),
		'why'    => implode( ' ', $why ),
	);
}

/**
 * How many rail projects to show after the featured one.
 *
 * @return int
 */
function muhamedahmed_home_work_rail_count() {
	$count = absint( get_option( 'mah_home_work_rail', 6 ) );

	return max( 1, min( 20, $count ) );
}

/**
 * How many reviews to show.
 *
 * @return int
 */
function muhamedahmed_home_reviews_count() {
	$count = absint( get_option( 'mah_home_reviews_count', 6 ) );

	return max( 1, min( 20, $count ) );
}

/**
 * Home reviews order: priority, newest, or random.
 *
 * @return string
 */
function muhamedahmed_home_reviews_order() {
	$order = function_exists( 'muhamedahmed_reviews_normalize_order' )
		? muhamedahmed_reviews_normalize_order( get_option( 'mah_home_reviews_order', 'priority' ) )
		: 'priority';

	return $order;
}

/**
 * Whether the home reviews block uses only _mah_show_home reviews.
 *
 * @return bool
 */
function muhamedahmed_home_reviews_home_only() {
	$raw = get_option( 'mah_home_reviews_home_only', '1' );

	if ( '0' === (string) $raw || 0 === $raw || false === $raw ) {
		return false;
	}

	return true;
}

/**
 * Whether the hero should print the compact proof chips. Off by default so
 * the numbers band is the only stats surface.
 *
 * @return bool
 */
function muhamedahmed_home_hero_chips_enabled() {
	return (bool) absint( get_option( 'mah_home_hero_chips', 0 ) );
}

/**
 * Motion effect keys that each have an on/off switch and intensity select.
 *
 * @return array<int,string>
 */
function muhamedahmed_home_motion_keys() {
	return array( 'hero', 'reveals', 'stats', 'work', 'process', 'marquee', 'header', 'magnetic' );
}

/**
 * Stored motion map: effect => off|subtle|standard.
 *
 * @return array<string,string>
 */
function muhamedahmed_home_motion_config() {
	$map = array();

	foreach ( muhamedahmed_home_motion_keys() as $key ) {
		$fallback  = ( 'stats' === $key ) ? '0' : '1';
		$on        = get_option( 'mah_home_motion_' . $key, $fallback );
		$intensity = get_option( 'mah_home_motion_' . $key . '_intensity', 'standard' );

		if ( '0' === (string) $on || 0 === $on || false === $on ) {
			$map[ $key ] = 'off';
			continue;
		}

		$map[ $key ] = in_array( $intensity, array( 'subtle', 'standard' ), true ) ? $intensity : 'standard';
	}

	return $map;
}

/**
 * Stored switcher as bool. Missing option uses $default.
 *
 * @param string $key     Option name.
 * @param bool   $default Default when unset.
 * @return bool
 */
function muhamedahmed_option_is_on( $key, $default = true ) {
	$raw = get_option( $key, $default ? '1' : '0' );

	if ( '0' === (string) $raw || 0 === $raw || false === $raw ) {
		return false;
	}

	if ( '' === $raw || null === $raw ) {
		return (bool) $default;
	}

	return true;
}

/**
 * Hero visual mode: photo, preview, or both.
 *
 * @return string
 */
function muhamedahmed_home_hero_visual() {
	$mode = sanitize_key( (string) get_option( 'mah_home_hero_visual', 'both' ) );

	return in_array( $mode, array( 'photo', 'preview', 'both' ), true ) ? $mode : 'both';
}

/**
 * Proof strip style: facts, marquee, or off.
 *
 * @return string
 */
function muhamedahmed_home_strip_style() {
	$style = sanitize_key( (string) get_option( 'mah_home_strip_style', 'facts' ) );

	return in_array( $style, array( 'facts', 'marquee', 'off' ), true ) ? $style : 'facts';
}

/**
 * Whether the header theme toggle is shown.
 *
 * @return bool
 */
function muhamedahmed_home_theme_toggle_enabled() {
	return muhamedahmed_option_is_on( 'mah_home_theme_toggle', true );
}

/**
 * Theme toggle button. UI chrome labels, not business copy.
 *
 * @return string
 */
function muhamedahmed_theme_toggle_markup() {
	if ( ! muhamedahmed_home_theme_toggle_enabled() ) {
		return '';
	}

	$label = sprintf(
		/* translators: %s: current theme mode. */
		__( 'Colour theme: %s', 'prowpsite-panel' ),
		__( 'System', 'prowpsite-panel' )
	);

	return '<button type="button" class="mah-theme" data-mah-theme aria-label="' . esc_attr( $label ) . '" aria-pressed="false"><span class="mah-theme__icon" aria-hidden="true"></span><span class="mah-theme__state">' . esc_html__( 'System', 'prowpsite-panel' ) . '</span></button>';
}

/**
 * Nav items for enabled home sections, labels from panel.
 *
 * @return array<int,array{label:string,href:string,key:string}>
 */
function muhamedahmed_chrome_nav_items() {
	$order   = array( 'work', 'services', 'process', 'about', 'reviews' );
	$enabled = function_exists( 'muhamedahmed_home_enabled_sections' )
		? muhamedahmed_home_enabled_sections()
		: $order;
	$stored  = function_exists( 'muhamedahmed_section_links' ) ? muhamedahmed_section_links() : array();
	$by_href = array();

	foreach ( $stored as $row ) {
		if ( ! empty( $row['href'] ) ) {
			$by_href[ $row['href'] ] = $row['label'];
		}
	}

	$items = array();

	foreach ( $order as $key ) {
		if ( ! in_array( $key, $enabled, true ) ) {
			continue;
		}

		$href  = '#' . ( function_exists( 'muhamedahmed_home_section_id' ) ? muhamedahmed_home_section_id( $key ) : $key );
		$label = muhamedahmed_option_text( 'mah_nav_' . $key );

		if ( '' === $label && isset( $by_href[ $href ] ) ) {
			$label = $by_href[ $href ];
		}

		if ( '' === $label ) {
			continue;
		}

		$items[] = array(
			'key'   => $key,
			'label' => $label,
			'href'  => $href,
		);
	}

	return $items;
}

/**
 * Kicker text when the switch is on.
 *
 * @return string
 */
function muhamedahmed_home_kicker_text() {
	if ( ! muhamedahmed_option_is_on( 'mah_home_hero_kicker_on', true ) ) {
		return '';
	}

	$text = muhamedahmed_option_text( 'mah_home_hero_kicker' );

	if ( '' === $text ) {
		$text = muhamedahmed_identity( 'availability' );
	}

	return $text;
}

/**
 * Primary hero CTA from panel, falling back to the contact setting.
 *
 * @return array{label:string,url:string}
 */
function muhamedahmed_home_hero_cta() {
	$label = muhamedahmed_option_text( 'mah_home_hero_cta_label' );
	$url   = muhamedahmed_option_text( 'mah_home_hero_cta_url' );

	if ( '' === $label ) {
		$label = muhamedahmed_identity( 'cta_label' );
	}

	if ( '' === $url ) {
		$url = muhamedahmed_primary_uri();
	} else {
		$url = esc_url_raw( $url );
		$url = function_exists( 'muhamedahmed_permalink' ) ? muhamedahmed_permalink( $url ) : $url;
	}

	return array(
		'label' => $label,
		'url'   => $url,
	);
}

/**
 * Rated-review count and average from published, displayable reviews.
 *
 * @return array{count:int,rated:int,average:float}
 */
function muhamedahmed_review_public_stats() {
	$out = array(
		'count'   => 0,
		'rated'   => 0,
		'average' => 0.0,
	);

	if ( ! function_exists( 'muhamedahmed_reviews_ordered' ) ) {
		return $out;
	}

	$posts = muhamedahmed_reviews_ordered(
		array(
			'count'     => 40,
			'order'     => 'priority',
			'home_only' => false,
		)
	);

	$sum = 0;

	foreach ( $posts as $post ) {
		if ( ! $post instanceof WP_Post ) {
			continue;
		}

		++$out['count'];
		$raw = function_exists( 'mah_review_meta' )
			? mah_review_meta( $post->ID, 'rating', '' )
			: get_post_meta( $post->ID, '_mah_rating', true );

		if ( '' === $raw || null === $raw || ! is_numeric( $raw ) ) {
			continue;
		}

		$rating = (int) $raw;

		if ( $rating < 1 || $rating > 5 ) {
			continue;
		}

		++$out['rated'];
		$sum += $rating;
	}

	if ( $out['rated'] > 0 ) {
		$out['average'] = $sum / $out['rated'];
	}

	return $out;
}

/**
 * Proof-strip items from owner fields and live counts. Empty items omitted.
 *
 * @return array<int,array{value:string,label:string}>
 */
function muhamedahmed_proof_items() {
	$items = array();
	$years = muhamedahmed_option_text( 'mah_years_experience' );

	if ( '' !== $years ) {
		$items[] = array(
			'value' => $years,
			'label' => muhamedahmed_option_text( 'mah_years_experience_label' ),
		);
	}

	$location = muhamedahmed_identity( 'location' );

	if ( '' !== $location ) {
		$items[] = array(
			'value' => $location,
			'label' => '',
		);
	}

	$worldwide = muhamedahmed_option_text( 'mah_working_worldwide' );

	if ( '' !== $worldwide ) {
		$items[] = array(
			'value' => $worldwide,
			'label' => '',
		);
	}

	$projects = function_exists( 'muhamedahmed_project_publish_count' )
		? muhamedahmed_project_publish_count()
		: 0;

	if ( $projects > 0 ) {
		$items[] = array(
			'value' => (string) $projects,
			'label' => muhamedahmed_option_text( 'mah_proof_projects_label' ),
		);
	}

	$reviews = muhamedahmed_review_public_stats();

	if ( $reviews['count'] > 0 ) {
		$value = (string) $reviews['count'];

		if ( $reviews['rated'] >= 1 ) {
			$value .= ' · ' . number_format_i18n( $reviews['average'], 1 );
		}

		$items[] = array(
			'value' => $value,
			'label' => muhamedahmed_option_text( 'mah_proof_reviews_label' ),
		);
	}

	return array_slice( $items, 0, 4 );
}

/**
 * Facts strip markup, or empty.
 *
 * @return string
 */
function muhamedahmed_render_proof_strip() {
	$items = muhamedahmed_proof_items();

	if ( ! $items ) {
		return '';
	}

	$html = '<div class="mah-proof" data-mah-reveal><div class="mah-shell"><ul class="mah-proof__list">';

	foreach ( $items as $item ) {
		$html .= '<li class="mah-proof__item">';
		$html .= '<span class="mah-proof__value">' . esc_html( $item['value'] ) . '</span>';

		if ( '' !== $item['label'] ) {
			$html .= '<span class="mah-proof__label">' . esc_html( $item['label'] ) . '</span>';
		}

		$html .= '</li>';
	}

	$html .= '</ul></div></div>';

	return $html;
}

/**
 * Featured project preview in a browser frame, without hiding the screenshot.
 *
 * @return string
 */
function muhamedahmed_hero_preview_markup() {
	$id = muhamedahmed_home_featured_project_id();

	if ( $id < 1 ) {
		$posts = function_exists( 'muhamedahmed_work_projects' )
			? muhamedahmed_work_projects( 1, 0 )
			: array();
		$id    = ! empty( $posts[0] ) ? (int) $posts[0]->ID : 0;
	}

	if ( $id < 1 ) {
		return '';
	}

	$project = get_post( $id );

	if ( ! $project instanceof WP_Post ) {
		return '';
	}

	$title = get_the_title( $project );
	$url   = function_exists( 'muhamedahmed_meta' ) ? muhamedahmed_meta( $id, 'url' ) : '';
	$image = function_exists( 'muhamedahmed_viewport_img' )
		? muhamedahmed_viewport_img( $id, $title, true )
		: '';

	if ( '' === $image ) {
		return '';
	}

	$html  = '<div class="mah-hero__preview" data-mah-stage="preview">';
	$html .= '<div class="mah-frame">';
	$html .= muhamedahmed_frame_chrome( $url );
	$html .= muhamedahmed_frame_screen( $title, $image );
	$html .= '</div></div>';

	return $html;
}

/**
 * Owner photo as a small overlapping chip.
 *
 * @return string
 */
function muhamedahmed_hero_portrait_chip_markup() {
	$figure = muhamedahmed_hero_figure_markup( 0 );

	if ( '' === $figure ) {
		return '';
	}

	return str_replace( 'mah-hero__figure', 'mah-hero__figure mah-hero__chip', $figure );
}

/**
 * HOME-6 hero: value statement, CTAs, visual from panel.
 *
 * @return string
 */
function muhamedahmed_render_home_hero() {
	$copy     = muhamedahmed_home_copy( 'hero' );
	$heading  = $copy['heading'];
	$intro    = $copy['intro'];
	$kicker   = muhamedahmed_home_kicker_text();
	$cta      = muhamedahmed_home_hero_cta();
	$secondary = muhamedahmed_option_text( 'mah_cta_secondary' );
	$sec_href  = '#work';
	$mode      = muhamedahmed_home_hero_visual();
	$preview   = ( 'photo' === $mode ) ? '' : muhamedahmed_hero_preview_markup();
	$photo     = ( 'preview' === $mode ) ? '' : ( ( 'both' === $mode ) ? muhamedahmed_hero_portrait_chip_markup() : muhamedahmed_hero_figure_markup( 0 ) );

	if ( 'both' === $mode && '' === $preview ) {
		$mode  = 'photo';
		$photo = muhamedahmed_hero_figure_markup( 0 );
	}

	if ( 'both' === $mode && '' === $photo ) {
		$mode = 'preview';
	}

	if ( '' === $intro ) {
		$intro = muhamedahmed_tagline();
	}

	$visual = $preview . $photo;
	$classes = array( 'mah-hero', 'mah-home', 'mah-home--hero', 'mah-hero--visual-' . sanitize_html_class( $mode ) );

	if ( '' !== $visual ) {
		$classes[] = 'mah-hero--split';
	}

	$out  = '<section id="top" class="' . esc_attr( implode( ' ', $classes ) ) . '" aria-labelledby="mah-hero-title" data-mah-section="top" data-mah-reveal>';
	$out .= '<div class="mah-shell mah-hero__grid">';
	$out .= '<div class="mah-hero__copy">';

	if ( '' !== $kicker ) {
		$out .= sprintf(
			'<p class="mah-pill" data-mah-stage="pill"><span class="mah-pill__dot" aria-hidden="true"></span>%s</p>',
			esc_html( $kicker )
		);
	}

	if ( '' !== $heading ) {
		$out .= sprintf(
			'<h1 id="mah-hero-title" class="mah-hero__name" data-mah-stage="name"><span class="mah-hero__name-text">%s</span></h1>',
			esc_html( $heading )
		);
	} else {
		$out .= '<h1 id="mah-hero-title" class="screen-reader-text">' . esc_html( muhamedahmed_name() ) . '</h1>';
	}

	if ( '' !== $intro ) {
		$out .= sprintf( '<p class="mah-hero__tag" data-mah-stage="tag">%s</p>', esc_html( $intro ) );
	}

	$buttons = '';

	if ( '' !== $cta['label'] && '' !== $cta['url'] ) {
		$buttons .= sprintf(
			'<a class="mah-btn mah-btn--accent" href="%s" data-mah-magnetic data-mah-stage="ctas">%s</a>',
			esc_url( $cta['url'] ),
			esc_html( $cta['label'] )
		);
	}

	if ( '' !== $secondary ) {
		$buttons .= sprintf(
			'<a class="mah-btn mah-btn--ghost" href="%s" data-mah-stage="ctas">%s</a>',
			esc_url( $sec_href ),
			esc_html( $secondary )
		);
	}

	if ( '' !== $buttons ) {
		$out .= '<div class="mah-hero__actions">' . $buttons . '</div>';
	}

	$out .= '</div>';

	if ( '' !== $visual ) {
		$out .= '<div class="mah-hero__visual">' . $visual . '</div>';
	}

	$out .= '</div></section>';

	return $out;
}

/**
 * Contact band: heading, large links, primary CTA.
 *
 * @return string
 */
function muhamedahmed_render_contact_home() {
	$email    = muhamedahmed_identity( 'email' );
	$phone    = muhamedahmed_identity( 'phone' );
	$wa       = preg_replace( '/[^0-9]/', '', muhamedahmed_identity( 'whatsapp' ) );
	$location = muhamedahmed_identity( 'location' );
	$cta      = muhamedahmed_identity( 'cta_label' );
	$uri      = muhamedahmed_primary_uri();
	$copy     = muhamedahmed_home_copy( 'contact' );
	$headline = $copy['heading'];

	if ( '' === $headline ) {
		$headline = muhamedahmed_option_text( 'mah_footer_headline' );
	}

	if ( '' === $email && '' === $phone && '' === $wa && '' === $location && '' === $uri ) {
		return '';
	}

	$html     = muhamedahmed_home_section_open( 'contact', 'band' );
	$primary  = '';
	$links    = '';

	if ( '' === $copy['heading'] && '' !== $headline ) {
		$primary .= sprintf(
			'<h2 id="mah-contact-title" class="mah-contact__headline">%s</h2>',
			esc_html( $headline )
		);
	}

	if ( $email ) {
		$links .= sprintf(
			'<a class="mah-contact__link" href="%s">%s</a>',
			esc_url( 'mailto:' . $email ),
			esc_html( $email )
		);
	}

	if ( $phone ) {
		$links .= sprintf(
			'<a class="mah-contact__link" href="%s">%s</a>',
			esc_url( 'tel:' . preg_replace( '/[^0-9+]/', '', $phone ) ),
			esc_html( $phone )
		);
	}

	if ( $wa ) {
		$links .= sprintf(
			'<a class="mah-contact__link" href="%s">%s</a>',
			esc_url( 'https://wa.me/' . $wa ),
			esc_html__( 'WhatsApp', 'prowpsite-panel' )
		);
	}

	if ( $location ) {
		$links .= sprintf(
			'<p class="mah-contact__link mah-contact__link--loc">%s</p>',
			esc_html( $location )
		);
	}

	if ( $cta && $uri ) {
		$primary .= sprintf(
			'<a class="mah-btn mah-btn--accent" href="%s" data-mah-magnetic>%s</a>',
			esc_url( $uri ),
			esc_html( $cta )
		);
	}

	if ( '' === $primary && '' === $links ) {
		return '';
	}

	$inner = '<div class="mah-contact__layout">';

	if ( '' !== $primary ) {
		$inner .= '<div class="mah-contact__primary">' . $primary . '</div>';
	}

	if ( '' !== $links ) {
		$inner .= '<div class="mah-contact__links">' . $links . '</div>';
	}

	$inner .= '</div>';

	return $html . $inner . muhamedahmed_home_section_close();
}

/**
 * One home section, or empty when its data is empty.
 *
 * @param string $key Section key.
 * @return string
 */
function muhamedahmed_render_home_section( $key ) {
	switch ( $key ) {
		case 'hero':
			return muhamedahmed_render_home_hero();

		case 'marquee':
			$style = muhamedahmed_home_strip_style();

			if ( 'off' === $style ) {
				return '';
			}

			if ( 'facts' === $style ) {
				return muhamedahmed_render_proof_strip();
			}

			return muhamedahmed_render_marquee(
				array(
					'text'   => '',
					'tone'   => 'band',
					'speed'  => 28,
					'anchor' => 'marquee',
				)
			);

		case 'stats':
			$inner = muhamedahmed_render_stats();

			if ( '' === $inner ) {
				return '';
			}

			$inner = '<div class="mah-pin-progress" hidden aria-hidden="true"><span></span></div>' . $inner;

			return muhamedahmed_home_section_open( 'stats', 'band' ) . $inner . muhamedahmed_home_section_close();

		case 'services':
			if ( ! function_exists( 'mah_content_services' ) ) {
				return '';
			}

			$inner = mah_content_services( array( 'count' => 12 ) );

			if ( '' === $inner ) {
				return '';
			}

			return muhamedahmed_home_section_open( 'services', 'band' ) . $inner . muhamedahmed_home_section_close();

		case 'work':
			$inner = muhamedahmed_render_work(
				array(
					'count'    => muhamedahmed_home_work_rail_count() + 1,
					'featured' => muhamedahmed_home_featured_project_id(),
					'bare'     => true,
				),
				''
			);

			if ( '' === $inner ) {
				return '';
			}

			return muhamedahmed_home_section_open( 'work', 'surface' ) . $inner . muhamedahmed_home_section_close();

		case 'process':
			if ( ! function_exists( 'mah_content_process' ) ) {
				return '';
			}

			$inner = mah_content_process();

			if ( '' === $inner ) {
				return '';
			}

			return muhamedahmed_home_section_open( 'process', 'band' ) . $inner . muhamedahmed_home_section_close();

		case 'about':
			$inner = muhamedahmed_about_body_markup();

			if ( '' === $inner ) {
				return '';
			}

			return muhamedahmed_home_section_open( 'about', 'band', 'mah-about' ) . $inner . muhamedahmed_home_section_close();

		case 'reviews':
			$inner = function_exists( 'muhamedahmed_reviews_markup' )
				? muhamedahmed_reviews_markup(
					array(
						'count'     => muhamedahmed_home_reviews_count(),
						'order'     => muhamedahmed_home_reviews_order(),
						'home_only' => muhamedahmed_home_reviews_home_only(),
					)
				)
				: ( function_exists( 'mah_content_reviews' )
					? mah_content_reviews(
						array(
							'count'     => muhamedahmed_home_reviews_count(),
							'order'     => muhamedahmed_home_reviews_order(),
							'home_only' => muhamedahmed_home_reviews_home_only(),
						)
					)
					: '' );

			if ( '' === $inner ) {
				return '';
			}

			return muhamedahmed_home_section_open( 'reviews', 'band' ) . $inner . muhamedahmed_home_section_close();

		case 'contact':
			return muhamedahmed_render_contact_home();
	}

	return '';
}

/**
 * Render the panel-driven home page.
 *
 * @return string
 */
function muhamedahmed_render_home() {
	muhamedahmed_migrate_home_copy();

	$GLOBALS['mah_home_rendered'] = true;
	$html                         = '';

	foreach ( muhamedahmed_home_enabled_sections() as $key ) {
		$html .= muhamedahmed_render_home_section( $key );
	}

	return '<div class="mah-home mah-home--page">' . $html . '</div>';
}

/**
 * Enqueue home CSS/JS even when the standalone blocks plugin skipped the module.
 *
 * @return void
 */
function muhamedahmed_home_front_assets() {
	if ( ! is_front_page() ) {
		return;
	}

	$css = PROWP_PATH . 'assets/home/home.css';
	$js  = PROWP_PATH . 'assets/home/motion.js';

	$tokens = PROWP_PATH . 'assets/home/tokens.css';

	if ( is_readable( $tokens ) && ! wp_style_is( 'mah-home-tokens', 'registered' ) ) {
		wp_register_style(
			'mah-home-tokens',
			PROWP_URL . 'assets/home/tokens.css',
			array(),
			(string) filemtime( $tokens )
		);
	}

	if ( wp_style_is( 'mah-home-tokens', 'registered' ) ) {
		wp_enqueue_style( 'mah-home-tokens' );
	}

	if ( is_readable( $css ) && ! wp_style_is( 'mah-home', 'registered' ) ) {
		wp_register_style(
			'mah-home',
			PROWP_URL . 'assets/home/home.css',
			array( 'mah-home-tokens' ),
			(string) filemtime( $css )
		);
	}

	if ( wp_style_is( 'mah-home', 'registered' ) ) {
		wp_enqueue_style( 'mah-home' );
	}

	if ( is_readable( $js ) && ! wp_script_is( 'mah-motion', 'registered' ) ) {
		wp_register_script(
			'mah-motion',
			PROWP_URL . 'assets/home/motion.js',
			array(),
			(string) filemtime( $js ),
			array(
				'in_footer' => true,
				'strategy'  => 'defer',
			)
		);
	}

	if ( wp_script_is( 'mah-motion', 'registered' ) && function_exists( 'muhamedahmed_home_motion_config' ) ) {
		wp_enqueue_script( 'mah-motion' );
		wp_localize_script(
			'mah-motion',
			'mahMotion',
			array(
				'fx' => muhamedahmed_home_motion_config(),
			)
		);
	}
}
add_action( 'wp_enqueue_scripts', 'muhamedahmed_home_front_assets', 21 );

/**
 * Replace the static front page's saved blocks when front-page.php is not used.
 *
 * @param string $content Page content.
 * @return string
 */
function muhamedahmed_home_the_content( $content ) {
	if ( 'page' !== get_option( 'show_on_front' ) || ! is_front_page() || ! is_singular( 'page' ) || ! is_main_query() || ! in_the_loop() ) {
		return $content;
	}

	if ( ! empty( $GLOBALS['mah_home_rendered'] ) ) {
		return $content;
	}

	$GLOBALS['mah_home_rendered'] = true;

	return muhamedahmed_render_home();
}
add_filter( 'the_content', 'muhamedahmed_home_the_content', 1 );

/**
 * Prefer the child theme front-page.php so Astra page templates cannot win.
 *
 * @param string $template Template path.
 * @return string
 */
function muhamedahmed_home_template_include( $template ) {
	if ( ! is_front_page() ) {
		return $template;
	}

	$front = get_stylesheet_directory() . '/front-page.php';

	if ( is_readable( $front ) ) {
		return $front;
	}

	return $template;
}
add_filter( 'template_include', 'muhamedahmed_home_template_include', 99 );
