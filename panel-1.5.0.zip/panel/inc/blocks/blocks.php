<?php
/**
 * Block registrations.
 *
 * @package MuhamedAhmed_Blocks
 */

defined( 'ABSPATH' ) || exit;

/**
 * Register the stylesheet.
 *
 * @return void
 */
function muhamedahmed_blocks_register_assets() {
	wp_register_style(
		'mah-blocks',
		MUHAMEDAHMED_BLOCKS_URL . 'assets/blocks.css',
		array(),
		MUHAMEDAHMED_BLOCKS_VERSION
	);

	$home_css = MUHAMEDAHMED_BLOCKS_DIR . '../assets/home/home.css';
	$home_url = MUHAMEDAHMED_BLOCKS_URL . 'assets/home/home.css';

	if ( is_readable( PROWP_PATH . 'assets/home/home.css' ) ) {
		$home_css = PROWP_PATH . 'assets/home/home.css';
		$home_url = PROWP_URL . 'assets/home/home.css';
	}

	wp_register_style(
		'mah-home',
		$home_url,
		array( 'mah-blocks' ),
		file_exists( $home_css ) ? (string) filemtime( $home_css ) : MUHAMEDAHMED_BLOCKS_VERSION
	);

	wp_register_script(
		'mah-viewport',
		MUHAMEDAHMED_BLOCKS_URL . 'assets/viewport.js',
		array(),
		MUHAMEDAHMED_BLOCKS_VERSION,
		array(
			'in_footer' => true,
			'strategy'  => 'defer',
		)
	);

	$motion_js = PROWP_PATH . 'assets/home/motion.js';

	wp_register_script(
		'mah-motion',
		PROWP_URL . 'assets/home/motion.js',
		array(),
		file_exists( $motion_js ) ? (string) filemtime( $motion_js ) : MUHAMEDAHMED_BLOCKS_VERSION,
		array(
			'in_footer' => true,
			'strategy'  => 'defer',
		)
	);
}

/**
 * Merge extra classes onto the block wrapper.
 *
 * @param array $classes Extra classes.
 * @return string
 */
function muhamedahmed_wrapper_class( array $classes ) {
	return get_block_wrapper_attributes(
		array(
			'class' => implode( ' ', array_filter( $classes ) ),
		)
	);
}

/* -------------------------------------------------------------------------
 * Hero
 * ---------------------------------------------------------------------- */

/**
 * Availability pill markup, or empty.
 *
 * @return string
 */
function muhamedahmed_hero_pill_markup() {
	if ( ! muhamedahmed_is_available() ) {
		return '';
	}

	return sprintf(
		'<p class="mah-pill" data-mah-stage="pill"><span class="mah-pill__dot" aria-hidden="true"></span>%s</p>',
		esc_html( muhamedahmed_identity( 'availability' ) )
	);
}

/**
 * Hero action buttons, or empty.
 *
 * @return string
 */
function muhamedahmed_hero_actions_markup() {
	$cta       = muhamedahmed_identity( 'cta_label' );
	$uri       = muhamedahmed_primary_uri();
	$secondary = muhamedahmed_option_text( 'mah_cta_secondary' );
	$sec_href  = '#work';
	$buttons   = '';

	if ( '' === $secondary ) {
		$links = function_exists( 'muhamedahmed_section_links' ) ? muhamedahmed_section_links() : array();

		if ( $links && ! empty( $links[0]['label'] ) ) {
			$secondary = (string) $links[0]['label'];
			$sec_href  = ! empty( $links[0]['href'] ) ? (string) $links[0]['href'] : '#work';
		}
	}

	if ( $cta && $uri ) {
		$buttons .= sprintf(
			'<a class="mah-btn mah-btn--accent" href="%s" data-mah-magnetic>%s</a>',
			esc_url( $uri ),
			esc_html( $cta )
		);
	}

	if ( $secondary ) {
		$buttons .= sprintf(
			'<a class="mah-btn mah-btn--ghost" href="%s">%s</a>',
			esc_url( $sec_href ),
			esc_html( $secondary )
		);
	}

	if ( '' === $buttons ) {
		return '';
	}

	return '<div class="mah-hero__actions" data-mah-stage="ctas">' . $buttons . '</div>';
}

/**
 * Trust line under the hero actions. Location and response time only.
 *
 * @return string
 */
function muhamedahmed_hero_trust_markup() {
	$location = muhamedahmed_identity( 'location' );
	$response = muhamedahmed_identity( 'response_time' );
	$bits     = array_filter( array( $location, $response ) );

	if ( ! $bits ) {
		return '';
	}

	return '<p class="mah-hero__trust" data-mah-stage="trust">' . esc_html( implode( ' · ', $bits ) ) . '</p>';
}

/**
 * Hero copy column.
 *
 * @param string $name Display name.
 * @return string
 */
function muhamedahmed_hero_copy_markup( $name ) {
	$role    = muhamedahmed_identity( 'role' );
	$tagline = muhamedahmed_tagline();
	$html    = '<div class="mah-hero__copy">';
	$html   .= muhamedahmed_hero_pill_markup();
	$html   .= sprintf(
		'<h1 id="mah-hero-title" class="mah-hero__name" data-mah-stage="name"><span class="mah-hero__name-text">%s</span></h1>',
		esc_html( $name )
	);

	if ( $role ) {
		$html .= sprintf( '<p class="mah-hero__role" data-mah-stage="role">%s</p>', esc_html( $role ) );
	}

	if ( $tagline ) {
		$html .= sprintf( '<p class="mah-hero__tag" data-mah-stage="tag">%s</p>', esc_html( $tagline ) );
	}

	$html .= muhamedahmed_hero_actions_markup();
	$html .= muhamedahmed_hero_trust_markup();

	if ( function_exists( 'muhamedahmed_hero_proof_markup' ) && function_exists( 'muhamedahmed_home_hero_chips_enabled' ) && muhamedahmed_home_hero_chips_enabled() ) {
		$html .= muhamedahmed_hero_proof_markup();
	}

	$html .= '</div>';

	return $html;
}

/**
 * Portrait figure, or empty.
 *
 * @param int $override Block portrait attribute.
 * @return string
 */
function muhamedahmed_hero_figure_markup( $override ) {
	$override = (int) $override;
	$image_id = 0;
	$alt      = function_exists( 'muhamedahmed_home_hero_image_alt' )
		? muhamedahmed_home_hero_image_alt()
		: ( function_exists( 'muhamedahmed_name' ) ? muhamedahmed_name() : '' );
	$position = function_exists( 'muhamedahmed_home_hero_object_position' )
		? muhamedahmed_home_hero_object_position()
		: '50% 35%';

	if ( $override > 0 ) {
		$image_id = $override;
	} elseif ( function_exists( 'muhamedahmed_home_hero_image_state' ) ) {
		$state    = muhamedahmed_home_hero_image_state();
		$image_id = isset( $state['id'] ) ? (int) $state['id'] : 0;
	} else {
		$image_id = function_exists( 'muhamedahmed_portrait_id' ) ? muhamedahmed_portrait_id( 0 ) : 0;
	}

	if ( $image_id < 1 ) {
		return '';
	}

	$image = function_exists( 'muhamedahmed_portrait_html' )
		? muhamedahmed_portrait_html( 'mah-hero__portrait', 'large', $image_id, $alt, $position )
		: '';

	if ( '' === $image ) {
		return '';
	}

	$style = 'style="--mah-portrait-object-position: ' . esc_attr( $position ) . '"';

	return '<figure class="mah-hero__figure" data-mah-stage="portrait" data-mah-parallax ' . $style . '>' . $image . '</figure>';
}

/**
 * Render the hero block from identity + portrait. Inner content is discarded.
 *
 * @param array  $attributes Block attributes.
 * @param string $content    Unused inner markup.
 * @return string
 */
function muhamedahmed_render_hero( $attributes, $content ) {
	unset( $content );

	$a = wp_parse_args(
		$attributes,
		array(
			'portrait' => 0,
		)
	);

	$figure  = muhamedahmed_hero_figure_markup( (int) $a['portrait'] );
	$classes = array( 'mah-hero' );

	if ( '' !== $figure ) {
		$classes[] = 'mah-hero--split';
	}

	$out  = '<section ' . muhamedahmed_wrapper_class( $classes ) . ' aria-labelledby="mah-hero-title">';
	$out .= '<div class="mah-shell mah-hero__grid">';
	$out .= muhamedahmed_hero_copy_markup( muhamedahmed_name() );
	$out .= $figure;
	$out .= '</div></section>';

	return $out;
}

/**
 * Register the hero block.
 *
 * @return void
 */
function muhamedahmed_register_hero_block() {
	register_block_type(
		'muhamedahmed/hero',
		array(
			'api_version'     => 3,
			'title'           => __( 'Hero', 'prowpsite-panel' ),
			'description'     => __( 'Opening identity section. Copy and portrait come from Site Content.', 'prowpsite-panel' ),
			'category'        => 'design',
			'icon'            => 'cover-image',
			'keywords'        => array( 'hero', 'banner', 'intro', 'mah' ),
			'supports'        => array(
				'align'           => true,
				'anchor'          => true,
				'html'            => false,
				'customClassName' => true,
			),
			'attributes'      => array(
				'eyebrow'  => array( 'type' => 'string', 'default' => '' ),
				'portrait' => array( 'type' => 'number', 'default' => 0 ),
				'height'   => array( 'type' => 'string', 'default' => 'tall' ),
				'scrim'    => array( 'type' => 'boolean', 'default' => true ),
				'split'    => array( 'type' => 'boolean', 'default' => false ),
				'anchor'   => array( 'type' => 'string', 'default' => 'top' ),
			),
			'render_callback' => 'muhamedahmed_render_hero',
			'editor_script'   => 'mah-blocks',
			'style'           => 'mah-blocks',
		)
	);
}

/* -------------------------------------------------------------------------
 * Section
 * ---------------------------------------------------------------------- */

/**
 * Render the section block.
 *
 * @param array  $attributes Block attributes.
 * @param string $content    Inner block markup.
 * @return string
 */
function muhamedahmed_render_section( $attributes, $content ) {
	$a = wp_parse_args(
		$attributes,
		array(
			'layout'  => 'ground',
			'eyebrow' => '',
			'align'   => 'full',
			'rule'    => false,
			'tone'    => 'default',
		)
	);

	$classes = array( 'mah-sec', 'mah-sec--' . sanitize_html_class( $a['layout'] ) );

	if ( 'flush' === $a['align'] ) {
		$classes[] = 'mah-sec--flush';
	}

	if ( $a['rule'] ) {
		$classes[] = 'mah-sec--rule';
	}

	if ( 'muted' === $a['tone'] ) {
		$classes[] = 'mah-sec--tone-muted';
	}

	$eyebrow = trim( (string) $a['eyebrow'] );

	if ( '' === $eyebrow && '' === trim( (string) $content ) ) {
		return '';
	}

	/*
	 * One id per anchor, on the section.
	 *
	 * Core prints the anchor as the id of this first tag. The callback must
	 * not print a second one.
	 */
	$out = '<section ' . get_block_wrapper_attributes( array( 'class' => implode( ' ', $classes ) ) ) . '>';

	if ( '' !== $eyebrow ) {
		$out .= '<div class="mah-shell mah-sec__head">';
		$out .= '<p class="mah-eyebrow">' . esc_html( $eyebrow ) . '</p>';
		$out .= '</div>';
	}

	$out .= '<div class="mah-shell">' . $content . '</div>';
	$out .= '</section>';

	return $out;
}

/**
 * Register the section block.
 *
 * @return void
 */
function muhamedahmed_register_section_block() {
	register_block_type(
		'muhamedahmed/section',
		array(
			'api_version'     => 3,
			'title'           => __( 'Homepage Section', 'prowpsite-panel' ),
			'description'     => __( 'Design-aware section wrapper: band rhythm, eyebrow label and anchor.', 'prowpsite-panel' ),
			'category'        => 'design',
			'icon'            => 'layout',
			'keywords'        => array( 'section', 'band', 'homepage', 'mah' ),
			'supports'        => array(
				'align'           => true,
				'html'            => false,
				'anchor'          => true,
				'customClassName' => true,
				'spacing'         => array( 'margin' => true, 'padding' => true ),
				'color'           => array( 'background' => true, 'text' => true ),
			),
			'attributes'      => array(
				'layout'  => array( 'type' => 'string', 'default' => 'ground' ),
				'eyebrow' => array( 'type' => 'string', 'default' => '' ),
				'align'   => array( 'type' => 'string', 'default' => 'full' ),
				'anchor'  => array( 'type' => 'string', 'default' => '' ),
				'rule'    => array( 'type' => 'boolean', 'default' => false ),
				'tone'    => array( 'type' => 'string', 'default' => 'default' ),
			),
			'render_callback' => 'muhamedahmed_render_section',
			'editor_script'   => 'mah-blocks',
			'style'           => 'mah-blocks',
		)
	);
}

/* -------------------------------------------------------------------------
 * Marquee
 * ---------------------------------------------------------------------- */

/**
 * Resolve marquee phrases: option first, then the block attribute.
 *
 * @param string $attribute_text Block text attribute.
 * @return array<int,string>
 */
function muhamedahmed_marquee_phrase_list( $attribute_text ) {
	$phrases = muhamedahmed_marquee_phrases();

	if ( $phrases ) {
		return $phrases;
	}

	$text = trim( (string) $attribute_text );

	if ( '' === $text ) {
		return array();
	}

	return array_values( array_filter( array_map( 'trim', explode( '•', $text ) ) ) );
}

/**
 * Render the marquee block.
 *
 * @param array $attributes Block attributes.
 * @return string
 */
function muhamedahmed_render_marquee( $attributes ) {
	$a = wp_parse_args(
		$attributes,
		array(
			'text'   => '',
			'tone'   => 'accent',
			'speed'  => 28,
			'anchor' => '',
		)
	);

	$parts = muhamedahmed_marquee_phrase_list( $a['text'] );

	if ( ! $parts ) {
		return '';
	}

	$speed = max( 6, absint( $a['speed'] ) );
	$tone  = in_array( $a['tone'], array( 'accent', 'band' ), true ) ? $a['tone'] : 'accent';
	$bits  = array();

	foreach ( $parts as $part ) {
		$bits[] = '<span class="mah-marquee__item">' . esc_html( $part ) . '</span>';
		$bits[] = '<span class="mah-marquee__sep" aria-hidden="true"></span>';
	}

	$group = '<div class="mah-marquee__group">' . implode( '', $bits ) . '</div>';
	$wrap  = array(
		'class' => 'mah-marquee mah-marquee--' . $tone,
		'style' => '--mah-marquee-speed:' . $speed . 's',
	);

	if ( '' !== sanitize_html_class( (string) $a['anchor'] ) ) {
		$wrap['id'] = sanitize_html_class( (string) $a['anchor'] );
	}

	$attrs = get_block_wrapper_attributes( $wrap );

	$static = '<ul class="mah-marquee__static">';

	foreach ( $parts as $part ) {
		$static .= '<li>' . esc_html( $part ) . '</li>';
	}

	$static .= '</ul>';

	return '<div ' . $attrs . '>' .
		'<div class="mah-marquee__track" aria-hidden="true">' . $group . $group . '</div>' .
		$static .
		'<span class="screen-reader-text">' . esc_html( implode( ' • ', $parts ) ) . '</span>' .
		'</div>';
}

/**
 * Register the marquee block.
 *
 * @return void
 */
function muhamedahmed_register_marquee_block() {
	register_block_type(
		'muhamedahmed/marquee',
		array(
			'api_version'     => 3,
			'title'           => __( 'Scrolling Marquee', 'prowpsite-panel' ),
			'description'     => __( 'Seamless scrolling text band. Phrases come from Site Content.', 'prowpsite-panel' ),
			'category'        => 'design',
			'icon'            => 'slides',
			'keywords'        => array( 'marquee', 'scroll', 'band', 'ticker', 'mah' ),
			'attributes'      => array(
				'text'  => array( 'type' => 'string', 'default' => '' ),
				'tone'  => array( 'type' => 'string', 'default' => 'accent' ),
				'speed' => array( 'type' => 'number', 'default' => 30 ),
			),
			'render_callback' => 'muhamedahmed_render_marquee',
			'editor_script'   => 'mah-blocks',
			'style'           => 'mah-blocks',
		)
	);
}

/* -------------------------------------------------------------------------
 * Stats
 * ---------------------------------------------------------------------- */

/**
 * Render stacked statistics. Empty option → nothing.
 *
 * @return string
 */
function muhamedahmed_render_stats() {
	$stats = muhamedahmed_stats();

	if ( ! $stats ) {
		return '';
	}

	$out = '<ul ' . get_block_wrapper_attributes(
		array(
			'class'      => 'mah-stats mah-stats--n' . count( $stats ),
			'aria-label' => __( 'Verified figures', 'prowpsite-panel' ),
		)
	) . '>';

	foreach ( $stats as $stat ) {
		$out .= '<li class="mah-stat">';
		$out .= sprintf(
			'<p class="mah-stat__value" data-mah-count="%s"><span class="screen-reader-text">%s</span><span aria-hidden="true">%s</span></p>',
			esc_attr( $stat['value'] ),
			esc_html( $stat['value'] ),
			esc_html( $stat['value'] )
		);
		$out .= sprintf( '<p class="mah-stat__label">%s</p>', esc_html( $stat['label'] ) );
		$out .= '</li>';
	}

	$out .= '</ul>';

	return $out;
}

/**
 * Register the stats block.
 *
 * @return void
 */
function muhamedahmed_register_stats_block() {
	register_block_type(
		'muhamedahmed/stats',
		array(
			'api_version'     => 3,
			'title'           => __( 'Statistics', 'prowpsite-panel' ),
			'description'     => __( 'Verified figures from Site Content, stacked value over label.', 'prowpsite-panel' ),
			'category'        => 'design',
			'icon'            => 'chart-bar',
			'keywords'        => array( 'stats', 'numbers', 'proof', 'mah' ),
			'supports'        => array(
				'align'           => true,
				'html'            => false,
				'customClassName' => true,
			),
			'attributes'      => array(),
			'render_callback' => 'muhamedahmed_render_stats',
			'editor_script'   => 'mah-blocks',
			'style'           => 'mah-blocks',
		)
	);
}

/* -------------------------------------------------------------------------
 * About
 * ---------------------------------------------------------------------- */

/**
 * About points list, or empty.
 *
 * @param array<int,string> $points Stored points.
 * @return string
 */
function muhamedahmed_about_points_markup( array $points ) {
	$points = array_slice( array_values( $points ), 0, 3 );

	if ( ! $points ) {
		return '';
	}

	$html = '<ul class="mah-about__points">';

	foreach ( $points as $point ) {
		$icon = function_exists( 'muhamedahmed_check_icon' ) ? muhamedahmed_check_icon() : '';
		$html .= '<li class="mah-about__card">';
		$html .= $icon;
		$html .= '<span>' . esc_html( $point ) . '</span>';
		$html .= '</li>';
	}

	$html .= '</ul>';

	return $html;
}

/**
 * About copy + reason cards, without the section wrapper.
 *
 * @return string
 */
function muhamedahmed_about_body_markup() {
	$body   = muhamedahmed_option_text( 'mah_about_body', true );
	$bio    = muhamedahmed_identity( 'bio' );
	$points = muhamedahmed_about_points();

	if ( '' === $body && '' === $bio && ! $points ) {
		return '';
	}

	$paragraphs = preg_split( '/\r\n\r\n|\n\n/', $body );
	$paragraphs = is_array( $paragraphs ) ? array_values( array_filter( array_map( 'trim', $paragraphs ) ) ) : array();

	$html = '<div class="mah-about__grid">';
	$html .= '<div class="mah-about__copy">';

	if ( $paragraphs ) {
		$first = $paragraphs[0];

		if ( preg_match( '/^(.+?[.!?])(\s+.*)?$/us', $first, $lead ) ) {
			$html .= sprintf( '<p class="mah-about__lead">%s</p>', esc_html( $lead[1] ) );

			if ( ! empty( $lead[2] ) ) {
				$paragraphs[0] = trim( $lead[2] );
			} else {
				array_shift( $paragraphs );
			}
		}

		foreach ( $paragraphs as $paragraph ) {
			if ( '' === $paragraph ) {
				continue;
			}

			$html .= sprintf( '<p class="mah-about__body">%s</p>', esc_html( $paragraph ) );
		}
	} elseif ( $body ) {
		$html .= sprintf( '<p class="mah-about__body">%s</p>', esc_html( $body ) );
	}

	if ( '' !== $bio && 0 !== strcasecmp( trim( $bio ), trim( $body ) ) ) {
		$html .= sprintf( '<p class="mah-about__bio">%s</p>', esc_html( $bio ) );
	}

	$html .= '</div>';
	$html .= muhamedahmed_about_points_markup( $points );
	$html .= '</div>';

	return $html;
}

/**
 * Render the about block. No nested #about.
 *
 * @return string
 */
function muhamedahmed_render_about() {
	$eyebrow = muhamedahmed_option_text( 'mah_about_eyebrow' );
	$stored  = muhamedahmed_option_text( 'mah_about_heading' );
	$heading = $stored;
	$inner   = muhamedahmed_about_body_markup();

	if ( '' === $heading && '' === $eyebrow && '' === $inner ) {
		return '';
	}

	$out = '<section ' . muhamedahmed_wrapper_class( array( 'mah-sec', 'mah-sec--paper', 'mah-about' ) );

	if ( '' !== $heading ) {
		$out .= ' aria-labelledby="mah-about-title"';
	}

	$out .= '>';
	$out .= '<div class="mah-shell">';

	if ( $eyebrow || $heading ) {
		$out .= '<header class="mah-sec__head">';

		if ( $eyebrow ) {
			$out .= sprintf( '<p class="mah-eyebrow">%s</p>', esc_html( $eyebrow ) );
		}

		if ( $heading ) {
			$out .= sprintf( '<h2 id="mah-about-title">%s</h2>', esc_html( $heading ) );
		}

		$out .= '</header>';
	}

	$out .= $inner;
	$out .= '</div></section>';

	return $out;
}

/**
 * Register the about block.
 *
 * @return void
 */
function muhamedahmed_register_about_block() {
	register_block_type(
		'muhamedahmed/about',
		array(
			'api_version'     => 3,
			'title'           => __( 'About', 'prowpsite-panel' ),
			'description'     => __( 'About section from Site Content. Renders nothing when empty.', 'prowpsite-panel' ),
			'category'        => 'design',
			'icon'            => 'id',
			'keywords'        => array( 'about', 'bio', 'mah' ),
			'supports'        => array(
				'align'           => true,
				'anchor'          => true,
				'html'            => false,
				'customClassName' => true,
			),
			'attributes'      => array(
				'anchor' => array( 'type' => 'string', 'default' => 'about' ),
			),
			'render_callback' => 'muhamedahmed_render_about',
			'editor_script'   => 'mah-blocks',
			'style'           => 'mah-blocks',
		)
	);
}

/* -------------------------------------------------------------------------
 * Work — Living Viewport
 * ---------------------------------------------------------------------- */

/**
 * Whether the hero portrait is the LCP image.
 *
 * @return bool
 */
function muhamedahmed_portrait_is_lcp() {
	$id = muhamedahmed_portrait_id( 0 );

	return $id > 0 && wp_attachment_is_image( $id );
}

/**
 * Hostname for the chrome URL label, or empty.
 *
 * @param string $url Project URL.
 * @return string
 */
function muhamedahmed_project_hostname( $url ) {
	if ( '' === $url ) {
		return '';
	}

	$host = wp_parse_url( $url, PHP_URL_HOST );

	return is_string( $host ) ? $host : '';
}

/**
 * Initials placeholder when a project has no featured image.
 *
 * @param string $title Project title.
 * @return string
 */
function muhamedahmed_viewport_placeholder( $title ) {
	$words    = preg_split( '/\s+/', trim( (string) $title ) );
	$initials = '';

	if ( is_array( $words ) ) {
		foreach ( $words as $word ) {
			$letter = substr( $word, 0, 1 );

			if ( '' !== $letter ) {
				$initials .= strtoupper( $letter );
			}

			if ( strlen( $initials ) >= 3 ) {
				break;
			}
		}
	}

	if ( '' === $initials ) {
		$initials = '?';
	}

	return sprintf(
		'<div class="mah-frame__ph" aria-hidden="true"><span>%s</span></div>',
		esc_html( $initials )
	);
}

/**
 * Registered image size whose file exists on disk. Falls back to full.
 *
 * @param int    $attachment_id Attachment id.
 * @param string $preferred     Size name.
 * @return string
 */
function muhamedahmed_usable_image_size( $attachment_id, $preferred = 'large' ) {
	$attachment_id = (int) $attachment_id;
	$preferred     = is_string( $preferred ) ? $preferred : 'large';

	if ( $attachment_id < 1 || 'full' === $preferred ) {
		return 'full';
	}

	$src = wp_get_attachment_image_src( $attachment_id, $preferred );

	if ( ! is_array( $src ) || empty( $src[0] ) ) {
		return 'full';
	}

	$uploads = wp_get_upload_dir();
	$baseurl = isset( $uploads['baseurl'] ) ? (string) $uploads['baseurl'] : '';
	$basedir = isset( $uploads['basedir'] ) ? (string) $uploads['basedir'] : '';

	if ( $baseurl && $basedir && 0 === strpos( $src[0], $baseurl ) ) {
		$path = $basedir . substr( $src[0], strlen( $baseurl ) );
		$path = rawurldecode( $path );

		if ( ! is_readable( $path ) ) {
			return 'full';
		}
	}

	return $preferred;
}

/**
 * Drop srcset candidates whose files are not on disk.
 *
 * @param array $sources Srcset entries keyed by width.
 * @return array
 */
function muhamedahmed_existing_srcset( $sources ) {
	if ( ! is_array( $sources ) ) {
		return $sources;
	}

	$uploads = wp_get_upload_dir();
	$baseurl = isset( $uploads['baseurl'] ) ? trailingslashit( (string) $uploads['baseurl'] ) : '';
	$basedir = isset( $uploads['basedir'] ) ? trailingslashit( (string) $uploads['basedir'] ) : '';

	if ( '' === $baseurl || '' === $basedir ) {
		return $sources;
	}

	foreach ( $sources as $width => $source ) {
		if ( empty( $source['url'] ) || 0 !== strpos( $source['url'], $baseurl ) ) {
			continue;
		}

		$path = $basedir . substr( $source['url'], strlen( $baseurl ) );
		$path = rawurldecode( $path );

		if ( ! is_readable( $path ) ) {
			unset( $sources[ $width ] );
		}
	}

	return $sources;
}
add_filter( 'wp_calculate_image_srcset', 'muhamedahmed_existing_srcset' );

/**
 * Screenshot markup. Empty when the attachment is missing or not an image.
 *
 * @param int    $post_id  Project id.
 * @param string $title    Project title.
 * @param bool   $featured Featured viewport uses a registered size and is lazy.
 * @return string
 */
function muhamedahmed_viewport_img( $post_id, $title, $featured ) {
	$attachment = (int) get_post_thumbnail_id( $post_id );

	if ( ! $attachment || ! wp_attachment_is_image( $attachment ) ) {
		return muhamedahmed_viewport_placeholder( $title );
	}

	$attrs = array(
		'class'    => 'mah-frame__img',
		'alt'      => $title,
		'decoding' => 'async',
		'loading'  => 'lazy',
	);

	if ( $featured ) {
		$attrs['sizes']         = '(min-width: 1024px) 70vw, 100vw';
		$attrs['fetchpriority'] = 'low';
		$size                   = muhamedahmed_usable_image_size( $attachment, 'large' );
	} else {
		$attrs['sizes']         = '(min-width: 768px) 22rem, 86vw';
		$attrs['fetchpriority'] = 'low';
		$size                   = muhamedahmed_usable_image_size( $attachment, 'medium_large' );
	}

	return wp_get_attachment_image( $attachment, $size, false, $attrs );
}

/**
 * Decorative browser chrome. Hostname is text, not a link.
 *
 * @param string $url Project URL.
 * @return string
 */
function muhamedahmed_frame_chrome( $url ) {
	$host = muhamedahmed_project_hostname( $url );
	$html = '<div class="mah-frame__chrome" aria-hidden="true">';
	$html .= '<span class="mah-frame__dot"></span><span class="mah-frame__dot"></span><span class="mah-frame__dot"></span>';

	if ( '' !== $host ) {
		$html .= '<span class="mah-frame__url">' . esc_html( $host ) . '</span>';
	}

	$html .= '</div>';

	return $html;
}

/**
 * Scroll region wrapping a screenshot.
 *
 * @param string $title Project title.
 * @param string $image Image HTML.
 * @return string
 */
function muhamedahmed_frame_screen( $title, $image ) {
	$label = sprintf(
		/* translators: %s: project title. */
		__( '%s — screenshot, scroll to inspect', 'prowpsite-panel' ),
		$title
	);

	return '<div class="mah-frame__screen" tabindex="0" role="region" aria-label="' . esc_attr( $label ) . '">' . $image . '</div>';
}

/**
 * Viewport meta: title, optional fields, visit link only when a URL exists.
 *
 * @param WP_Post $project Project post.
 * @param string  $url     Project URL.
 * @return string
 */
function muhamedahmed_viewport_meta( $project, $url, $variant = 'rail' ) {
	$id      = (int) $project->ID;
	$title   = get_the_title( $project );
	$client  = muhamedahmed_plain_meta_line( muhamedahmed_meta( $id, 'client' ) );
	$excerpt = get_the_excerpt( $project );
	$tags    = muhamedahmed_plain_meta_line( muhamedahmed_meta( $id, 'tags_line' ) );
	$services = muhamedahmed_plain_meta_line( muhamedahmed_meta( $id, 'services' ) );
	$year    = muhamedahmed_plain_meta_line( muhamedahmed_meta( $id, 'year' ) );
	$type    = '';
	$terms   = get_the_terms( $id, 'mah_project_cat' );

	if ( $terms && ! is_wp_error( $terms ) ) {
		$names = array();

		foreach ( $terms as $term ) {
			if ( $term instanceof WP_Term && '' !== $term->name ) {
				$names[] = $term->name;
			}
		}

		$type = implode( ' · ', $names );
	}

	$html  = '<div class="mah-viewport__meta">';
	$html .= '<h3>' . esc_html( $title ) . '</h3>';

	$type_bits = array_filter( array( $type, $services ? $services : $tags, $year, $client ) );

	if ( $type_bits ) {
		$html .= '<p class="mah-viewport__type">' . esc_html( implode( ' · ', $type_bits ) ) . '</p>';
	}

	if ( 'featured' === $variant ) {
		$lines = array(
			'role'      => muhamedahmed_plain_meta_line( muhamedahmed_meta( $id, 'role' ) ),
			'challenge' => muhamedahmed_plain_meta_line( muhamedahmed_meta( $id, 'challenge' ) ),
			'outcome'   => muhamedahmed_plain_meta_line( muhamedahmed_meta( $id, 'outcome' ) ),
		);

		foreach ( $lines as $line_key => $line_text ) {
			if ( '' === $line_text ) {
				continue;
			}

			$html .= sprintf(
				'<p class="mah-viewport__case mah-viewport__case--%s">%s</p>',
				esc_attr( $line_key ),
				esc_html( $line_text )
			);
		}
	} elseif ( '' !== $excerpt ) {
		$html .= '<p class="mah-viewport__excerpt">' . esc_html( $excerpt ) . '</p>';
	}

	$out_url = $url;

	if ( '' === $out_url ) {
		$permalink = get_permalink( $project );
		$out_url   = is_string( $permalink ) ? $permalink : '';
		if ( '' !== $out_url && function_exists( 'muhamedahmed_permalink' ) ) {
			$out_url = muhamedahmed_permalink( $out_url );
		}
	} elseif ( function_exists( 'muhamedahmed_permalink' ) ) {
		$out_url = muhamedahmed_permalink( $out_url );
	}

	if ( '' !== $out_url ) {
		$case_label = muhamedahmed_option_text( 'mah_home_work_case_label' );

		$html .= sprintf(
			'<a class="mah-viewport__out" href="%s">%s<span class="screen-reader-text"> %s</span></a>',
			esc_url( $out_url ),
			esc_html( '' !== $case_label ? $case_label : $title ),
			esc_html( $title )
		);
	}

	$html .= '</div>';

	return $html;
}

/**
 * One Living Viewport article. The screenshot is never wrapped in a link.
 *
 * @param WP_Post $project  Project post.
 * @param string  $variant  featured|rail.
 * @return string
 */
function muhamedahmed_render_viewport( $project, $variant ) {
	$id      = (int) $project->ID;
	$title   = get_the_title( $project );
	$url     = muhamedahmed_meta( $id, 'url' );
	$image   = muhamedahmed_viewport_img( $id, $title, 'featured' === $variant );
	$classes = 'mah-viewport project mah-viewport--' . sanitize_html_class( $variant );

	$html  = '<article class="' . esc_attr( $classes ) . '">';
	$html .= '<div class="mah-frame">';
	$html .= muhamedahmed_frame_chrome( $url );
	$html .= muhamedahmed_frame_screen( $title, $image );
	$html .= '</div>';

	$html .= muhamedahmed_viewport_meta( $project, $url, $variant );
	$html .= '</article>';

	return $html;
}

/**
 * Published projects with a title, bounded by the block count.
 *
 * @param int $count Max count.
 * @return array<int,WP_Post>
 */
function muhamedahmed_work_projects( $count, $featured_id = 0 ) {
	$count = max( 1, (int) $count );
	$posts = function_exists( 'muhamedahmed_projects_ordered' )
		? muhamedahmed_projects_ordered( max( $count, 20 ) )
		: muhamedahmed_posts( 'mah_project', max( $count, 20 ) );
	$keep  = array();

	foreach ( $posts as $project ) {
		if ( '' === trim( get_the_title( $project ) ) ) {
			continue;
		}

		$keep[] = $project;
	}

	if ( $featured_id ) {
		$first = null;
		$rest  = array();

		foreach ( $keep as $project ) {
			if ( ! $first && (int) $project->ID === (int) $featured_id ) {
				$first = $project;
				continue;
			}

			$rest[] = $project;
		}

		$keep = $first ? array_merge( array( $first ), $rest ) : $rest;
	}

	return array_slice( $keep, 0, $count );
}

/**
 * Work index header: title plus a count badge when any projects exist.
 *
 * @param int $published Published count.
 * @return string
 */
function muhamedahmed_work_head( $published ) {
	$html  = '<header class="mah-work__head">';
	$html .= '<h2 id="mah-work-title">' . esc_html__( 'Selected work', 'prowpsite-panel' ) . '</h2>';

	if ( $published > 0 ) {
		$html .= '<p class="mah-work__count">' . esc_html( (string) $published ) . '</p>';
	}

	$html .= '</header>';

	return $html;
}

/**
 * Render the work block from the projects CPT. Inner content is discarded.
 *
 * @param array  $attributes Block attributes.
 * @param string $content    Unused inner markup.
 * @return string
 */
function muhamedahmed_render_work( $attributes, $content ) {
	unset( $content );

	$a        = wp_parse_args(
		$attributes,
		array(
			'count'    => 6,
			'featured' => 0,
			'bare'     => false,
		)
	);
	$projects = muhamedahmed_work_projects( max( 1, absint( $a['count'] ) ), absint( $a['featured'] ) );

	if ( ! $projects ) {
		return '';
	}

	$featured       = array_shift( $projects );
	$featured_id    = (int) $featured->ID;
	$featured_title = strtolower( trim( get_the_title( $featured ) ) );
	$rail           = array();

	foreach ( $projects as $project ) {
		if ( (int) $project->ID === $featured_id ) {
			continue;
		}

		if ( $featured_title && strtolower( trim( get_the_title( $project ) ) ) === $featured_title ) {
			continue;
		}

		$rail[] = $project;
	}

	$projects = $rail;
	$attrs    = array( 'class' => 'mah-work' );

	if ( empty( $a['bare'] ) ) {
		$attrs['aria-labelledby'] = 'mah-work-title';
	}

	$html  = '<div ' . get_block_wrapper_attributes( $attrs ) . '>';

	if ( empty( $a['bare'] ) ) {
		$html .= muhamedahmed_work_head( muhamedahmed_project_publish_count() );
	}

	$html .= muhamedahmed_render_viewport( $featured, 'featured' );

	if ( $projects ) {
		$html .= '<div class="mah-work__rail-wrap">';
		$html .= '<button type="button" class="mah-work__rail-btn" data-mah-rail-prev aria-label="' . esc_attr__( 'Previous projects', 'prowpsite-panel' ) . '">';
		$html .= '<span aria-hidden="true">‹</span></button>';
		$html .= '<div class="mah-work__rail" tabindex="0" aria-label="' . esc_attr__( 'More projects', 'prowpsite-panel' ) . '" data-mah-rail>';

		foreach ( $projects as $project ) {
			$html .= muhamedahmed_render_viewport( $project, 'rail' );
		}

		$html .= '</div>';
		$html .= '<button type="button" class="mah-work__rail-btn" data-mah-rail-next aria-label="' . esc_attr__( 'Next projects', 'prowpsite-panel' ) . '">';
		$html .= '<span aria-hidden="true">›</span></button>';
		$html .= '</div>';
		$html .= '<div class="mah-work__rail-progress" aria-hidden="true"><span></span></div>';
	}

	$html .= '</div>';

	return $html;
}

/**
 * Register the work block.
 *
 * @return void
 */
function muhamedahmed_register_work_block() {
	register_block_type(
		'muhamedahmed/work',
		array(
			'api_version'     => 3,
			'title'           => __( 'Project Index', 'prowpsite-panel' ),
			'description'     => __( 'Selected work as living viewports. Projects come from the Projects post type.', 'prowpsite-panel' ),
			'category'        => 'design',
			'icon'            => 'portfolio',
			'keywords'        => array( 'work', 'projects', 'portfolio', 'mah' ),
			'supports'        => array(
				'align'           => true,
				'anchor'          => true,
				'html'            => false,
				'customClassName' => true,
			),
			'attributes'      => array(
				'count' => array( 'type' => 'number', 'default' => 6 ),
			),
			'render_callback' => 'muhamedahmed_render_work',
			'editor_script'   => 'mah-blocks',
			'style'           => 'mah-blocks',
			'view_script'     => 'mah-viewport',
		)
	);
}

/* -------------------------------------------------------------------------
 * Boot
 * ---------------------------------------------------------------------- */

/**
 * Register blocks.
 *
 * @return void
 */
function muhamedahmed_blocks_register() {
	muhamedahmed_blocks_register_assets();

	muhamedahmed_register_hero_block();
	muhamedahmed_register_section_block();
	muhamedahmed_register_marquee_block();
	muhamedahmed_register_stats_block();
	muhamedahmed_register_about_block();
	muhamedahmed_register_work_block();
}
add_action( 'init', 'muhamedahmed_blocks_register' );

/**
 * Editor script for all blocks.
 *
 * @return void
 */
function muhamedahmed_blocks_editor_assets() {
	wp_enqueue_script(
		'mah-blocks',
		MUHAMEDAHMED_BLOCKS_URL . 'assets/editor.js',
		array( 'wp-blocks', 'wp-element', 'wp-block-editor', 'wp-components', 'wp-i18n', 'wp-data' ),
		MUHAMEDAHMED_BLOCKS_VERSION,
		true
	);
}
add_action( 'enqueue_block_editor_assets', 'muhamedahmed_blocks_editor_assets' );

/**
 * Preload the homepage portrait so it can be LCP without waiting on CSS.
 *
 * @return void
 */
function muhamedahmed_preload_portrait() {
	if ( ! is_front_page() || ! function_exists( 'muhamedahmed_portrait_id' ) ) {
		return;
	}

	$id = muhamedahmed_portrait_id( 0 );

	if ( $id < 1 ) {
		return;
	}

	$size = muhamedahmed_usable_image_size( $id, 'large' );
	$src  = wp_get_attachment_image_src( $id, $size );

	if ( ! is_array( $src ) || empty( $src[0] ) ) {
		return;
	}

	printf(
		'<link rel="preload" as="image" href="%s" fetchpriority="high">' . "\n",
		esc_url( $src[0] )
	);
}
add_action( 'wp_head', 'muhamedahmed_preload_portrait', 2 );

/**
 * Front-end styles.
 *
 * @return void
 */
function muhamedahmed_blocks_front_assets() {
	wp_enqueue_style( 'mah-blocks' );
	wp_enqueue_style( 'mah-home' );

	$needs_viewport = is_front_page()
		|| ( is_singular() && function_exists( 'has_block' ) && has_block( 'muhamedahmed/work' ) );

	if ( $needs_viewport ) {
		wp_enqueue_script( 'mah-viewport' );
	}

	if ( is_front_page() && function_exists( 'muhamedahmed_home_motion_config' ) ) {
		wp_enqueue_script( 'mah-motion' );
		wp_localize_script(
			'mah-motion',
			'mahMotion',
			array(
				'fx' => muhamedahmed_home_motion_config(),
			)
		);
	}
}
add_action( 'wp_enqueue_scripts', 'muhamedahmed_blocks_front_assets', 20 );
