<?php
/**
 * Pure presentation helpers for ratings, CTA copy, and Astra layout meta.
 *
 * @package MuhamedAhmed_Blocks
 */

defined( 'ABSPATH' ) || exit;

if ( ! defined( 'MUHAMEDAHMED_PORTRAIT_OBJECT_POSITION' ) ) {
	define( 'MUHAMEDAHMED_PORTRAIT_OBJECT_POSITION', '50% 35%' );
}

/**
 * Clamp a stored rating to 1–5. Empty or out of range is 0 (no stars).
 *
 * @param mixed $raw Stored _mah_rating value.
 * @return int
 */
function muhamedahmed_normalize_rating( $raw ) {
	if ( '' === $raw || null === $raw || false === $raw ) {
		return 0;
	}

	if ( ! is_numeric( $raw ) ) {
		return 0;
	}

	$rating = (int) $raw;

	if ( $rating < 1 || $rating > 5 ) {
		return 0;
	}

	return $rating;
}

/**
 * Inline check icon for about reason cards.
 *
 * @return string
 */
function muhamedahmed_check_icon() {
	return '<span class="mah-check" aria-hidden="true"><svg viewBox="0 0 20 20" width="14" height="14" focusable="false"><path fill="currentColor" d="M8.1 13.6 4.9 10.4l1.1-1.1 2.1 2.1 5.3-5.4 1.1 1.1z"/></svg></span>';
}

/**
 * Five SVG stars with an accessible name. Empty rating renders nothing.
 *
 * @param mixed $raw Stored rating.
 * @return string
 */
function muhamedahmed_stars_markup( $raw ) {
	$rating = muhamedahmed_normalize_rating( $raw );

	if ( $rating < 1 ) {
		return '';
	}

	$label  = sprintf(
		/* translators: %d: star rating out of five. */
		_n( 'Rated %d out of 5', 'Rated %d out of 5', $rating, 'prowpsite-panel' ),
		$rating
	);

	$path = 'M12 2.1l2.85 5.78 6.38.93-4.62 4.5 1.09 6.36L12 16.66 6.3 19.67l1.09-6.36-4.62-4.5 6.38-.93L12 2.1z';
	$html = sprintf(
		'<p class="mah-stars" role="img" aria-label="%s">',
		esc_attr( $label )
	);

	for ( $index = 1; $index <= 5; $index++ ) {
		$on    = $index <= $rating;
		$class = $on ? 'mah-star mah-star--on' : 'mah-star mah-star--off';
		$html .= sprintf(
			'<svg class="%s" viewBox="0 0 24 24" width="18" height="18" aria-hidden="true" focusable="false"><path d="%s"/></svg>',
			esc_attr( $class ),
			$path
		);
	}

	$html .= '</p>';

	return $html;
}

/**
 * Collapse CTA copy for near-duplicate detection.
 *
 * @param string $text Copy.
 * @return string
 */
function muhamedahmed_cta_fingerprint( $text ) {
	$text = strtolower( (string) $text );
	$text = preg_replace( '/\b(your|a|the|my)\b/u', '', $text );
	$text = preg_replace( '/[^a-z0-9]+/u', '', $text );

	return is_string( $text ) ? $text : '';
}

/**
 * Visible contact heading. Empty or CTA-paraphrase values use the UI label.
 *
 * @param string $headline mah_footer_headline.
 * @param string $cta      Identity cta_label.
 * @return string
 */
function muhamedahmed_cta_heading( $headline, $cta ) {
	$headline = trim( (string) $headline );
	$cta      = trim( (string) $cta );
	$label    = __( 'Contact', 'prowpsite-panel' );

	if ( '' === $headline ) {
		return $label;
	}

	if ( '' !== $cta && 0 === strcasecmp( $headline, $cta ) ) {
		return $label;
	}

	if ( '' !== $cta && muhamedahmed_cta_fingerprint( $headline ) === muhamedahmed_cta_fingerprint( $cta ) ) {
		return $label;
	}

	return $headline;
}

/**
 * Visible about heading. Empty stored values use the UI label, never invented copy.
 *
 * @param string $stored mah_about_heading.
 * @return string
 */
function muhamedahmed_about_heading( $stored ) {
	$stored = trim( (string) $stored );

	if ( '' === $stored ) {
		return __( 'About', 'prowpsite-panel' );
	}

	return $stored;
}

/**
 * Astra per-page meta that makes section bands full-bleed.
 *
 * @return array<string,string>
 */
function muhamedahmed_astra_page_meta() {
	return array(
		'ast-site-content-layout'       => 'page-builder',
		'site-content-layout'           => 'page-builder',
		'site-content-style'            => 'unboxed',
		'ast-content-style'             => 'unboxed',
		'site-sidebar-layout'           => 'no-sidebar',
		'ast-site-sidebar-layout'       => 'no-sidebar',
		'site-post-title'               => 'disabled',
		'ast-title-bar-display'         => 'disabled',
		'ast-featured-img'              => 'disabled',
		'ast-breadcrumbs-content'       => 'disabled',
		'ast-main-header-display'       => 'disabled',
		'ast-hfb-above-header-display'  => 'disabled',
		'ast-hfb-below-header-display'  => 'disabled',
		'ast-hfb-mobile-header-display' => 'disabled',
		'footer-sml-layout'             => 'disabled',
		'footer-adv-display'            => 'disabled',
		'theme-transparent-header-meta' => 'disabled',
		'ast-migrate-meta-layouts'      => 'default',
	);
}
