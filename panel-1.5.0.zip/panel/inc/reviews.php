<?php
/**
 * Review meta, hide rule, shared query, and admin list columns.
 *
 * Loaded even when the standalone mah-content plugin is still active, so a
 * zip overwrite does not depend on deactivating the old plugin first.
 *
 * @package ProWPSite
 */

defined( 'ABSPATH' ) || exit;

/**
 * Whether the current user may edit this review's meta via REST.
 *
 * @param bool   $allowed  Incoming.
 * @param string $meta_key Meta key.
 * @param int    $post_id  Post id.
 * @return bool
 */
function mah_review_meta_auth( $allowed, $meta_key, $post_id ) {
	unset( $allowed, $meta_key );

	return current_user_can( 'edit_post', (int) $post_id );
}

/**
 * Sanitize rating to 1–5 or empty. Never defaults to 5.
 *
 * @param mixed $value Raw value.
 * @return int|string
 */
function mah_sanitize_rating_meta( $value ) {
	if ( '' === $value || null === $value || false === $value ) {
		return '';
	}

	if ( is_string( $value ) && '' === trim( $value ) ) {
		return '';
	}

	$rating = absint( $value );

	if ( $rating < 1 || $rating > 5 ) {
		return '';
	}

	return $rating;
}

/**
 * Sanitize the home switcher to a REST boolean.
 *
 * @param mixed $value Raw value.
 * @return bool
 */
function mah_sanitize_show_home_meta( $value ) {
	if ( function_exists( 'rest_sanitize_boolean' ) ) {
		return (bool) rest_sanitize_boolean( $value );
	}

	return (bool) $value;
}

/**
 * Sanitize a related project id.
 *
 * @param mixed $value Raw value.
 * @return int
 */
function mah_sanitize_related_project_meta( $value ) {
	return absint( $value );
}

/**
 * Sanitize a source URL: esc_url_raw plus http/https only.
 *
 * @param mixed $value Raw value.
 * @return string
 */
function mah_sanitize_source_url_meta( $value ) {
	if ( ! is_scalar( $value ) ) {
		return '';
	}

	$raw = trim( (string) $value );

	if ( '' === $raw ) {
		return '';
	}

	$clean = esc_url_raw( $raw );

	if ( '' === $clean ) {
		return '';
	}

	if ( function_exists( 'wp_http_validate_url' ) ) {
		$valid = wp_http_validate_url( $clean );

		if ( ! $valid ) {
			return '';
		}

		$clean = $valid;
	}

	$parts = function_exists( 'wp_parse_url' ) ? wp_parse_url( $clean ) : parse_url( $clean );

	if ( ! is_array( $parts ) || empty( $parts['scheme'] ) ) {
		return '';
	}

	$scheme = strtolower( (string) $parts['scheme'] );

	if ( 'http' !== $scheme && 'https' !== $scheme ) {
		return '';
	}

	return $clean;
}

/**
 * Trimmed reviewer name. Empty or whitespace is not a name.
 *
 * @param mixed $name Raw name.
 * @return string
 */
function muhamedahmed_review_display_name( $name ) {
	return is_scalar( $name ) ? trim( (string) $name ) : '';
}

/**
 * Trimmed quote with tags stripped. Empty quote is not displayable.
 *
 * @param mixed $quote Raw quote / post content.
 * @return string
 */
function muhamedahmed_review_display_quote( $quote ) {
	$text = is_scalar( $quote ) ? (string) $quote : '';

	if ( function_exists( 'wp_strip_all_tags' ) ) {
		$text = wp_strip_all_tags( $text );
	}

	return trim( $text );
}

/**
 * Hide rule: a review is shown only when name and quote are both non-empty.
 *
 * @param mixed $name  Reviewer name.
 * @param mixed $quote Quote / content.
 * @return bool
 */
function muhamedahmed_review_fields_are_visible( $name, $quote ) {
	return '' !== muhamedahmed_review_display_name( $name )
		&& '' !== muhamedahmed_review_display_quote( $quote );
}

/**
 * Whether a review post may be rendered on the front end.
 *
 * @param WP_Post|object $post Review post.
 * @return bool
 */
function muhamedahmed_review_post_is_displayable( $post ) {
	if ( ! is_object( $post ) || empty( $post->ID ) ) {
		return false;
	}

	$name = function_exists( 'get_post_meta' )
		? get_post_meta( (int) $post->ID, '_mah_author', true )
		: '';
	$quote = isset( $post->post_content ) ? $post->post_content : '';

	return muhamedahmed_review_fields_are_visible( $name, $quote );
}

/**
 * Normalize home/block order to priority, newest, or random.
 *
 * @param mixed $order Raw order.
 * @return string
 */
function muhamedahmed_reviews_normalize_order( $order ) {
	$order = is_scalar( $order ) ? strtolower( trim( (string) $order ) ) : 'priority';

	if ( in_array( $order, array( 'priority', 'newest', 'random' ), true ) ) {
		return $order;
	}

	return 'priority';
}

/**
 * Sort fixture/query rows the same way the SQL orderby does.
 *
 * Random uses this PHP list (priority). Shuffle happens in motion.js.
 *
 * @param array<int,array<string,mixed>> $rows  Rows with id, name, quote, priority, date, menu_order.
 * @param string                         $order priority|newest|random.
 * @return array<int,string>
 */
function muhamedahmed_reviews_ordered_ids_from_rows( array $rows, $order ) {
	$visible = array();

	foreach ( $rows as $row ) {
		if ( ! is_array( $row ) ) {
			continue;
		}

		$name  = isset( $row['name'] ) ? $row['name'] : '';
		$quote = isset( $row['quote'] ) ? $row['quote'] : '';

		if ( ! muhamedahmed_review_fields_are_visible( $name, $quote ) ) {
			continue;
		}

		$visible[] = $row;
	}

	$order = muhamedahmed_reviews_normalize_order( $order );

	usort(
		$visible,
		static function ( $left, $right ) use ( $order ) {
			$left_menu  = isset( $left['menu_order'] ) ? (int) $left['menu_order'] : 0;
			$right_menu = isset( $right['menu_order'] ) ? (int) $right['menu_order'] : 0;
			$left_date  = isset( $left['date'] ) ? (string) $left['date'] : '';
			$right_date = isset( $right['date'] ) ? (string) $right['date'] : '';

			if ( 'newest' === $order ) {
				$by_date = strcmp( $right_date, $left_date );

				if ( 0 !== $by_date ) {
					return $by_date;
				}

				if ( $left_menu !== $right_menu ) {
					return $left_menu - $right_menu;
				}

				return strcmp( (string) $left['id'], (string) $right['id'] );
			}

			$left_prio  = isset( $left['priority'] ) ? (int) $left['priority'] : 0;
			$right_prio = isset( $right['priority'] ) ? (int) $right['priority'] : 0;

			if ( $left_prio !== $right_prio ) {
				return $left_prio - $right_prio;
			}

			if ( $left_menu !== $right_menu ) {
				return $left_menu - $right_menu;
			}

			$by_date = strcmp( $right_date, $left_date );

			if ( 0 !== $by_date ) {
				return $by_date;
			}

			return strcmp( (string) $left['id'], (string) $right['id'] );
		}
	);

	$ids = array();

	foreach ( $visible as $row ) {
		$ids[] = (string) $row['id'];
	}

	return $ids;
}

/**
 * Meta query that excludes empty reviewer names.
 *
 * @return array<string,mixed>
 */
function muhamedahmed_reviews_name_meta_query() {
	return array(
		'key'     => '_mah_author',
		'value'   => '',
		'compare' => '!=',
	);
}

/**
 * Meta query for reviews marked show-on-home. Missing meta counts as on.
 *
 * @return array<string,mixed>
 */
function muhamedahmed_reviews_home_meta_query() {
	return array(
		'relation' => 'OR',
		array(
			'key'     => '_mah_show_home',
			'compare' => 'NOT EXISTS',
		),
		array(
			'key'     => '_mah_show_home',
			'value'   => 1,
			'type'    => 'NUMERIC',
			'compare' => '=',
		),
	);
}

/**
 * Named priority clause so missing meta sorts as 0.
 *
 * @return array<string,mixed>
 */
function muhamedahmed_reviews_priority_clause() {
	return array(
		'relation' => 'OR',
		array(
			'key'     => '_mah_priority',
			'compare' => 'NOT EXISTS',
		),
		array(
			'key'     => '_mah_priority',
			'type'    => 'NUMERIC',
			'compare' => 'EXISTS',
		),
	);
}

/**
 * Shared WP_Query args for displayable reviews.
 *
 * @param array<string,mixed> $args Overrides. order, home_only, posts_per_page.
 * @return array<string,mixed>
 */
function muhamedahmed_reviews_query_args( $args = array() ) {
	if ( ! is_array( $args ) ) {
		$args = array();
	}

	$order     = muhamedahmed_reviews_normalize_order( isset( $args['order'] ) ? $args['order'] : 'priority' );
	$home_only = ! empty( $args['home_only'] );

	unset( $args['order'], $args['home_only'] );

	$meta_query = array(
		'relation'          => 'AND',
		'mah_author_clause' => muhamedahmed_reviews_name_meta_query(),
	);

	if ( $home_only ) {
		$meta_query['mah_home_clause'] = muhamedahmed_reviews_home_meta_query();
	}

	$defaults = array(
		'post_type'           => 'mah_review',
		'post_status'         => 'publish',
		'ignore_sticky_posts' => true,
		'suppress_filters'    => false,
		'meta_query'          => $meta_query,
		'mah_review_visible'  => 1,
		'mah_review_order'    => $order,
	);

	if ( 'newest' === $order ) {
		$defaults['orderby'] = array(
			'date'       => 'DESC',
			'menu_order' => 'ASC',
		);
	} else {
		$meta_query['mah_priority_clause'] = muhamedahmed_reviews_priority_clause();
		$defaults['meta_query']            = $meta_query;
		$defaults['orderby']               = array(
			'mah_priority_clause' => 'ASC',
			'menu_order'          => 'ASC',
			'date'                => 'DESC',
		);
	}

	return array_merge( $defaults, $args );
}

/**
 * COALESCE missing priority to 0. Random still uses this SQL order.
 *
 * @param array<string,string> $clauses Query clauses.
 * @param WP_Query             $query   Query.
 * @return array<string,string>
 */
function muhamedahmed_reviews_posts_clauses( $clauses, $query ) {
	if ( ! $query instanceof WP_Query || ! $query->get( 'mah_review_order' ) ) {
		return $clauses;
	}

	$order = muhamedahmed_reviews_normalize_order( $query->get( 'mah_review_order' ) );

	if ( 'newest' === $order ) {
		return $clauses;
	}

	global $wpdb;

	$clauses['join']   .= " LEFT JOIN {$wpdb->postmeta} AS mah_rev_prio ON ({$wpdb->posts}.ID = mah_rev_prio.post_id AND mah_rev_prio.meta_key = '_mah_priority') ";
	$clauses['orderby'] = "CAST(COALESCE(mah_rev_prio.meta_value,0) AS SIGNED) ASC, {$wpdb->posts}.menu_order ASC, {$wpdb->posts}.post_date DESC";
	$clauses['groupby'] = "{$wpdb->posts}.ID";

	return $clauses;
}

/**
 * Drop empty-quote rows in SQL. Whitespace names are caught in the_posts.
 *
 * @param string   $where Where clause.
 * @param WP_Query $query Query.
 * @return string
 */
function muhamedahmed_reviews_posts_where( $where, $query ) {
	if ( ! $query instanceof WP_Query || ! $query->get( 'mah_review_visible' ) ) {
		return $where;
	}

	global $wpdb;

	$where .= " AND TRIM({$wpdb->posts}.post_content) <> '' ";

	return $where;
}

/**
 * Whether this request is public front-end or public REST (not the editor).
 *
 * @return bool
 */
function muhamedahmed_reviews_is_public_request() {
	if ( function_exists( 'is_admin' ) && is_admin() ) {
		return false;
	}

	if ( defined( 'REST_REQUEST' ) && REST_REQUEST && function_exists( 'current_user_can' ) && current_user_can( 'edit_posts' ) ) {
		return false;
	}

	return true;
}

/**
 * Render guard for every front-end / public REST review list.
 *
 * @param array<int,WP_Post> $posts Posts.
 * @param WP_Query           $query Query.
 * @return array<int,WP_Post>
 */
function muhamedahmed_reviews_the_posts( $posts, $query ) {
	if ( ! $query instanceof WP_Query || ! is_array( $posts ) ) {
		return $posts;
	}

	$type      = $query->get( 'post_type' );
	$is_review = ( 'mah_review' === $type ) || ( is_array( $type ) && in_array( 'mah_review', $type, true ) );

	if ( ! $is_review && ! $query->get( 'mah_review_visible' ) ) {
		return $posts;
	}

	$force_hide = (bool) $query->get( 'mah_review_visible' );

	if ( ! $force_hide && ! muhamedahmed_reviews_is_public_request() ) {
		return $posts;
	}

	$kept = array();

	foreach ( $posts as $post ) {
		if ( muhamedahmed_review_post_is_displayable( $post ) ) {
			$kept[] = $post;
		}
	}

	return $kept;
}

/**
 * Published, displayable reviews in the requested order.
 *
 * @param array<string,mixed> $args count, order, home_only.
 * @return array<int,WP_Post>
 */
function muhamedahmed_reviews_ordered( $args = array() ) {
	if ( ! is_array( $args ) ) {
		$args = array();
	}

	$count = isset( $args['count'] ) ? (int) $args['count'] : 6;
	$count = max( 1, min( 40, $count ) );

	$posts = get_posts(
		muhamedahmed_reviews_query_args(
			array(
				'posts_per_page' => $count,
				'no_found_rows'  => true,
				'order'          => isset( $args['order'] ) ? $args['order'] : 'priority',
				'home_only'      => ! empty( $args['home_only'] ),
			)
		)
	);

	return is_array( $posts ) ? $posts : array();
}

/**
 * Apply the hide rule to front-end review queries, including the old renderer.
 *
 * @param WP_Query $query Query.
 * @return void
 */
function muhamedahmed_reviews_pre_get_posts( $query ) {
	if ( ! $query instanceof WP_Query ) {
		return;
	}

	$type      = $query->get( 'post_type' );
	$is_review = ( 'mah_review' === $type ) || ( is_array( $type ) && in_array( 'mah_review', $type, true ) );

	if ( ! $is_review ) {
		return;
	}

	$is_rest = ( defined( 'REST_REQUEST' ) && REST_REQUEST );

	if ( function_exists( 'is_admin' ) && is_admin() && ! $is_rest ) {
		if ( ! $query->is_main_query() ) {
			return;
		}

		if ( 'mah_priority' === $query->get( 'orderby' ) ) {
			$order = strtoupper( (string) $query->get( 'order' ) );
			$order = 'DESC' === $order ? 'DESC' : 'ASC';
			$query->set( 'meta_key', '_mah_priority' );
			$query->set(
				'orderby',
				array(
					'meta_value_num' => $order,
					'menu_order'     => 'ASC',
				)
			);
		}

		return;
	}

	if ( $query->get( 'mah_review_visible' ) ) {
		return;
	}

	$existing = $query->get( 'meta_query' );
	$hide     = array(
		'relation'          => 'AND',
		'mah_author_clause' => muhamedahmed_reviews_name_meta_query(),
	);

	if ( is_array( $existing ) && $existing ) {
		$hide[] = $existing;
	}

	$query->set( 'meta_query', $hide );
	$query->set( 'mah_review_visible', 1 );
}

/**
 * REST list uses the same hide rule.
 *
 * @param array<string,mixed> $args    Query args.
 * @param WP_REST_Request     $request Request.
 * @return array<string,mixed>
 */
function muhamedahmed_reviews_rest_query( $args, $request ) {
	unset( $request );

	$shared = muhamedahmed_reviews_query_args(
		array(
			'order'     => 'priority',
			'home_only' => false,
		)
	);

	$args['meta_query']         = $shared['meta_query'];
	$args['mah_review_visible'] = 1;
	$args['mah_review_order']   = 'priority';

	return $args;
}

/**
 * REST response guard: nameless / empty-quote reviews are not emitted.
 *
 * @param WP_REST_Response $response Response.
 * @param WP_Post          $post     Post.
 * @param WP_REST_Request  $request  Request.
 * @return WP_REST_Response
 */
function muhamedahmed_reviews_rest_prepare( $response, $post, $request ) {
	unset( $request );

	$id = ( is_object( $post ) && isset( $post->ID ) ) ? (int) $post->ID : 0;

	if ( $id > 0 && function_exists( 'current_user_can' ) && current_user_can( 'edit_post', $id ) ) {
		return $response;
	}

	if ( ! muhamedahmed_review_post_is_displayable( $post ) ) {
		$data = $response instanceof WP_REST_Response ? $response->get_data() : array();
		unset( $data );
		$response = new WP_REST_Response( null, 404 );
	}

	return $response;
}

/**
 * Register review meta with sanitize + REST + auth. Replaces weaker copies.
 *
 * @return void
 */
function mah_register_review_front_meta() {
	$object = 'post';
	$keys   = array(
		'_mah_author',
		'_mah_role',
		'_mah_rating',
		'_mah_highlight',
		'_mah_source',
		'_mah_priority',
		'_mah_show_home',
		'_mah_project',
	);

	foreach ( $keys as $key ) {
		if ( function_exists( 'unregister_meta_key' ) ) {
			unregister_meta_key( $object, $key );
		}
	}

	$auth = 'mah_review_meta_auth';

	register_post_meta(
		'mah_review',
		'_mah_author',
		array(
			'type'              => 'string',
			'single'            => true,
			'show_in_rest'      => true,
			'sanitize_callback' => 'sanitize_text_field',
			'auth_callback'     => $auth,
			'default'           => '',
		)
	);

	register_post_meta(
		'mah_review',
		'_mah_role',
		array(
			'type'              => 'string',
			'single'            => true,
			'show_in_rest'      => true,
			'sanitize_callback' => 'sanitize_text_field',
			'auth_callback'     => $auth,
			'default'           => '',
		)
	);

	register_post_meta(
		'mah_review',
		'_mah_rating',
		array(
			'type'              => 'integer',
			'single'            => true,
			'show_in_rest'      => true,
			'sanitize_callback' => 'mah_sanitize_rating_meta',
			'auth_callback'     => $auth,
		)
	);

	register_post_meta(
		'mah_review',
		'_mah_highlight',
		array(
			'type'              => 'boolean',
			'single'            => true,
			'show_in_rest'      => true,
			'sanitize_callback' => 'rest_sanitize_boolean',
			'auth_callback'     => $auth,
			'default'           => false,
		)
	);

	register_post_meta(
		'mah_review',
		'_mah_source',
		array(
			'type'              => 'string',
			'single'            => true,
			'show_in_rest'      => true,
			'sanitize_callback' => 'mah_sanitize_source_url_meta',
			'auth_callback'     => $auth,
			'default'           => '',
		)
	);

	$priority_cb = function_exists( 'mah_sanitize_priority_meta' )
		? 'mah_sanitize_priority_meta'
		: 'absint';

	register_post_meta(
		'mah_review',
		'_mah_priority',
		array(
			'type'              => 'integer',
			'single'            => true,
			'show_in_rest'      => true,
			'sanitize_callback' => $priority_cb,
			'auth_callback'     => $auth,
			'default'           => 0,
		)
	);

	register_post_meta(
		'mah_review',
		'_mah_show_home',
		array(
			'type'              => 'boolean',
			'single'            => true,
			'show_in_rest'      => true,
			'sanitize_callback' => 'mah_sanitize_show_home_meta',
			'auth_callback'     => $auth,
			'default'           => true,
		)
	);

	register_post_meta(
		'mah_review',
		'_mah_project',
		array(
			'type'              => 'integer',
			'single'            => true,
			'show_in_rest'      => true,
			'sanitize_callback' => 'mah_sanitize_related_project_meta',
			'auth_callback'     => $auth,
			'default'           => 0,
		)
	);
}

/**
 * Admin list columns.
 *
 * @param array<string,string> $columns Columns.
 * @return array<string,string>
 */
function mah_review_posts_columns( $columns ) {
	$out = array();

	foreach ( $columns as $key => $label ) {
		$out[ $key ] = $label;

		if ( 'title' === $key ) {
			$out['mah_author']   = __( 'Name', 'prowpsite-panel' );
			$out['mah_rating']   = __( 'Rating', 'prowpsite-panel' );
			$out['mah_priority'] = __( 'Priority', 'prowpsite-panel' );
			$out['mah_home']     = __( 'Show on home', 'prowpsite-panel' );
			$out['mah_hidden']   = __( 'Hidden: no name', 'prowpsite-panel' );
		}
	}

	if ( ! isset( $out['mah_author'] ) ) {
		$out['mah_author']   = __( 'Name', 'prowpsite-panel' );
		$out['mah_rating']   = __( 'Rating', 'prowpsite-panel' );
		$out['mah_priority'] = __( 'Priority', 'prowpsite-panel' );
		$out['mah_home']     = __( 'Show on home', 'prowpsite-panel' );
		$out['mah_hidden']   = __( 'Hidden: no name', 'prowpsite-panel' );
	}

	return $out;
}

/**
 * Admin list cell output.
 *
 * @param string $column  Column id.
 * @param int    $post_id Post id.
 * @return void
 */
function mah_review_posts_custom_column( $column, $post_id ) {
	$post_id = (int) $post_id;
	$name    = muhamedahmed_review_display_name( get_post_meta( $post_id, '_mah_author', true ) );

	if ( 'mah_author' === $column ) {
		echo '' === $name ? esc_html( '—' ) : esc_html( $name );
		return;
	}

	if ( 'mah_rating' === $column ) {
		$rating = mah_sanitize_rating_meta( get_post_meta( $post_id, '_mah_rating', true ) );
		echo '' === $rating ? esc_html( '—' ) : esc_html( (string) $rating );
		return;
	}

	if ( 'mah_priority' === $column ) {
		$raw = get_post_meta( $post_id, '_mah_priority', true );
		echo esc_html( (string) absint( '' === $raw ? 0 : $raw ) );
		return;
	}

	if ( 'mah_home' === $column ) {
		if ( ! metadata_exists( 'post', $post_id, '_mah_show_home' ) ) {
			$flag = true;
		} else {
			$flag = rest_sanitize_boolean( get_post_meta( $post_id, '_mah_show_home', true ) );
		}

		echo $flag ? esc_html( '●' ) : esc_html( '—' );
		return;
	}

	if ( 'mah_hidden' === $column ) {
		echo '' === $name ? esc_html__( 'Hidden: no name', 'prowpsite-panel' ) : esc_html( '—' );
	}
}

/**
 * Sortable Priority column. menu_order remains the drag-order tie-breaker.
 *
 * @param array<string,string> $columns Columns.
 * @return array<string,string>
 */
function mah_review_sortable_columns( $columns ) {
	$columns['mah_priority'] = 'mah_priority';

	return $columns;
}

/**
 * Write defaults for missing priority / show-on-home.
 *
 * @param int     $post_id Post id.
 * @param WP_Post $post    Post.
 * @return void
 */
function mah_review_backfill_order_meta( $post_id, $post ) {
	if ( ! $post instanceof WP_Post || 'mah_review' !== $post->post_type ) {
		return;
	}

	if ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) {
		return;
	}

	if ( ! metadata_exists( 'post', $post_id, '_mah_priority' ) ) {
		update_post_meta( $post_id, '_mah_priority', 0 );
	}

	if ( ! metadata_exists( 'post', $post_id, '_mah_show_home' ) ) {
		update_post_meta( $post_id, '_mah_show_home', 1 );
	}
}

/**
 * Front-end reviews markup. Used by the block, shortcode, and home section.
 *
 * @param array<string,mixed> $atts count, order, home_only.
 * @return string
 */
function muhamedahmed_reviews_markup( $atts = array() ) {
	if ( ! is_array( $atts ) ) {
		$atts = array();
	}

	$count     = isset( $atts['count'] ) ? max( 1, min( 40, (int) $atts['count'] ) ) : 6;
	$order     = muhamedahmed_reviews_normalize_order( isset( $atts['order'] ) ? $atts['order'] : 'priority' );
	$home_only = ! empty( $atts['home_only'] );
	$reviews   = muhamedahmed_reviews_ordered(
		array(
			'count'     => $count,
			'order'     => $order,
			'home_only' => $home_only,
		)
	);

	if ( ! $reviews ) {
		return '';
	}

	$cards = array();

	foreach ( $reviews as $review ) {
		$id     = (int) $review->ID;
		$quote  = muhamedahmed_review_display_quote( $review->post_content );
		$author = muhamedahmed_review_display_name(
			function_exists( 'mah_review_meta' )
				? mah_review_meta( $id, 'author' )
				: get_post_meta( $id, '_mah_author', true )
		);

		if ( ! muhamedahmed_review_fields_are_visible( $author, $quote ) ) {
			continue;
		}

		$source = function_exists( 'mah_review_meta' )
			? mah_review_meta( $id, 'source' )
			: get_post_meta( $id, '_mah_source', true );
		$source = mah_sanitize_source_url_meta( $source );

		$cards[] = array(
			'quote'  => $quote,
			'author' => $author,
			'role'   => function_exists( 'mah_review_meta' )
				? mah_review_meta( $id, 'role' )
				: get_post_meta( $id, '_mah_role', true ),
			'source' => $source,
			'rating' => function_exists( 'mah_review_meta' )
				? mah_review_meta( $id, 'rating' )
				: get_post_meta( $id, '_mah_rating', true ),
			'lime'   => function_exists( 'mah_content_is_highlight' )
				? mah_content_is_highlight(
					function_exists( 'mah_review_meta' )
						? mah_review_meta( $id, 'highlight', false )
						: get_post_meta( $id, '_mah_highlight', true )
				)
				: false,
		);
	}

	$card_count = count( $cards );

	if ( 0 === $card_count ) {
		return '';
	}

	$shuffle = 'random' === $order ? '1' : '0';
	$html    = sprintf(
		'<div class="mah-rev-grid" data-mah-count="%d" data-mah-reviews-order="%s" data-mah-reviews-shuffle="%s">',
		$card_count,
		esc_attr( $order ),
		esc_attr( $shuffle )
	);

	foreach ( $cards as $index => $card ) {
		$class = 'mah-rev__card review' . ( $card['lime'] ? ' mah-rev__card--lime' : '' );

		if ( '1' !== $shuffle && function_exists( 'mah_content_review_span_class' ) ) {
			$span = mah_content_review_span_class( $index, $card_count );

			if ( '' !== $span ) {
				$class .= ' ' . $span;
			}

			if ( 0 === $index && false !== strpos( $class, 'span-2' ) ) {
				$class .= ' mah-rev__card--feature';
			}
		}

		$html .= sprintf( '<figure class="%s">', esc_attr( $class ) );
		$html .= function_exists( 'mah_content_stars_markup' )
			? mah_content_stars_markup( $card['rating'] )
			: '';
		$html .= '<blockquote><p class="mah-rev__quote">' . esc_html( $card['quote'] ) . '</p></blockquote>';

		if ( strlen( $card['quote'] ) > 220 ) {
			$html .= '<details class="mah-rev__more"><summary>' . esc_html__( 'Full review', 'prowpsite-panel' ) . '</summary>';
			$html .= '<p>' . esc_html( $card['quote'] ) . '</p></details>';
		}

		$html .= '<figcaption class="mah-rev__by">';
		$html .= '<span class="mah-rev__name">' . esc_html( $card['author'] ) . '</span>';

		if ( $card['role'] ) {
			$html .= '<span class="mah-rev__role">' . esc_html( $card['role'] ) . '</span>';
		}

		if ( $card['source'] ) {
			$html .= sprintf(
				'<a class="mah-rev__source" href="%s" rel="noopener noreferrer">%s</a>',
				esc_url( $card['source'] ),
				esc_html( $card['source'] )
			);
		}

		$html .= '</figcaption>';
		$html .= '</figure>';
	}

	$html .= '</div>';

	return $html;
}

if ( function_exists( 'add_action' ) ) {
	add_action( 'init', 'mah_register_review_front_meta', 12 );
	add_action( 'pre_get_posts', 'muhamedahmed_reviews_pre_get_posts' );
	add_action( 'manage_mah_review_posts_custom_column', 'mah_review_posts_custom_column', 10, 2 );
	add_action( 'save_post_mah_review', 'mah_review_backfill_order_meta', 20, 2 );
}

if ( function_exists( 'add_filter' ) ) {
	add_filter( 'posts_clauses', 'muhamedahmed_reviews_posts_clauses', 10, 2 );
	add_filter( 'posts_where', 'muhamedahmed_reviews_posts_where', 10, 2 );
	add_filter( 'the_posts', 'muhamedahmed_reviews_the_posts', 10, 2 );
	add_filter( 'rest_mah_review_query', 'muhamedahmed_reviews_rest_query', 10, 2 );
	add_filter( 'rest_prepare_mah_review', 'muhamedahmed_reviews_rest_prepare', 10, 3 );
	add_filter( 'manage_mah_review_posts_columns', 'mah_review_posts_columns' );
	add_filter( 'manage_edit-mah_review_sortable_columns', 'mah_review_sortable_columns' );
}
