<?php
/**
 * Projects as a custom post type.
 *
 * Projects were previously written into the page content by a build script,
 * which meant editing a project meant editing PHP. As a post type they are
 * added, reordered and edited in the normal WordPress admin, and the block
 * renders whatever is published.
 *
 * @package MuhamedAhmed_Content
 */

defined( 'ABSPATH' ) || exit;

/**
 * Register the project post type.
 *
 * @return void
 */
function mah_register_project() {
	register_post_type(
		'mah_project',
		array(
			'labels'        => array(
				'name'               => __( 'Projects', 'prowpsite-panel' ),
				'singular_name'      => __( 'Project', 'prowpsite-panel' ),
				'add_new'            => __( 'Add project', 'prowpsite-panel' ),
				'add_new_item'       => __( 'Add new project', 'prowpsite-panel' ),
				'edit_item'          => __( 'Edit project', 'prowpsite-panel' ),
				'new_item'           => __( 'New project', 'prowpsite-panel' ),
				'view_item'          => __( 'View project', 'prowpsite-panel' ),
				'search_items'       => __( 'Search projects', 'prowpsite-panel' ),
				'not_found'          => __( 'No projects yet', 'prowpsite-panel' ),
				'not_found_in_trash' => __( 'Nothing in the bin', 'prowpsite-panel' ),
				'menu_name'          => __( 'Projects', 'prowpsite-panel' ),
			),
			'public'        => true,
			'show_in_rest'  => true,
			'has_archive'   => false,
			'hierarchical'  => false,
			'menu_icon'     => 'dashicons-portfolio',
			'menu_position' => 26,
			'supports'      => array( 'title', 'editor', 'thumbnail', 'excerpt', 'page-attributes', 'revisions' ),
			'rewrite'       => array( 'slug' => 'work' ),
			'show_in_menu'  => true,
		)
	);
}
/*
 * Builder seed (inc/upgrade.php) writes this same CPT into muhamed_ahmed_panel
 * so the owner can add categories and fields from the UI. Registration stays
 * here: DynamicRegistrationManager skips existing types, uses with_front false,
 * defaults has_archive on, and the CPT class is a no-op stub. Existing /work/
 * permalinks must not change.
 */
add_action( 'init', 'mah_register_project' );

/**
 * Register the fields a project carries beyond the title and image.
 *
 * @return void
 */
function mah_register_project_meta() {
	register_post_meta(
		'mah_project',
		'_mah_client',
		array(
			'type'              => 'string',
			'single'            => true,
			'show_in_rest'      => true,
			'sanitize_callback' => 'sanitize_text_field',
			'default'           => '',
		)
	);

	register_post_meta(
		'mah_project',
		'_mah_url',
		array(
			'type'              => 'string',
			'single'            => true,
			'show_in_rest'      => true,
			'sanitize_callback' => 'esc_url_raw',
			'default'           => '',
		)
	);

	register_post_meta(
		'mah_project',
		'_mah_tags_line',
		array(
			'type'              => 'string',
			'single'            => true,
			'show_in_rest'      => true,
			'sanitize_callback' => 'sanitize_text_field',
			'default'           => '',
		)
	);
}
add_action( 'init', 'mah_register_project_meta' );

/**
 * Read one project field with a fallback.
 *
 * @param int    $post_id Project id.
 * @param string $key     Meta key without the prefix.
 * @return string
 */
function mah_project_meta( $post_id, $key ) {
	$value = get_post_meta( $post_id, '_mah_' . $key, true );

	if ( ! is_string( $value ) ) {
		return '';
	}

	if ( 'url' === $key && function_exists( 'muhamedahmed_permalink' ) ) {
		return muhamedahmed_permalink( $value );
	}

	return $value;
}