<?php
/**
 * Dynamic blocks.
 *
 * Every block is rendered on the server. The editor stores only a count and a
 * layout, never the content, so editing a project or a review updates every page
 * that shows it and a block never carries a stale copy of the data.
 *
 * @package MuhamedAhmed_Content
 */

defined( 'ABSPATH' ) || exit;

/**
 * Register the content blocks.
 *
 * @return void
 */
function mah_register_content_blocks() {
	$shared = array( 'api_version' => 3 );

	register_block_type(
		'mah-content/projects',
		array_merge(
			$shared,
			array(
				'title'           => __( 'Projects', 'prowpsite-panel' ),
				'description'     => __( 'Your published projects, in the order you set.', 'prowpsite-panel' ),
				'category'        => 'design',
				'icon'            => 'portfolio',
				'attributes'      => array(
					'count' => array(
						'type'    => 'number',
						'default' => 6,
					),
					'order' => array(
						'type'    => 'string',
						'default' => 'menu_order',
					),
				),
				'render_callback' => static function ( $atts ) {
					return mah_content_projects( $atts );
				},
			)
		)
	);

	register_block_type(
		'mah-content/reviews',
		array_merge(
			$shared,
			array(
				'title'           => __( 'Reviews', 'prowpsite-panel' ),
				'description'     => __( 'Your published client reviews, with ratings.', 'prowpsite-panel' ),
				'category'        => 'design',
				'icon'            => 'format-quote',
				'attributes'      => array(
					'count' => array(
						'type'    => 'number',
						'default' => 6,
					),
				),
				'render_callback' => static function ( $atts ) {
					return mah_content_reviews( $atts );
				},
			)
		)
	);

	register_block_type(
		'mah-content/services',
		array_merge(
			$shared,
			array(
				'title'           => __( 'Services', 'prowpsite-panel' ),
				'description'     => __( 'Your published services, numbered automatically.', 'prowpsite-panel' ),
				'category'        => 'design',
				'icon'            => 'list-view',
				'attributes'      => array(
					'count' => array(
						'type'    => 'number',
						'default' => 12,
					),
				),
				'render_callback' => static function ( $atts ) {
					return mah_content_services( $atts );
				},
			)
		)
	);

	register_block_type(
		'mah-content/process',
		array_merge(
			$shared,
			array(
				'title'           => __( 'Process steps', 'prowpsite-panel' ),
				'description'     => __( 'The steps listed in Site Details.', 'prowpsite-panel' ),
				'category'        => 'design',
				'icon'            => 'editor-ol',
				'attributes'      => array(),
				'render_callback' => static function () {
					return mah_content_process();
				},
			)
		)
	);

	register_block_type(
		'mah-content/stats',
		array_merge(
			$shared,
			array(
				'title'           => __( 'Statistics', 'prowpsite-panel' ),
				'description'     => __( 'The figures listed in Site Details.', 'prowpsite-panel' ),
				'category'        => 'design',
				'icon'            => 'chart-bar',
				'attributes'      => array(),
				'render_callback' => static function () {
					return mah_content_stats_grid();
				},
			)
		)
	);

	register_block_type(
		'mah-content/contact-details',
		array_merge(
			$shared,
			array(
				'title'           => __( 'Contact details', 'prowpsite-panel' ),
				'description'     => __( 'Your email, phone, WhatsApp and location, as saved in Site Details.', 'prowpsite-panel' ),
				'category'        => 'design',
				'icon'            => 'email',
				'attributes'      => array(
					'style' => array(
						'type'    => 'string',
						'default' => 'list',
					),
					'class' => array(
						'type'    => 'string',
						'default' => 'mah-contact-details',
					),
				),
				'render_callback' => static function ( $atts ) {
					return mah_content_contact_details( $atts );
				},
			)
		)
	);

	register_block_type(
		'mah-content/cta',
		array_merge(
			$shared,
			array(
				'title'           => __( 'Call to action', 'prowpsite-panel' ),
				'description'     => __( 'The main button, linked to whichever contact method you choose.', 'prowpsite-panel' ),
				'category'        => 'design',
				'icon'            => 'button',
				'attributes'      => array(),
				'render_callback' => static function () {
					$uri      = mah_content_primary_uri();
					$label    = mah_content_identity( 'cta_label' );
					$headline = trim( (string) get_option( 'mah_footer_headline', '' ) );

					if ( ! $uri && ! $label && '' === $headline ) {
						return '';
					}

					$html = sprintf(
						'<h2 id="mah-contact-title">%s</h2>',
						esc_html( mah_content_cta_heading() )
					);

					if ( $uri && $label ) {
						$html .= sprintf(
							'<a class="mah-btn mah-btn--accent" href="%s">%s</a>',
							esc_url( $uri ),
							esc_html( $label )
						);
					}

					return $html;
				},
			)
		)
	);

	register_block_type(
		'mah-content/availability',
		array_merge(
			$shared,
			array(
				'title'           => __( 'Availability', 'prowpsite-panel' ),
				'description'     => __( 'The status pill, shown only when you mark yourself as available.', 'prowpsite-panel' ),
				'category'        => 'design',
				'icon'            => 'yes-alt',
				'attributes'      => array(),
				'render_callback' => static function () {
					return mah_content_availability();
				},
			)
		)
	);
}
add_action( 'init', 'mah_register_content_blocks' );

/**
 * Group the blocks under their own category.
 *
 * This replaces the old editor script hook, which registered a script with no
 * source and did nothing useful. The blocks are server rendered, so there is
 * no editor JavaScript to load.
 *
 * @param array $categories Existing categories.
 * @return array
 */
function mah_content_block_category( $categories ) {
	array_unshift(
		$categories,
		array(
			'slug'  => 'design',
			'title' => __( 'Design', 'prowpsite-panel' ),
			'icon'  => null,
		)
	);

	return $categories;
}
add_filter( 'block_categories_all', 'mah_content_block_category' );