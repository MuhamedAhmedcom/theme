<?php
/**
 * All output.
 *
 * Every template in this file reads its content from the plugin's storage. No
 * name, address, number or label is written here, so changing any of them in
 * the admin updates every place it appears without touching this file.
 *
 * @package MuhamedAhmed_Content
 */

defined( 'ABSPATH' ) || exit;

/**
 * The site logo, when one has been chosen.
 *
 * @param string $size  Image size.
 * @param string $class Class attribute for the image.
 * @return string
 */
function mah_content_logo( $size = 'full', $class = '' ) {
	$id = (int) get_option( 'mah_logo_id', 0 );

	if ( function_exists( 'muhamedahmed_object_id' ) ) {
		$id = muhamedahmed_object_id( $id, 'attachment', true );
	}

	if ( ! $id || ! wp_attachment_is_image( $id ) ) {
		return '';
	}

	return wp_get_attachment_image(
		$id,
		$size,
		false,
		array(
			'class'   => $class,
			'alt'     => mah_identity_name(),
			'loading' => 'eager',
			'decoding' => 'async',
		)
	);
}

/**
 * Render the header.
 *
 * @return void
 */
function mah_content_header() {
	$name   = mah_identity_name();
	$tag    = mah_identity_tagline();
	$links  = function_exists( 'muhamedahmed_chrome_nav_items' )
		? muhamedahmed_chrome_nav_items()
		: mah_content_section_links();
	$cta    = mah_content_identity( 'cta_label' );
	$uri    = mah_content_primary_uri();
	$logo   = mah_content_logo( 'full', 'mah-header__logo mah-header__logo--knockout' );
	$toggle = function_exists( 'muhamedahmed_theme_toggle_markup' )
		? muhamedahmed_theme_toggle_markup()
		: '';
	unset( $tag );
	?>
	<header class="mah-header" data-mah-header>
		<div class="mah-progress" hidden aria-hidden="true"><span></span></div>
		<div class="mah-header__bar">
			<a class="mah-header__brand" href="<?php echo esc_url( function_exists( 'muhamedahmed_permalink' ) ? muhamedahmed_permalink( home_url( '/' ) ) : home_url( '/' ) ); ?>" aria-label="<?php echo esc_attr( $name ); ?> — <?php esc_attr_e( 'home', 'prowpsite-panel' ); ?>">
				<?php if ( $logo ) : ?>
					<?php echo wp_kses_post( $logo ); ?>
				<?php else : ?>
					<span class="mah-header__wordmark"><?php echo esc_html( $name ); ?></span>
				<?php endif; ?>
			</a>

			<?php if ( $links ) : ?>
				<nav class="mah-header__nav" aria-label="<?php esc_attr_e( 'Primary', 'prowpsite-panel' ); ?>">
					<ul class="mah-header__list">
						<?php foreach ( $links as $link ) : ?>
							<li>
								<a class="mah-header__link" href="<?php echo esc_url( $link['href'] ); ?>" data-mah-nav-target="<?php echo esc_attr( ltrim( $link['href'], '#' ) ); ?>">
									<?php echo esc_html( $link['label'] ); ?>
								</a>
							</li>
						<?php endforeach; ?>
					</ul>
				</nav>
			<?php endif; ?>

			<div class="mah-header__end">
			<?php
			if ( function_exists( 'muhamedahmed_language_switcher_markup' ) ) {
				echo muhamedahmed_language_switcher_markup( 'header' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- helper escapes.
			}
			echo $toggle; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built with esc_html/esc_attr.
			?>

			<?php if ( $cta && $uri ) : ?>
				<a class="mah-btn mah-btn--accent mah-header__cta" href="<?php echo esc_url( $uri ); ?>">
					<?php echo esc_html( $cta ); ?>
				</a>
			<?php endif; ?>

			<button
				class="mah-header__toggle"
				type="button"
				aria-expanded="false"
				aria-controls="mah-mobile-nav"
				aria-label="<?php esc_attr_e( 'Open menu', 'prowpsite-panel' ); ?>"
				data-mah-nav-toggle
				data-mah-label-open="<?php esc_attr_e( 'Open menu', 'prowpsite-panel' ); ?>"
				data-mah-label-close="<?php esc_attr_e( 'Close menu', 'prowpsite-panel' ); ?>"
			>
				<span class="screen-reader-text"><?php esc_html_e( 'Open menu', 'prowpsite-panel' ); ?></span>
				<span class="mah-header__toggle-bars" aria-hidden="true">
					<span class="mah-header__toggle-bar"></span>
					<span class="mah-header__toggle-bar"></span>
					<span class="mah-header__toggle-bar"></span>
				</span>
			</button>
			</div>
		</div>

		<div class="mah-header__mobile" id="mah-mobile-nav" hidden data-mah-nav>
			<ul class="mah-header__mobile-list">
				<?php foreach ( $links as $link ) : ?>
					<li><a href="<?php echo esc_url( $link['href'] ); ?>" data-mah-nav-target="<?php echo esc_attr( ltrim( $link['href'], '#' ) ); ?>"><?php echo esc_html( $link['label'] ); ?></a></li>
				<?php endforeach; ?>
			</ul>
			<?php
			if ( function_exists( 'muhamedahmed_language_switcher_markup' ) ) {
				echo muhamedahmed_language_switcher_markup( 'header' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- helper escapes.
			}
			echo $toggle; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built with esc_html/esc_attr.
			?>
			<?php if ( $cta && $uri ) : ?>
				<a class="mah-btn mah-btn--accent" href="<?php echo esc_url( $uri ); ?>">
					<?php echo esc_html( $cta ); ?>
				</a>
			<?php endif; ?>
		</div>
	</header>
	<?php
}

/**
 * Visible contact heading. Empty or CTA-paraphrase values use the UI label.
 *
 * @return string
 */
function mah_content_cta_heading() {
	$stored = (string) get_option( 'mah_footer_headline', '' );
	$cta    = mah_content_identity( 'cta_label' );

	if ( function_exists( 'muhamedahmed_cta_heading' ) ) {
		return muhamedahmed_cta_heading( $stored, $cta );
	}

	$headline = trim( $stored );

	if ( function_exists( 'muhamedahmed_t' ) && '' !== $headline ) {
		$headline = muhamedahmed_t( $headline, 'mah_footer_headline' );
	}

	return '' === $headline ? __( 'Contact', 'prowpsite-panel' ) : $headline;
}

/**
 * Five SVG stars with an accessible name.
 *
 * @param mixed $raw Stored rating.
 * @return string
 */
function mah_content_stars_markup( $raw ) {
	if ( function_exists( 'muhamedahmed_stars_markup' ) ) {
		return muhamedahmed_stars_markup( $raw );
	}

	if ( '' === $raw || null === $raw || false === $raw || ! is_numeric( $raw ) ) {
		return '';
	}

	$rating = (int) $raw;
	if ( $rating < 1 || $rating > 5 ) {
		return '';
	}

	$label = sprintf(
		/* translators: %d: star rating out of five. */
		_n( 'Rated %d out of 5', 'Rated %d out of 5', $rating, 'prowpsite-panel' ),
		$rating
	);
	$path = 'M12 2.1l2.85 5.78 6.38.93-4.62 4.5 1.09 6.36L12 16.66 6.3 19.67l1.09-6.36-4.62-4.5 6.38-.93L12 2.1z';
	$html = sprintf( '<p class="mah-stars" role="img" aria-label="%s">', esc_attr( $label ) );

	for ( $index = 1; $index <= 5; $index++ ) {
		$on    = $index <= $rating;
		$class = $on ? 'mah-star mah-star--on' : 'mah-star mah-star--off';
		$html .= sprintf(
			'<svg class="%s" viewBox="0 0 24 24" width="18" height="18" aria-hidden="true" focusable="false"><path d="%s"/></svg>',
			esc_attr( $class ),
			$path
		);
	}

	$html .= '</p>';

	return $html;
}

/**
 * Whether a stored highlight flag is true.
 *
 * @param mixed $raw Stored _mah_highlight value.
 * @return bool
 */
function mah_content_is_highlight( $raw ) {
	return true === $raw || 1 === $raw || '1' === $raw || 'true' === $raw;
}

/**
 * Render the footer.
 *
 * @return void
 */
function mah_content_footer() {
	$name     = mah_identity_name();
	$bio      = mah_content_identity( 'bio' );
	$email    = mah_content_identity( 'email' );
	$phone    = mah_content_identity( 'phone' );
	$wa       = mah_content_identity( 'whatsapp' );
	$location = mah_content_identity( 'location' );
	$response = mah_content_identity( 'response_time' );
	$links    = mah_content_section_links();
	$headline = trim( (string) get_option( 'mah_footer_headline', '' ) );
	if ( function_exists( 'muhamedahmed_t' ) && '' !== $headline ) {
		$headline = muhamedahmed_t( $headline, 'mah_footer_headline' );
	}
	$services = get_posts(
		array(
			'post_type'        => 'mah_service',
			'posts_per_page'   => 6,
			'orderby'          => 'menu_order',
			'order'            => 'ASC',
			'post_status'      => 'publish',
			'suppress_filters' => false,
			'no_found_rows'    => true,
		)
	);

	$wa_digits     = preg_replace( '/[^0-9]/', '', $wa );
	$uri           = mah_content_primary_uri();
	$has_contact   = ( $email || $phone || $wa_digits || $location || $response );
	?>
	<footer class="mah-footer" data-mah-reveal>
		<?php if ( $headline && $uri && ! ( is_front_page() && function_exists( 'muhamedahmed_render_home' ) ) ) : ?>
			<div class="mah-footer__top">
				<a class="mah-footer__huge" href="<?php echo esc_url( $uri ); ?>">
					<?php echo esc_html( $headline ); ?>
				</a>
			</div>
		<?php endif; ?>

		<div class="mah-footer__grid">
			<div class="mah-footer__col mah-footer__col--brand">
				<?php $logo = mah_content_logo( 'full', 'mah-footer__logo mah-footer__logo--knockout' ); ?>
				<?php if ( $logo ) : ?>
					<?php echo wp_kses_post( $logo ); ?>
				<?php endif; ?>
				<p class="mah-footer__brand"><?php echo esc_html( $name ); ?></p>
				<?php if ( $bio ) : ?>
					<p class="mah-footer__desc"><?php echo esc_html( $bio ); ?></p>
				<?php endif; ?>
			</div>

			<?php if ( $services ) : ?>
				<div class="mah-footer__col">
					<h2 class="mah-footer__title"><?php esc_html_e( 'Services', 'prowpsite-panel' ); ?></h2>
					<ul class="mah-footer__list">
						<?php
						foreach ( $services as $service ) {
							printf(
								'<li><a href="%s">%s</a></li>',
								esc_url( '#' . $service->post_name ),
								esc_html( get_the_title( $service ) )
							);
						}
						?>
					</ul>
				</div>
			<?php endif; ?>

			<?php if ( $links ) : ?>
				<div class="mah-footer__col">
					<h2 class="mah-footer__title"><?php esc_html_e( 'Explore', 'prowpsite-panel' ); ?></h2>
					<ul class="mah-footer__list">
						<?php foreach ( $links as $link ) : ?>
							<li><a href="<?php echo esc_url( $link['href'] ); ?>"><?php echo esc_html( $link['label'] ); ?></a></li>
						<?php endforeach; ?>
					</ul>
				</div>
			<?php endif; ?>

			<?php if ( $has_contact ) : ?>
			<div class="mah-footer__col">
				<h2 class="mah-footer__title"><?php esc_html_e( 'Contact', 'prowpsite-panel' ); ?></h2>
				<ul class="mah-footer__list">
					<?php if ( $email ) : ?>
						<li><a href="<?php echo esc_url( 'mailto:' . $email ); ?>"><?php echo esc_html( $email ); ?></a></li>
					<?php endif; ?>
					<?php if ( $phone ) : ?>
						<li>
							<a href="<?php echo esc_url( 'tel:' . preg_replace( '/[^0-9+]/', '', $phone ) ); ?>">
								<?php echo esc_html( $phone ); ?>
							</a>
						</li>
					<?php endif; ?>
					<?php if ( $wa_digits ) : ?>
						<li>
							<a href="<?php echo esc_url( 'https://wa.me/' . $wa_digits ); ?>">
								<?php esc_html_e( 'WhatsApp', 'prowpsite-panel' ); ?>
							</a>
						</li>
					<?php endif; ?>
					<?php if ( $location ) : ?>
						<li><span><?php echo esc_html( $location ); ?></span></li>
					<?php endif; ?>
					<?php if ( $response ) : ?>
						<li><span><?php echo esc_html( $response ); ?></span></li>
					<?php endif; ?>
				</ul>
			</div>
			<?php endif; ?>
		</div>

		<?php
		if ( function_exists( 'muhamedahmed_language_switcher_markup' ) ) {
			echo muhamedahmed_language_switcher_markup( 'footer' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- helper escapes.
		}
		?>

		<div class="mah-footer__bottom">
			<p>
				<?php
				printf(
					/* translators: 1: year, 2: name. */
					esc_html__( '© %1$s %2$s. All rights reserved.', 'prowpsite-panel' ),
					esc_html( gmdate( 'Y' ) ),
					esc_html( $name )
				);
				?>
			</p>
			<p class="mah-footer__built">
				<?php
				printf(
					/* translators: %s: site name. */
					esc_html__( 'Built on WordPress', 'prowpsite-panel' ),
					esc_html( get_bloginfo( 'name', 'display' ) )
				);
				?>
			</p>
		</div>
	</footer>
	<?php
}

/**
 * Render the projects grid from the post type.
 *
 * @param array $atts Shortcode or block attributes.
 * @return string
 */
function mah_content_projects( $atts = array() ) {
	$atts = shortcode_atts(
		array(
			'count' => 6,
			'order' => 'menu_order',
		),
		$atts,
		'mah_projects'
	);

	$projects = function_exists( 'muhamedahmed_projects_query_args' )
		? get_posts(
			muhamedahmed_projects_query_args(
				array(
					'posts_per_page' => (int) $atts['count'],
					'no_found_rows'  => true,
				)
			)
		)
		: get_posts(
			array(
				'post_type'      => 'mah_project',
				'posts_per_page' => (int) $atts['count'],
				'orderby'        => 'menu_order' === $atts['order'] ? 'menu_order' : 'date',
				'order'          => 'menu_order' === $atts['order'] ? 'ASC' : 'DESC',
				'post_status'    => 'publish',
				'no_found_rows'  => true,
			)
		);

	if ( ! $projects ) {
		return '';
	}

	$html = '<div class="mah-work">';

	foreach ( $projects as $project ) {
		$id    = $project->ID;
		$title = get_the_title( $project );
		$url   = mah_project_meta( $id, 'url' );
		$tags  = mah_project_meta( $id, 'tags_line' );

		$html .= '<div class="mah-work__item">';
		$html .= '<div class="mah-work__media">';

		if ( has_post_thumbnail( $id ) ) {
			$html .= get_the_post_thumbnail(
				$id,
				'large',
				array(
					'class'    => 'mah-work__img',
					'loading'  => 'lazy',
					'decoding' => 'async',
					'alt'      => $title,
				)
			);
		}

		$html .= '</div>';
		$html .= '<div class="mah-work__body">';

		if ( $url ) {
			$html .= sprintf(
				'<h3 class="mah-work__title"><a href="%s">%s</a></h3>',
				esc_url( $url ),
				esc_html( $title )
			);
		} else {
			$html .= sprintf( '<h3 class="mah-work__title">%s</h3>', esc_html( $title ) );
		}

		$excerpt = get_the_excerpt( $project );

		if ( $excerpt ) {
			$html .= sprintf( '<p class="mah-work__meta">%s</p>', esc_html( $excerpt ) );
		}

		if ( $tags ) {
			$html .= sprintf( '<p class="mah-work__tag">%s</p>', esc_html( $tags ) );
		}

		$html .= '</div>';
		$html .= '</div>';
	}

	$html .= '</div>';

	return $html;
}

/**
 * Grid span class so review rows stay complete for counts 3–9.
 *
 * 3-col: remainder 0 → all span 1; remainder 2 → first spans 2;
 * remainder 1 → first and last span 2.
 *
 * @param int $index Zero-based card index.
 * @param int $count Visible card count.
 * @return string
 */
function mah_content_review_span_class( $index, $count ) {
	$index = (int) $index;
	$count = (int) $count;

	if ( $count < 3 ) {
		return '';
	}

	$mod = $count % 3;

	if ( 0 === $mod ) {
		return '';
	}

	if ( 2 === $mod && 0 === $index ) {
		return 'mah-rev__card--span-2';
	}

	if ( 1 === $mod && ( 0 === $index || ( $count - 1 ) === $index ) ) {
		return 'mah-rev__card--span-2';
	}

	return '';
}

/**
 * Render the reviews grid from the post type.
 *
 * @param array $atts Shortcode or block attributes.
 * @return string
 */
function mah_content_reviews( $atts = array() ) {
	$atts = shortcode_atts(
		array(
			'count'     => 6,
			'order'     => 'priority',
			'home_only' => false,
		),
		$atts,
		'mah_reviews'
	);

	if ( function_exists( 'muhamedahmed_reviews_markup' ) ) {
		return muhamedahmed_reviews_markup( $atts );
	}

	return '';
}

/**
 * Render the services grid from the post type.
 *
 * @param array $atts Shortcode or block attributes.
 * @return string
 */
function mah_content_services( $atts = array() ) {
	$atts = shortcode_atts( array( 'count' => 12 ), $atts, 'mah_services' );

	$services = get_posts(
		array(
			'post_type'      => 'mah_service',
			'posts_per_page' => (int) $atts['count'],
			'orderby'        => 'menu_order',
			'order'          => 'ASC',
			'post_status'    => 'publish',
			'no_found_rows'  => true,
		)
	);

	if ( ! $services ) {
		return '';
	}

	$html  = '<ol class="mah-svc-grid">';
	$index = 0;

	foreach ( $services as $service ) {
		$title = get_the_title( $service );

		if ( '' === trim( $title ) ) {
			continue;
		}

		$index++;
		$body = trim( (string) get_the_excerpt( $service ) );

		if ( '' === $body ) {
			$body = wp_trim_words( wp_strip_all_tags( $service->post_content ), 28, '' );
		}

		$highlight = rest_sanitize_boolean( get_post_meta( $service->ID, '_mah_highlight', true ) );
		$item_class = 'mah-svc__item service';

		if ( $highlight ) {
			$item_class .= ' mah-svc__item--highlight';
		}

		$html .= sprintf(
			'<li class="%s" id="%s">',
			esc_attr( $item_class ),
			esc_attr( $service->post_name )
		);
		$html .= sprintf( '<span class="mah-num">%s</span>', esc_html( str_pad( (string) $index, 2, '0', STR_PAD_LEFT ) ) );
		$html .= sprintf( '<h3 class="mah-svc__title">%s</h3>', esc_html( $title ) );

		if ( '' !== $body ) {
			$html .= sprintf( '<p>%s</p>', esc_html( $body ) );
		}

		$html .= '</li>';
	}

	$html .= '</ol>';

	if ( 0 === $index ) {
		return '';
	}

	return $html;
}

/**
 * Render the contact details as a list.
 *
 * @param array $atts Shortcode attributes.
 * @return string
 */
function mah_content_contact_details( $atts = array() ) {
	$atts = shortcode_atts(
		array(
			'class' => 'mah-contact-details',
			'style' => 'list',
		),
		$atts,
		'mah_contact_details'
	);

	$email    = mah_content_identity( 'email' );
	$phone    = mah_content_identity( 'phone' );
	$wa       = preg_replace( '/[^0-9]/', '', mah_content_identity( 'whatsapp' ) );
	$location = mah_content_identity( 'location' );
	$response = mah_content_identity( 'response_time' );

	$items = array();

	if ( $email ) {
		$items[] = sprintf(
			'<li><a href="%s">%s</a></li>',
			esc_url( 'mailto:' . $email ),
			esc_html( $email )
		);
	}

	if ( $phone ) {
		$items[] = sprintf(
			'<li><a href="%s">%s</a></li>',
			esc_url( 'tel:' . preg_replace( '/[^0-9+]/', '', $phone ) ),
			esc_html( $phone )
		);
	}

	if ( $wa ) {
		$items[] = sprintf(
			'<li><a href="%s">%s</a></li>',
			esc_url( 'https://wa.me/' . $wa ),
			esc_html__( 'WhatsApp', 'prowpsite-panel' )
		);
	}

	if ( $location ) {
		$items[] = sprintf( '<li><span>%s</span></li>', esc_html( $location ) );
	}

	if ( $response ) {
		$items[] = sprintf( '<li><span>%s</span></li>', esc_html( $response ) );
	}

	if ( ! $items ) {
		return '';
	}

	$tag = ( 'list' === $atts['style'] ) ? 'ul' : 'div';

	return sprintf(
		'<%1$s class="%2$s">%3$s</%1$s>',
		esc_html( $tag ),
		esc_attr( $atts['class'] ),
		implode( '', $items )
	);
}

/**
 * Register the shortcodes.
 *
 * Shortcodes are kept alongside the blocks because they are the standard way to
 * place plugin content anywhere, including inside widgets and the classic
 * editor.
 *
 * @return void
 */
add_action(
	'init',
	static function () {
		add_shortcode( 'mah_projects', static function ( $atts ) {
			return mah_content_projects( (array) $atts );
		} );

		add_shortcode( 'mah_reviews', static function ( $atts ) {
			return mah_content_reviews( (array) $atts );
		} );

		add_shortcode( 'mah_services', static function ( $atts ) {
			return mah_content_services( (array) $atts );
		} );

		add_shortcode( 'mah_contact_details', static function ( $atts ) {
			return mah_content_contact_details( (array) $atts );
		} );

		add_shortcode( 'mah_cta', static function ( $atts ) {
			$uri = mah_content_primary_uri();

			if ( ! $uri ) {
				return '';
			}

			$label = mah_content_identity( 'cta_label' );

			if ( ! $label ) {
				return '';
			}

			return sprintf(
				'<a class="mah-btn mah-btn--accent" href="%s">%s</a>',
				esc_url( $uri ),
				esc_html( $label )
			);
		} );
	}
);