<?php
/**
 * Identity: the name, description and contact details that appear site-wide.
 *
 * WordPress already stores a site title and tagline, so those are read from
 * core settings rather than duplicated here. Only the fields core has no home
 * for are kept in this plugin.
 *
 * @package MuhamedAhmed_Content
 */

defined( 'ABSPATH' ) || exit;

/**
 * The name to display.
 *
 * Prefers the plugin value so the header, footer and structured data all agree,
 * and falls back to the WordPress site title, which is the standard fallback.
 *
 * @return string
 */
function mah_identity_name() {
	$name = mah_content_identity( 'full_name' );

	return $name ? $name : get_bloginfo( 'name', 'display' );
}

/**
 * The tagline to display.
 *
 * @return string
 */
function mah_identity_tagline() {
	$tagline = mah_content_identity( 'tagline' );

	return $tagline ? $tagline : get_bloginfo( 'description', 'display' );
}

/**
 * Build the document title.
 *
 * Extends the WordPress pattern rather than replacing it, so page titles keep
 * working on every other page.
 *
 * @param array $parts Title parts.
 * @return array
 */
add_filter(
	'document_title_parts',
	static function ( $parts ) {
		if ( is_front_page() ) {
			$name = mah_identity_name();
			$tag  = mah_identity_tagline();

			$parts['title']   = $tag ? $name . ' — ' . $tag : $name;
			$parts['site']    = '';
			$parts['tagline'] = '';
		}

		return $parts;
	}
);

/**
 * Feed the identity into core's social and schema output.
 *
 * @return void
 */
add_action(
	'wp_head',
	static function () {
		$bio = mah_content_identity( 'bio' );

		if ( $bio ) {
			printf( '<meta name="author" content="%s">' . "\n", esc_attr( $bio ) );
		}

		$phone = mah_content_identity( 'phone' );

		if ( $phone ) {
			printf(
				'<meta name="telephone" content="%s">' . "\n",
				esc_attr( $phone )
			);
		}
	},
	4
);