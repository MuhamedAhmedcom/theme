<?php
/**
 * Reviews as a custom post type.
 *
 * A review has a body, a rating and an attribution. Storing them as posts means
 * a new testimonial can be added from the admin at any time, with no build step
 * and no risk of it disappearing when the page is rebuilt.
 *
 * @package MuhamedAhmed_Content
 */

defined( 'ABSPATH' ) || exit;

/**
 * Register the review post type.
 *
 * @return void
 */
function mah_register_review() {
	register_post_type(
		'mah_review',
		array(
			'labels'        => array(
				'name'          => __( 'Reviews', 'prowpsite-panel' ),
				'singular_name' => __( 'Review', 'prowpsite-panel' ),
				'add_new'       => __( 'Add review', 'prowpsite-panel' ),
				'add_new_item'  => __( 'Add new review', 'prowpsite-panel' ),
				'edit_item'     => __( 'Edit review', 'prowpsite-panel' ),
				'view_item'     => __( 'View review', 'prowpsite-panel' ),
				'menu_name'     => __( 'Reviews', 'prowpsite-panel' ),
			),
			'public'        => false,
			'show_ui'       => true,
			'show_in_rest'  => true,
			'hierarchical'  => false,
			'menu_icon'     => 'dashicons-format-quote',
			'menu_position' => 27,
			'supports'      => array( 'title', 'editor', 'page-attributes', 'revisions' ),
			'show_in_menu'  => true,
		)
	);
}
add_action( 'init', 'mah_register_review' );

/**
 * Register review meta.
 *
 * @return void
 */
function mah_register_review_meta() {
	if ( function_exists( 'mah_register_review_front_meta' ) ) {
		return;
	}

	register_post_meta(
		'mah_review',
		'_mah_author',
		array(
			'type'              => 'string',
			'single'            => true,
			'show_in_rest'      => true,
			'sanitize_callback' => 'sanitize_text_field',
			'default'           => '',
		)
	);

	register_post_meta(
		'mah_review',
		'_mah_role',
		array(
			'type'              => 'string',
			'single'            => true,
			'show_in_rest'      => true,
			'sanitize_callback' => 'sanitize_text_field',
			'default'           => '',
		)
	);

	register_post_meta(
		'mah_review',
		'_mah_rating',
		array(
			'type'              => 'integer',
			'single'            => true,
			'show_in_rest'      => true,
			'sanitize_callback' => 'absint',
			'default'           => 0,
		)
	);

	register_post_meta(
		'mah_review',
		'_mah_highlight',
		array(
			'type'              => 'boolean',
			'single'            => true,
			'show_in_rest'      => true,
			'sanitize_callback' => 'rest_sanitize_boolean',
			'default'           => false,
		)
	);

	register_post_meta(
		'mah_review',
		'_mah_source',
		array(
			'type'              => 'string',
			'single'            => true,
			'show_in_rest'      => true,
			'sanitize_callback' => 'sanitize_text_field',
			'default'           => '',
		)
	);
}
add_action( 'init', 'mah_register_review_meta' );

/**
 * Read one review field with a fallback.
 *
 * @param int    $post_id Review id.
 * @param string $key     Meta key without the prefix.
 * @param mixed  $default Fallback.
 * @return mixed
 */
function mah_review_meta( $post_id, $key, $default = '' ) {
	$value = get_post_meta( $post_id, '_mah_' . $key, true );

	if ( '' === $value || null === $value ) {
		return $default;
	}

	if ( 'project' === $key && function_exists( 'muhamedahmed_object_id' ) ) {
		return muhamedahmed_object_id( $value, 'mah_project', true );
	}

	return $value;
}