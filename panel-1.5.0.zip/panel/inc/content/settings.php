<?php
/**
 * The admin screen that edits identity details and navigation links.
 *
 * The form is generated from the field schema, so the screen and the renderer
 * can never disagree about which fields exist.
 *
 * @package MuhamedAhmed_Content
 */

defined( 'ABSPATH' ) || exit;

/**
 * Register the menu.
 *
 * @return void
 */
function mah_content_admin_menu() {
	add_menu_page(
		__( 'Site Details', 'prowpsite-panel' ),
		__( 'Site Details', 'prowpsite-panel' ),
		'manage_options',
		'mah-content',
		'mah_content_render_page',
		'dashicons-id',
		58
	);
}
add_action( 'admin_menu', 'mah_content_admin_menu' );

/**
 * Handle the save.
 *
 * @return void
 */
function mah_content_handle_save() {
	if ( ! isset( $_POST['mah_content_nonce'] ) ) {
		return;
	}

	if ( ! wp_verify_nonce( sanitize_key( wp_unslash( $_POST['mah_content_nonce'] ) ), 'mah_content_save' ) ) {
		return;
	}

	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}

	$raw = isset( $_POST['mah'] ) ? wp_unslash( $_POST['mah'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized

	// Sanitised against the declared type for each field.
	update_option( 'mah_identity', mah_content_sanitize_set( $raw, mah_content_identity_fields() ) );

	if ( isset( $_POST['mah_links'] ) ) {
		mah_content_save_section_links( wp_unslash( $_POST['mah_links'] ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
	} else {
		update_option( 'mah_section_links', array() );
	}

	if ( isset( $_POST['mah_logo_id'] ) ) {
		update_option( 'mah_logo_id', absint( $_POST['mah_logo_id'] ) );
	}

	if ( isset( $_POST['mah_process'] ) ) {
		update_option( 'mah_process', mah_content_clean_rows( wp_unslash( $_POST['mah_process'] ) ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
	}

	if ( isset( $_POST['mah_stats'] ) ) {
		update_option( 'mah_stats', mah_content_clean_rows( wp_unslash( $_POST['mah_stats'] ) ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
	}

	if ( isset( $_POST['mah_marquee'] ) ) {
		update_option(
			'mah_marquee_phrases',
			array_map( 'sanitize_text_field', array_filter( array_map( 'trim', (array) wp_unslash( $_POST['mah_marquee'] ) ) ) )
		);
	}

	// Clear the page cache so the change is visible immediately.
	if ( function_exists( 'wp_cache_flush' ) ) {
		wp_cache_flush();
	}

	add_settings_error(
		'mah_content',
		'mah_saved',
		__( 'Saved. Every page that shows these details is updated.', 'prowpsite-panel' ),
		'success'
	);
}
add_action( 'admin_init', 'mah_content_handle_save' );

/**
 * Render one field.
 *
 * @param string $key   Field key.
 * @param array  $field Field definition.
 * @param string $value Current value.
 * @return void
 */
function mah_content_render_field( $key, array $field, $value ) {
	$id = 'mah-' . $key;
	?>
	<tr>
		<th scope="row">
			<label for="<?php echo esc_attr( $id ); ?>"><?php echo esc_html( $field['label'] ); ?></label>
		</th>
		<td>
			<?php if ( 'textarea' === $field['type'] ) : ?>
				<textarea id="<?php echo esc_attr( $id ); ?>" name="mah[<?php echo esc_attr( $key ); ?>]"
					rows="3" class="large-text"><?php echo esc_textarea( $value ); ?></textarea>
			<?php elseif ( 'checkbox' === $field['type'] ) : ?>
				<label>
					<input type="checkbox" id="<?php echo esc_attr( $id ); ?>"
						name="mah[<?php echo esc_attr( $key ); ?>]" value="1" <?php checked( $value, '1' ); ?> />
					<?php echo esc_html( $field['label'] ); ?>
				</label>
			<?php elseif ( 'select' === $field['type'] ) : ?>
				<select id="<?php echo esc_attr( $id ); ?>" name="mah[<?php echo esc_attr( $key ); ?>]">
					<?php foreach ( $field['options'] as $val => $label ) : ?>
						<option value="<?php echo esc_attr( $val ); ?>" <?php selected( $value, $val ); ?>>
							<?php echo esc_html( $label ); ?>
						</option>
					<?php endforeach; ?>
				</select>
			<?php else : ?>
				<input type="<?php echo esc_attr( $field['type'] ); ?>" id="<?php echo esc_attr( $id ); ?>"
					name="mah[<?php echo esc_attr( $key ); ?>]" value="<?php echo esc_attr( $value ); ?>"
					class="regular-text" />
			<?php endif; ?>

			<?php if ( ! empty( $field['help'] ) ) : ?>
				<p class="description"><?php echo esc_html( $field['help'] ); ?></p>
			<?php endif; ?>
		</td>
	</tr>
	<?php
}

/**
 * Render the page.
 *
 * @return void
 */
function mah_content_render_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}

	$stored  = get_option( 'mah_identity', array() );
	$stored  = is_array( $stored ) ? $stored : array();
	$fields  = mah_content_identity_fields();
	$links   = mah_content_section_links();
	$logo_id = (int) get_option( 'mah_logo_id', 0 );
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'Site Details', 'prowpsite-panel' ); ?></h1>
		<p class="description">
			<?php esc_html_e( 'These values are stored once and rendered everywhere by the plugin. The header, the footer, the contact section, the page title and the contact buttons all read from here, so a change applies site-wide immediately. Nothing here is written into code.', 'prowpsite-panel' ); ?>
		</p>

		<?php settings_errors( 'mah_content' ); ?>

		<form method="post">
			<?php wp_nonce_field( 'mah_content_save', 'mah_content_nonce' ); ?>

			<h2><?php esc_html_e( 'Logo', 'prowpsite-panel' ); ?></h2>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><?php esc_html_e( 'Logo image', 'prowpsite-panel' ); ?></th>
					<td>
						<?php if ( $logo_id && wp_attachment_is_image( $logo_id ) ) : ?>
							<div style="display:flex;gap:16px;align-items:center;margin-bottom:10px">
								<?php echo wp_get_attachment_image( $logo_id, 'medium', false, array( 'style' => 'max-width:180px;height:auto;background:#151515;padding:8px;border-radius:8px' ) ); ?>
								<button type="button" class="button" id="mah-pick-logo">
									<?php esc_html_e( 'Change', 'prowpsite-panel' ); ?>
								</button>
							</div>
						<?php endif; ?>

						<input type="hidden" name="mah_logo_id" id="mah-logo-id" value="<?php echo esc_attr( $logo_id ); ?>" />
						<button type="button" class="button" id="mah-pick-logo">
							<?php echo $logo_id ? esc_html__( 'Change logo', 'prowpsite-panel' ) : esc_html__( 'Choose logo', 'prowpsite-panel' ); ?>
						</button>

						<p class="description">
							<?php esc_html_e( 'A PNG with transparency works best on the dark header. If no logo is chosen, the site name is shown instead.', 'prowpsite-panel' ); ?>
						</p>
					</td>
				</tr>
			</table>

			<h2><?php esc_html_e( 'You', 'prowpsite-panel' ); ?></h2>
			<table class="form-table" role="presentation">
				<tbody>
				<?php
				foreach ( array( 'full_name', 'role', 'tagline', 'bio' ) as $key ) :
					mah_content_render_field(
						$key,
						$fields[ $key ],
						isset( $stored[ $key ] ) ? $stored[ $key ] : ''
					);
				endforeach;
				?>
				</tbody>
			</table>

			<h2><?php esc_html_e( 'Contact', 'prowpsite-panel' ); ?></h2>
			<table class="form-table" role="presentation">
				<tbody>
				<?php
				foreach ( array( 'email', 'phone', 'whatsapp', 'location', 'response_time' ) as $key ) :
					mah_content_render_field(
						$key,
						$fields[ $key ],
						isset( $stored[ $key ] ) ? $stored[ $key ] : ''
					);
				endforeach;
				?>
				</tbody>
			</table>

			<h2><?php esc_html_e( 'Main button', 'prowpsite-panel' ); ?></h2>
			<table class="form-table" role="presentation">
				<tbody>
				<?php
				foreach ( array( 'cta_label', 'cta_action', 'cta_target', 'availability', 'available' ) as $key ) :
					mah_content_render_field(
						$key,
						$fields[ $key ],
						isset( $stored[ $key ] ) ? $stored[ $key ] : ''
					);
				endforeach;
				?>
				</tbody>
			</table>

			<h2><?php esc_html_e( 'Section links', 'prowpsite-panel' ); ?></h2>
			<p class="description">
				<?php esc_html_e( 'These appear in the header, the mobile menu and the footer. Reorder or remove them here.', 'prowpsite-panel' ); ?>
			</p>
			<table class="form-table" role="presentation">
				<tbody>
				<?php
				$rows = $links;
				// Always show a few empty rows so a new link can be added.
				for ( $i = count( $rows ); $i < count( $rows ) + 3; $i++ ) {
					$rows[] = array(
						'label' => '',
						'href'  => '',
					);
				}

				foreach ( $rows as $i => $row ) :
					?>
					<tr>
						<td style="width:35%">
							<input type="text" class="regular-text" placeholder="<?php esc_attr_e( 'Label', 'prowpsite-panel' ); ?>"
								name="mah_links[<?php echo (int) $i; ?>][label]"
								value="<?php echo esc_attr( $row['label'] ); ?>" />
						</td>
						<td>
							<input type="text" class="regular-text" placeholder="#work"
								name="mah_links[<?php echo (int) $i; ?>][href]"
								value="<?php echo esc_attr( $row['href'] ); ?>" />
						</td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>

			<h2><?php esc_html_e( 'Statistics', 'prowpsite-panel' ); ?></h2>
			<p class="description"><?php esc_html_e( 'Shown in the numbers band. The Process and Statistics blocks read these.', 'prowpsite-panel' ); ?></p>
			<table class="form-table" role="presentation">
				<tbody>
				<?php
				$stat_rows = mah_content_stats();

				for ( $i = count( $stat_rows ); $i < count( $stat_rows ) + 2; $i++ ) {
					$stat_rows[] = array(
						'value' => '',
						'label' => '',
					);
				}

				foreach ( $stat_rows as $i => $row ) :
					?>
					<tr>
						<td style="width:20%">
							<input type="text" class="regular-text" placeholder="<?php esc_attr_e( '120+', 'prowpsite-panel' ); ?>"
								name="mah_stats[<?php echo (int) $i; ?>][0]" value="<?php echo esc_attr( $row['value'] ); ?>" />
						</td>
						<td>
							<input type="text" class="regular-text" placeholder="<?php esc_attr_e( 'Projects delivered', 'prowpsite-panel' ); ?>"
								name="mah_stats[<?php echo (int) $i; ?>][1]" value="<?php echo esc_attr( $row['label'] ); ?>" />
						</td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>

			<h2><?php esc_html_e( 'Process steps', 'prowpsite-panel' ); ?></h2>
			<table class="form-table" role="presentation">
				<tbody>
				<?php
				$proc_rows = mah_content_process_steps();

				for ( $i = count( $proc_rows ); $i < count( $proc_rows ) + 2; $i++ ) {
					$proc_rows[] = array(
						'title' => '',
						'text'  => '',
					);
				}

				foreach ( $proc_rows as $i => $row ) :
					?>
					<tr>
						<td style="width:20%">
							<input type="text" class="regular-text" placeholder="<?php esc_attr_e( 'Discover', 'prowpsite-panel' ); ?>"
								name="mah_process[<?php echo (int) $i; ?>][0]" value="<?php echo esc_attr( $row['title'] ); ?>" />
						</td>
						<td>
							<input type="text" class="regular-text" placeholder="<?php esc_attr_e( 'A short call to find out the goal.', 'prowpsite-panel' ); ?>"
								name="mah_process[<?php echo (int) $i; ?>][1]" value="<?php echo esc_attr( $row['text'] ); ?>" />
						</td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>

			<h2><?php esc_html_e( 'Scrolling phrases', 'prowpsite-panel' ); ?></h2>
			<p class="description"><?php esc_html_e( 'One phrase per line. A bullet is placed between them automatically.', 'prowpsite-panel' ); ?></p>
			<?php
			$phrases = get_option( 'mah_marquee_phrases', array() );
			$phrases = is_array( $phrases ) ? $phrases : array();
			?>
			<textarea name="mah_marquee[]" rows="3" class="large-text" placeholder="<?php esc_attr_e( 'One phrase per line', 'prowpsite-panel' ); ?>"><?php
				foreach ( $phrases as $phrase ) {
					echo esc_textarea( $phrase . "\n" );
				}
			?></textarea>

			<?php submit_button(); ?>
		</form>

		<h2><?php esc_html_e( 'Content you manage elsewhere', 'prowpsite-panel' ); ?></h2>
		<ul>
			<li><strong><?php esc_html_e( 'Projects', 'prowpsite-panel' ); ?></strong> <?php esc_html_e( 'Ã¢â‚¬â€ add or edit each one, then set its order under Page Attributes.', 'prowpsite-panel' ); ?></li>
			<li><strong><?php esc_html_e( 'Reviews', 'prowpsite-panel' ); ?></strong> <?php esc_html_e( 'Ã¢â‚¬â€ author, role and star rating are on each review.', 'prowpsite-panel' ); ?></li>
			<li><strong><?php esc_html_e( 'Services', 'prowpsite-panel' ); ?></strong> <?php esc_html_e( 'Ã¢â‚¬â€ the number shown is the order, so no numbering is typed by hand.', 'prowpsite-panel' ); ?></li>
		</ul>

		<p>
			<?php esc_html_e( 'On the page, place the Projects, Reviews, Services and Contact details blocks. They render whatever is published, so content never has to be edited in two places.', 'prowpsite-panel' ); ?>
		</p>
	</div>
	<?php
}

/**
 * Media picker for the logo field.
 *
 * Uses the standard media modal, so no custom uploader is needed.
 *
 * @return void
 */
function mah_content_media_script() {
	$screen = get_current_screen();

	if ( ! $screen || 'toplevel_page_mah-content' !== $screen->id ) {
		return;
	}

	wp_enqueue_media();

	wp_add_inline_script(
		'media-upload',
		'jQuery(function($){
			var frame;
			$(document).on("click", "#mah-pick-logo", function(e){
				e.preventDefault();
				if(frame){ frame.open(); return; }
				frame = wp.media({title: "' . esc_js__( 'Choose a logo', 'prowpsite-panel' ) . '", multiple:false, library:{type:"image"}});
				frame.on("select", function(){
					var a = frame.state().get("selection").first().toJSON();
					$("#mah-logo-id").val(a.id);
					$("#mah-pick-logo").first().trigger("click");
					window.location.reload();
				});
				frame.open();
			});
		});'
	);
}
add_action( 'admin_enqueue_scripts', 'mah_content_media_script' );