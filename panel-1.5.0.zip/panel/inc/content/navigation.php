<?php
/**
 * Navigation.
 *
 * WordPress already stores menus. The header and footer read them rather than
 * repeating a hard-coded link list, so a menu change applies everywhere at once.
 *
 * The section jump links on a one-page site are a different shape from a
 * WordPress menu, so they are stored as their own repeatable list.
 *
 * @package MuhamedAhmed_Content
 */

defined( 'ABSPATH' ) || exit;

/**
 * The section links used by the header and footer on one-page designs.
 *
 * Stored in one option so the header, the footer and the mobile panel all read
 * the same list. Editing it changes all three at once.
 *
 * @return array
 */
function mah_content_section_links() {
	$links = get_option( 'mah_section_links', array() );

	if ( ! is_array( $links ) || ! $links ) {
		return array();
	}

	$clean = array();

	foreach ( $links as $link ) {
		if ( ! is_array( $link ) ) {
			continue;
		}

		$label = isset( $link['label'] ) ? sanitize_text_field( $link['label'] ) : '';
		$href  = isset( $link['href'] ) ? sanitize_text_field( $link['href'] ) : '';

		if ( '' === $label ) {
			continue;
		}

		$idx = count( $clean );

		if ( function_exists( 'muhamedahmed_t' ) ) {
			$label = muhamedahmed_t( $label, 'mah_section_links.' . $idx . '.label' );
		}

		if ( function_exists( 'muhamedahmed_permalink' ) ) {
			$href = muhamedahmed_permalink( $href );
		}

		$clean[] = array(
			'label' => $label,
			'href'  => $href,
		);
	}

	return $clean;
}

/**
 * Save the section link list.
 *
 * @param array $raw Submitted rows.
 * @return void
 */
function mah_content_save_section_links( $raw ) {
	$clean = array();

	$raw = is_array( $raw ) ? $raw : array();

	for ( $i = 0; $i < count( $raw ); $i++ ) {
		$row = isset( $raw[ $i ] ) && is_array( $raw[ $i ] ) ? $raw[ $i ] : array();

		$label = isset( $row['label'] ) ? sanitize_text_field( $row['label'] ) : '';
		$href  = isset( $row['href'] ) ? sanitize_text_field( $row['href'] ) : '';

		if ( '' === $label ) {
			continue;
		}

		$clean[] = array(
			'label' => $label,
			'href'  => $href,
		);
	}

	update_option( 'mah_section_links', $clean );
}