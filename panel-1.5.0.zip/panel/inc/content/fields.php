<?php
/**
 * A repeatable field list: the schema and the read/write helpers.
 *
 * Every piece of content in this plugin is declared once, here, as a field
 * schema. The admin form, the sanitiser and the renderer are all generated from
 * that schema, so adding a field means adding one array entry and nothing else.
 *
 * @package MuhamedAhmed_Content
 */

defined( 'ABSPATH' ) || exit;

/**
 * The single source of truth for identity and contact details.
 *
 * These values appear in the header, the footer, the contact section and the
 * browser metadata. They are stored once and read everywhere.
 *
 * @return array
 */
function mah_content_identity_fields() {
	return array(
		'full_name'    => array(
			'label'   => __( 'Full name', 'prowpsite-panel' ),
			'type'    => 'text',
			'default' => '',
		),
		'role'         => array(
			'label'   => __( 'Role or title', 'prowpsite-panel' ),
			'type'    => 'text',
			'default' => '',
		),
		'tagline'      => array(
			'label'   => __( 'Short tagline', 'prowpsite-panel' ),
			'type'    => 'text',
			'default' => '',
		),
		'bio'          => array(
			'label'   => __( 'Short biography', 'prowpsite-panel' ),
			'type'    => 'textarea',
			'default' => '',
		),
		'email'        => array(
			'label'   => __( 'Email address', 'prowpsite-panel' ),
			'type'    => 'email',
			'default' => '',
		),
		'phone'        => array(
			'label'   => __( 'Phone number', 'prowpsite-panel' ),
			'type'    => 'text',
			'default' => '',
			'help'    => __( 'International format, for example +20 100 000 0000.', 'prowpsite-panel' ),
		),
		'whatsapp'     => array(
			'label'   => __( 'WhatsApp number', 'prowpsite-panel' ),
			'type'    => 'text',
			'default' => '',
			'help'    => __( 'Digits only, including the country code.', 'prowpsite-panel' ),
		),
		'location'     => array(
			'label'   => __( 'Location', 'prowpsite-panel' ),
			'type'    => 'text',
			'default' => '',
		),
		'response_time' => array(
			'label'   => __( 'Response time note', 'prowpsite-panel' ),
			'type'    => 'text',
			'default' => '',
		),
		'availability' => array(
			'label'   => __( 'Availability status', 'prowpsite-panel' ),
			'type'    => 'text',
			'default' => '',
		),
		'available'    => array(
			'label'   => __( 'Show as currently available', 'prowpsite-panel' ),
			'type'    => 'checkbox',
			'default' => '1',
		),
		'cta_label'    => array(
			'label'   => __( 'Main button label', 'prowpsite-panel' ),
			'type'    => 'text',
			'default' => '',
		),
		'cta_action'   => array(
			'label'   => __( 'Main button action', 'prowpsite-panel' ),
			'type'    => 'select',
			'options' => array(
				'mailto' => __( 'Open email app', 'prowpsite-panel' ),
				'tel'    => __( 'Call phone', 'prowpsite-panel' ),
				'wa'     => __( 'Open WhatsApp', 'prowpsite-panel' ),
				'link'   => __( 'Go to a page link', 'prowpsite-panel' ),
			),
			'default' => 'mailto',
		),
		'cta_target'   => array(
			'label'   => __( 'Button link', 'prowpsite-panel' ),
			'type'    => 'url',
			'default' => '',
			'help'    => __( 'Used when the action is a page link. Leave empty for mailto.', 'prowpsite-panel' ),
		),
	);
}

/**
 * Read one identity field, falling back to the schema default.
 *
 * @param string $key Field key.
 * @return string
 */
function mah_content_identity( $key ) {
	static $cache = null;

	if ( null === $cache ) {
		$cache = get_option( 'mah_identity', array() );
		if ( ! is_array( $cache ) ) {
			$cache = array();
		}
	}

	$fields = mah_content_identity_fields();

	if ( isset( $cache[ $key ] ) && '' !== $cache[ $key ] ) {
		$value = $cache[ $key ];
	} else {
		$value = isset( $fields[ $key ]['default'] ) ? (string) $fields[ $key ]['default'] : '';
	}

	if ( function_exists( 'muhamedahmed_i18n_identity_value' ) && is_scalar( $value ) ) {
		return muhamedahmed_i18n_identity_value( $key, (string) $value );
	}

	return is_scalar( $value ) ? (string) $value : '';
}

/**
 * Sanitise a field value against its declared type.
 *
 * @param mixed  $value Raw value.
 * @param string $type  Field type.
 * @return string
 */
function mah_content_sanitize( $value, $type ) {
	$value = is_scalar( $value ) ? trim( (string) $value ) : '';

	switch ( $type ) {
		case 'email':
			// Returns an empty string when the address is not valid.
			return sanitize_email( $value );
		case 'url':
			return esc_url_raw( $value );
		case 'textarea':
			return sanitize_textarea_field( $value );
		case 'checkbox':
			return $value ? '1' : '';
		case 'text':
		default:
			return sanitize_text_field( $value );
	}
}

/**
 * Sanitise a whole field set.
 *
 * @param array $raw    Raw values.
 * @param array $schema Field schema.
 * @return array
 */
function mah_content_sanitize_set( $raw, array $schema ) {
	$clean = array();

	foreach ( $schema as $key => $field ) {
		$value = isset( $raw[ $key ] ) ? $raw[ $key ] : '';

		if ( 'checkbox' === $field['type'] ) {
			$clean[ $key ] = ( ! empty( $value ) && '0' !== $value ) ? '1' : '';
			continue;
		}

		$clean[ $key ] = mah_content_sanitize( $value, $field['type'] );
	}

	return $clean;
}

/**
 * Build a contact URI from the stored details.
 *
 * The button action is chosen in the admin, so the same button becomes a phone
 * call or a WhatsApp chat by changing one setting. No code edit.
 *
 * @return string
 */
function mah_content_primary_uri() {
	$action = mah_content_identity( 'cta_action' );

	switch ( $action ) {
		case 'tel':
			$phone = preg_replace( '/[^0-9+]/', '', mah_content_identity( 'phone' ) );

			return $phone ? 'tel:' . $phone : '';

		case 'wa':
			$wa = preg_replace( '/[^0-9]/', '', mah_content_identity( 'whatsapp' ) );

			return $wa ? 'https://wa.me/' . $wa : '';

		case 'link':
			$target = mah_content_identity( 'cta_target' );

			return function_exists( 'muhamedahmed_permalink' ) ? muhamedahmed_permalink( $target ) : $target;

		case 'mailto':
		default:
			$email = mah_content_identity( 'email' );

			return $email ? 'mailto:' . $email : '';
	}
}