<?php
/**
 * Small repeatable lists: process steps, statistics and marquee phrases.
 *
 * These are short ordered lists rather than full posts, so they live in options
 * edited from the admin. They are defined once and rendered once, so the same
 * value is never repeated in a template.
 *
 * @package MuhamedAhmed_Content
 */

defined( 'ABSPATH' ) || exit;

/**
 * Read a stored list.
 *
 * @param string $option  Option name.
 * @param string $subkey  Sub-key of each row.
 * @param array  $default Default rows.
 * @return array
 */
function mah_content_list( $option, $subkey, array $default = array() ) {
	$rows = get_option( $option, array() );

	if ( ! is_array( $rows ) || ! $rows ) {
		$rows = $default;
	}

	$clean = array();

	foreach ( $rows as $row ) {
		// A plain string list, used by the marquee.
		if ( is_string( $row ) ) {
			$row = array( $subkey => $row );
		}

		if ( ! is_array( $row ) || empty( $row[ $subkey ] ) ) {
			continue;
		}

		$clean[] = sanitize_text_field( $row[ $subkey ] );
	}

	return $clean;
}

/**
 * Read the process steps.
 *
 * @return array Rows of title and description.
 */
function mah_content_process_steps() {
	$rows = get_option( 'mah_process', array() );

	if ( ! is_array( $rows ) || ! $rows ) {
		return array();
	}

	$clean = array();

	foreach ( $rows as $row ) {
		// Rows arrive either keyed or as the numeric pairs the form submits.
		$title = isset( $row['title'] ) ? $row['title'] : ( isset( $row[0] ) ? $row[0] : '' );
		$text  = isset( $row['text'] ) ? $row['text'] : ( isset( $row[1] ) ? $row[1] : '' );

		if ( '' === trim( (string) $title ) ) {
			continue;
		}

		$title = sanitize_text_field( $title );
		$text  = sanitize_textarea_field( $text );
		$idx   = count( $clean );

		if ( function_exists( 'muhamedahmed_t' ) ) {
			$title = muhamedahmed_t( $title, 'mah_process.' . $idx . '.0' );
			$text  = muhamedahmed_t( $text, 'mah_process.' . $idx . '.1' );
		}

		$clean[] = array(
			'title' => $title,
			'text'  => $text,
		);
	}

	return $clean;
}

/**
 * Read the statistics.
 *
 * @return array Rows of value and label.
 */
function mah_content_stats() {
	$rows = get_option( 'mah_stats', array() );

	if ( ! is_array( $rows ) || ! $rows ) {
		return array();
	}

	$clean = array();

	foreach ( $rows as $row ) {
		$value = isset( $row['value'] ) ? $row['value'] : ( isset( $row[0] ) ? $row[0] : '' );
		$label = isset( $row['label'] ) ? $row['label'] : ( isset( $row[1] ) ? $row[1] : '' );

		if ( '' === trim( (string) $value ) ) {
			continue;
		}

		$value = sanitize_text_field( $value );
		$label = sanitize_textarea_field( $label );
		$idx   = count( $clean );

		if ( function_exists( 'muhamedahmed_t' ) ) {
			$value = muhamedahmed_t( $value, 'mah_stats.' . $idx . '.0' );
			$label = muhamedahmed_t( $label, 'mah_stats.' . $idx . '.1' );
		}

		$clean[] = array(
			'value' => $value,
			'label' => $label,
		);
	}

	return $clean;
}

/**
 * Render the process grid.
 *
 * @return string
 */
function mah_content_process() {
	$steps = mah_content_process_steps();

	if ( ! $steps ) {
		return '';
	}

	$html  = '<ol class="mah-proc-grid" data-mah-process>';
	$index = 0;

	foreach ( $steps as $step ) {
		$index++;
		$html .= '<li class="mah-proc__step" data-mah-step>';
		$html .= sprintf(
			'<span class="mah-proc__index" data-mah-step-dot>%s</span>',
			esc_html( str_pad( (string) $index, 2, '0', STR_PAD_LEFT ) )
		);
		$html .= sprintf( '<h3 class="mah-proc__title">%s</h3>', esc_html( $step['title'] ) );

		if ( $step['text'] ) {
			$html .= sprintf( '<p>%s</p>', esc_html( $step['text'] ) );
		}

		$html .= '</li>';
	}

	$html .= '</ol>';

	return $html;
}

/**
 * Render the statistics grid.
 *
 * @return string
 */
function mah_content_stats_grid() {
	if ( function_exists( 'muhamedahmed_render_stats' ) ) {
		return muhamedahmed_render_stats();
	}

	$stats = mah_content_stats();

	if ( ! $stats ) {
		return '';
	}

	$html = '<ul class="mah-stats" aria-label="' . esc_attr__( 'Verified figures', 'prowpsite-panel' ) . '">';

	foreach ( $stats as $stat ) {
		$html .= '<li class="mah-stat">';
		$html .= sprintf( '<p class="mah-stat__value">%s</p>', esc_html( $stat['value'] ) );
		$html .= sprintf( '<p class="mah-stat__label">%s</p>', esc_html( $stat['label'] ) );
		$html .= '</li>';
	}

	$html .= '</ul>';

	return $html;
}

/**
 * Render the availability pill.
 *
 * @return string
 */
function mah_content_availability() {
	if ( ! mah_content_identity( 'available' ) ) {
		return '';
	}

	$text = mah_content_identity( 'availability' );

	if ( ! $text ) {
		return '';
	}

	return sprintf(
		'<p class="mah-pill"><span class="mah-pill__dot" aria-hidden="true"></span>%s</p>',
		esc_html( $text )
	);
}
/**
 * Sanitise a repeated two-column list.
 *
 * Rows are supplied as arrays of strings. Only the two named columns are kept,
 * so a stray key in the form cannot reach the database.
 *
 * @param array $raw Submitted rows.
 * @return array
 */
function mah_content_clean_rows( $raw ) {
	$raw = is_array( $raw ) ? $raw : array();
	$out = array();

	foreach ( $raw as $row ) {
		if ( ! is_array( $row ) ) {
			continue;
		}

		$first = isset( $row[0] ) ? sanitize_text_field( $row[0] ) : '';
		$rest  = isset( $row[1] ) ? sanitize_textarea_field( $row[1] ) : '';

		if ( '' === $first ) {
			continue;
		}

		// Which pair of columns is this depends on the caller, so both are kept
		// under numeric keys and the caller maps them.
		$out[] = array(
			0 => $first,
			1 => $rest,
		);
	}

	return $out;
}