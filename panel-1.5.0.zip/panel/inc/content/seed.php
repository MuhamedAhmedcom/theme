<?php
/**
 * First-run content.
 *
 * Seeds the plugin with content once, so a fresh install is not an empty page.
 * It runs only while the site has no projects and no identity details, and it
 * never overwrites anything afterwards.
 *
 * @package MuhamedAhmed_Content
 */

defined( 'ABSPATH' ) || exit;

/**
 * Seed the default content on activation.
 *
 * @return void
 */
function mah_content_seed() {
	/**
	 * Whether first-run content seeding should run.
	 *
	 * Playground fixtures hook this (from an mu-plugin) and return false so
	 * snapshot posts are not mixed with the plugin defaults. Production
	 * installs leave the default true. The seeder still no-ops when any
	 * mah_project post already exists.
	 *
	 * @param bool $enabled Default true.
	 */
	if ( ! apply_filters( 'mah_content_seed_enabled', true ) ) {
		return;
	}

	$existing = get_posts(
		array(
			'post_type'      => 'mah_project',
			'posts_per_page' => 1,
			'post_status'    => 'any',
			'fields'         => 'ids',
		)
	);

	if ( $existing ) {
		// Already populated, never touch it.
		return;
	}

	mah_content_seed_identity();
	mah_content_seed_services();
	mah_content_seed_projects();
	mah_content_seed_reviews();
	mah_content_seed_links();
	mah_content_seed_lists();

	// A flag so the seeder is auditable and does not repeat.
	update_option( 'mah_content_seeded', gmdate( 'c' ) );
}
add_action( 'wp_loaded', 'mah_content_seed' );

/**
 * Identity defaults.
 *
 * @return void
 */
function mah_content_seed_identity() {
	$fields = mah_content_identity_fields();
	$values = array(
		'full_name'     => 'Muhamed Ahmed',
		'role'          => 'WordPress developer',
		'tagline'       => 'WordPress design and development',
		'bio'           => 'WordPress design, development and SEO for businesses that want to grow online.',
		'email'         => 'hello@muhamedahmed.com',
		'phone'         => '',
		'whatsapp'      => '',
		'location'      => 'Cairo, Egypt',
		'response_time' => 'Replies within one business day',
		'availability'  => 'Available for new projects',
		'available'     => '1',
		'cta_label'     => 'Start your project',
		'cta_action'    => 'mailto',
		'cta_target'    => '',
	);

	$stored = get_option( 'mah_identity', array() );
	$stored = is_array( $stored ) ? $stored : array();

	foreach ( $values as $key => $value ) {
		if ( empty( $stored[ $key ] ) ) {
			$stored[ $key ] = $value;
		}
	}

	update_option( 'mah_identity', mah_content_sanitize_set( $stored, $fields ) );
}

/**
 * Section links.
 *
 * @return void
 */
function mah_content_seed_links() {
	if ( get_option( 'mah_section_links' ) ) {
		return;
	}

	update_option(
		'mah_section_links',
		array(
			array(
				'label' => 'Work',
				'href'  => '#work',
			),
			array(
				'label' => 'Services',
				'href'  => '#services',
			),
			array(
				'label' => 'Process',
				'href'  => '#process',
			),
			array(
				'label' => 'Reviews',
				'href'  => '#reviews',
			),
		)
	);
}

/**
 * Services.
 *
 * @return void
 */
function mah_content_seed_services() {
	$services = array(
		array(
			'UI/UX design',
			'Interface design for WordPress that stays clear on a phone and a large monitor.',
		),
		array(
			'WordPress development',
			'Custom blocks and themes, built to load fast and stay easy to edit.',
		),
		array(
			'Performance and SEO',
			'Core Web Vitals fixed and on-page SEO done properly, not bolted on afterwards.',
		),
		array(
			'WooCommerce builds',
			'Product pages and checkouts that convert, and hold up under real traffic.',
		),
		array(
			'Care plans',
			'Updates, backups and monitoring after launch, so nothing breaks quietly.',
		),
	);

	foreach ( $services as $order => $service ) {
		wp_insert_post(
			array(
				'post_type'    => 'mah_service',
				'post_status'  => 'publish',
				'post_title'   => $service[0],
				'post_excerpt' => $service[1],
				'post_content' => '',
				'menu_order'   => $order,
			)
		);
	}
}

/**
 * Projects.
 *
 * @return void
 */
function mah_content_seed_projects() {
	$dot      = "\xC2\xB7";
	$projects = array(
		array( 'Alex Arabia', 'Brand and website for a regional agency.', 'Branding ' . $dot . ' WordPress' ),
		array( 'NASA Egypt', 'Public information site for a space outreach programme.', 'WordPress ' . $dot . ' Multilingual' ),
		array( 'Mansour Farms', 'E-commerce build for an agricultural supplier.', 'WooCommerce ' . $dot . ' Arabic RTL' ),
		array( 'Perfectil Egypt', 'Product site for a medical supplies distributor.', 'WooCommerce ' . $dot . ' SEO' ),
		array( 'PregnaCare', 'Brand and store for a maternity care range.', 'Branding ' . $dot . ' E-commerce' ),
		array( 'Dr Diamond', 'Editorial site for a private clinic.', 'WordPress ' . $dot . ' Performance' ),
	);

	foreach ( $projects as $order => $project ) {
		$id = wp_insert_post(
			array(
				'post_type'    => 'mah_project',
				'post_status'  => 'publish',
				'post_title'   => $project[0],
				'post_excerpt' => $project[1],
				'post_content' => '',
				'menu_order'   => $order,
			)
		);

		if ( $id && ! is_wp_error( $id ) ) {
			update_post_meta( $id, '_mah_tags_line', $project[2] );
		}
	}
}

/**
 * Reviews.
 *
 * @return void
 */
function mah_content_seed_reviews() {
	$reviews = array(
		array( 'Mohamed Adel', 'Founder, Alex Arabia', 'Delivered on time and the site is genuinely fast. The handover notes were better than I expected.' ),
		array( 'Dr Hala Mansour', 'NASA Egypt', 'They rebuilt our site in Arabic and English without losing a single old URL. Traffic held.' ),
		array( 'Karim Fouad', 'Mansour Farms', 'The checkout needed real work. Conversion is up a third since launch.' ),
		array( 'Sara Ibrahim', 'PregnaCare', 'The brand work made the difference. Clients now recognise us before they read the name.' ),
		array( 'Tarek Nabil', 'Dr Diamond', 'Accessibility was not a lecture, it was just done properly. That mattered to us.' ),
		array( 'Nesma Kamel', 'Perfectil Egypt', 'Six months on, the site still runs fast and I can edit it myself.' ),
	);

	foreach ( $reviews as $order => $review ) {
		$id = wp_insert_post(
			array(
				'post_type'    => 'mah_review',
				'post_status'  => 'publish',
				'post_title'   => $review[0],
				'post_content' => $review[2],
				'menu_order'   => $order,
			)
		);

		if ( $id && ! is_wp_error( $id ) ) {
			update_post_meta( $id, '_mah_author', $review[0] );
			update_post_meta( $id, '_mah_role', $review[1] );
			update_post_meta( $id, '_mah_rating', 5 );
			update_post_meta( $id, '_mah_highlight', 0 === $order % 3 );
		}
	}
}
/**
 * Process steps, statistics and marquee phrases.
 *
 * @return void
 */
function mah_content_seed_lists() {
	if ( ! get_option( 'mah_process' ) ) {
		update_option(
			'mah_process',
			array(
				array( 'Discover', 'A short call to find out what the site has to achieve, and who it is for.' ),
				array( 'Design', 'Interface design first, so the layout is settled before any code is written.' ),
				array( 'Build', 'Clean Gutenberg blocks you can edit yourself, with no page builder lock-in.' ),
				array( 'Launch', 'Performance, accessibility and SEO checked on real devices, then go live.' ),
			)
		);
	}

	if ( ! get_option( 'mah_stats' ) ) {
		update_option(
			'mah_stats',
			array(
				array( '120+', 'Projects delivered across Egypt and the Gulf.' ),
				array( '4.9', 'Average client rating, from 40+ reviews.' ),
				array( '6 yrs', 'Building for WordPress every day since 2020.' ),
			)
		);
	}

	if ( ! get_option( 'mah_marquee_phrases' ) ) {
		update_option(
			'mah_marquee_phrases',
			array( 'WordPress design', 'Accessible by default', 'Built to convert', 'Shipped on time' )
		);
	}
}