<?php
/**
 * Services as a custom post type.
 *
 * @package MuhamedAhmed_Content
 */

defined( 'ABSPATH' ) || exit;

/**
 * Register the service post type.
 *
 * @return void
 */
function mah_register_service() {
	register_post_type(
		'mah_service',
		array(
			'labels'        => array(
				'name'          => __( 'Services', 'prowpsite-panel' ),
				'singular_name' => __( 'Service', 'prowpsite-panel' ),
				'add_new'       => __( 'Add service', 'prowpsite-panel' ),
				'add_new_item'  => __( 'Add new service', 'prowpsite-panel' ),
				'edit_item'     => __( 'Edit service', 'prowpsite-panel' ),
				'menu_name'     => __( 'Services', 'prowpsite-panel' ),
			),
			'public'        => false,
			'show_ui'       => true,
			'show_in_rest'  => true,
			'hierarchical'  => false,
			'menu_icon'     => 'dashicons-portfolio',
			'menu_position' => 28,
			'supports'      => array( 'title', 'editor', 'excerpt', 'page-attributes', 'revisions' ),
			'show_in_menu'  => true,
		)
	);
}
add_action( 'init', 'mah_register_service' );

/**
 * Highlight switcher on a service. Default off.
 *
 * @return void
 */
function mah_register_service_meta() {
	register_post_meta(
		'mah_service',
		'_mah_highlight',
		array(
			'type'              => 'boolean',
			'single'            => true,
			'show_in_rest'      => true,
			'sanitize_callback' => 'rest_sanitize_boolean',
			'auth_callback'     => function ( $allowed, $meta_key, $post_id ) {
				unset( $allowed, $meta_key );

				return current_user_can( 'edit_post', (int) $post_id );
			},
			'default'           => false,
		)
	);
}
add_action( 'init', 'mah_register_service_meta', 11 );

/**
 * Read one service field.
 *
 * @param int    $post_id Service id.
 * @param string $key     Meta key without the prefix.
 * @return string
 */
function mah_service_meta( $post_id, $key ) {
	$value = get_post_meta( $post_id, '_mah_' . $key, true );

	return is_string( $value ) ? $value : '';
}