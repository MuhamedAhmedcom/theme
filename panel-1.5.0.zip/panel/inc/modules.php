<?php
/**
 * Load mah-content and homepage blocks from this plugin.
 *
 * Skips a module when the original standalone plugin is still active, so the
 * two copies cannot redeclare functions during the switch. Rewrite rules are
 * flushed once per panel version, not on every request.
 *
 * @package ProWPSite
 */

defined( 'ABSPATH' ) || exit;

/**
 * Whether the standalone mah-content plugin already loaded.
 *
 * @return bool
 */
function prowp_legacy_content_active() {
	return defined( 'MAH_CONTENT_VERSION' ) || function_exists( 'mah_register_project' );
}

/**
 * Whether the standalone homepage-blocks plugin already loaded.
 *
 * @return bool
 */
function prowp_legacy_blocks_active() {
	return defined( 'MUHAMEDAHMED_BLOCKS_VERSION' ) || function_exists( 'muhamedahmed_blocks_register' );
}

/**
 * Standalone plugin slugs that panel skipped this request.
 *
 * @return array<int,string>
 */
function prowp_panel_skipped_legacy_plugins() {
	$skipped = isset( $GLOBALS['prowp_panel_skipped_legacy'] ) ? $GLOBALS['prowp_panel_skipped_legacy'] : array();

	return is_array( $skipped ) ? $skipped : array();
}

/**
 * Remember which standalone plugins were left in charge this request.
 *
 * @param array<int,string> $slugs Plugin directory slugs.
 * @return void
 */
function prowp_panel_store_skipped_legacy( array $slugs ) {
	$GLOBALS['prowp_panel_skipped_legacy'] = array_values( array_unique( array_filter( $slugs ) ) );
}

/**
 * Load the content module (CPTs, meta, settings, renderers, seed).
 *
 * @return void
 */
function prowp_panel_load_content_module() {
	if ( ! defined( 'MAH_CONTENT_VERSION' ) ) {
		define( 'MAH_CONTENT_VERSION', PROWP_VERSION );
	}

	if ( ! defined( 'MAH_CONTENT_FILE' ) ) {
		define( 'MAH_CONTENT_FILE', PROWP_FILE );
	}

	if ( ! defined( 'MAH_CONTENT_DIR' ) ) {
		define( 'MAH_CONTENT_DIR', PROWP_PATH . 'inc/content/' );
	}

	$files = array(
		'fields.php',
		'identity.php',
		'lists.php',
		'navigation.php',
		'portfolioupost.php',
		'reviewpost.php',
		'servicepost.php',
		'blocks.php',
		'settings.php',
		'render.php',
		'seed.php',
	);

	foreach ( $files as $file ) {
		require_once PROWP_PATH . 'inc/content/' . $file;
	}
}

/**
 * Load homepage block module (hero, section, marquee, stats, about, work).
 *
 * @return void
 */
function prowp_panel_load_blocks_module() {
	if ( ! defined( 'MUHAMEDAHMED_BLOCKS_VERSION' ) ) {
		define( 'MUHAMEDAHMED_BLOCKS_VERSION', PROWP_VERSION );
	}

	if ( ! defined( 'MUHAMEDAHMED_BLOCKS_FILE' ) ) {
		define( 'MUHAMEDAHMED_BLOCKS_FILE', PROWP_FILE );
	}

	if ( ! defined( 'MUHAMEDAHMED_BLOCKS_DIR' ) ) {
		define( 'MUHAMEDAHMED_BLOCKS_DIR', PROWP_PATH . 'inc/blocks/' );
	}

	if ( ! defined( 'MUHAMEDAHMED_BLOCKS_URL' ) ) {
		define( 'MUHAMEDAHMED_BLOCKS_URL', PROWP_URL );
	}

	require_once PROWP_PATH . 'inc/blocks/data.php';
	require_once PROWP_PATH . 'inc/blocks/present.php';
	require_once PROWP_PATH . 'inc/blocks/home.php';
	require_once PROWP_PATH . 'inc/blocks/blocks.php';
}

/**
 * Load merged modules after every plugin file has been included.
 *
 * @return void
 */
function prowp_panel_load_merged_modules() {
	static $loaded = false;

	if ( $loaded ) {
		return;
	}

	$loaded  = true;
	$skipped = array();

	if ( prowp_legacy_content_active() ) {
		$skipped[] = 'mah-content';
	} else {
		prowp_panel_load_content_module();
	}

	if ( prowp_legacy_blocks_active() ) {
		$skipped[] = 'muhamed-ahmed-blocks';
	} else {
		prowp_panel_load_blocks_module();
	}

	if ( ! function_exists( 'muhamedahmed_render_home' ) && is_readable( PROWP_PATH . 'inc/blocks/home.php' ) ) {
		require_once PROWP_PATH . 'inc/blocks/home.php';
	}

	prowp_panel_store_skipped_legacy( $skipped );
}

/**
 * Register CPTs that own rewrite slugs, then flush once.
 *
 * @return void
 */
function prowp_panel_register_content_types() {
	if ( function_exists( 'mah_register_project' ) ) {
		mah_register_project();
	}

	if ( function_exists( 'mah_register_project_meta' ) ) {
		mah_register_project_meta();
	}

	if ( function_exists( 'mah_register_review' ) ) {
		mah_register_review();
	}

	if ( function_exists( 'mah_register_review_meta' ) ) {
		mah_register_review_meta();
	}

	if ( function_exists( 'mah_register_service' ) ) {
		mah_register_service();
	}
}

/**
 * Flush rewrite rules once for this panel version.
 *
 * @return void
 */
function prowp_panel_flush_rewrites_once() {
	if ( get_option( 'prowp_panel_rewrite_version' ) === PROWP_VERSION ) {
		return;
	}

	prowp_panel_register_content_types();
	flush_rewrite_rules( false );
	update_option( 'prowp_panel_rewrite_version', PROWP_VERSION );
}

/**
 * Activation: load modules, register types, flush rewrites.
 *
 * @return void
 */
function prowp_panel_activate() {
	prowp_panel_load_merged_modules();
	if ( function_exists( 'prowp_panel_maybe_upgrade' ) ) {
		prowp_panel_maybe_upgrade();
	}
	prowp_panel_flush_rewrites_once();
}

/**
 * Human-readable plugin titles for the coexistence notice.
 *
 * @return array<string,string>
 */
function prowp_panel_legacy_plugin_titles() {
	return array(
		'mah-content'            => __( 'Muhamed Ahmed — Content Source (mah-content)', 'prowpsite-panel' ),
		'muhamed-ahmed-blocks'   => __( 'Muhamed Ahmed Homepage Blocks (muhamed-ahmed-blocks)', 'prowpsite-panel' ),
	);
}

/**
 * Dismissible warning on the Plugins screen while a standalone plugin is active.
 *
 * @return void
 */
function prowp_panel_coexistence_notice() {
	if ( ! current_user_can( 'activate_plugins' ) ) {
		return;
	}

	$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;

	if ( ! $screen || 'plugins' !== $screen->id ) {
		return;
	}

	$skipped = prowp_panel_skipped_legacy_plugins();

	if ( ! $skipped ) {
		return;
	}

	$titles = prowp_panel_legacy_plugin_titles();
	$names  = array();

	foreach ( $skipped as $slug ) {
		$names[] = isset( $titles[ $slug ] ) ? $titles[ $slug ] : $slug;
	}

	$list = implode( ', ', $names );

	echo '<div class="notice notice-warning is-dismissible"><p>';
	echo esc_html(
		sprintf(
			/* translators: %s: plugin names to deactivate. */
			__( 'Panel now includes the same features. Deactivate these plugins so the site runs on the child theme plus Panel only: %s', 'prowpsite-panel' ),
			$list
		)
	);
	echo '</p></div>';
}

require_once PROWP_PATH . 'inc/i18n.php';
require_once PROWP_PATH . 'inc/projects.php';
require_once PROWP_PATH . 'inc/reviews.php';
require_once PROWP_PATH . 'inc/upgrade.php';

add_action( 'plugins_loaded', 'prowp_panel_load_merged_modules', 0 );

if ( did_action( 'plugins_loaded' ) ) {
	prowp_panel_load_merged_modules();
}

add_action( 'plugins_loaded', 'prowp_panel_maybe_upgrade', 20 );
add_action( 'admin_init', 'prowp_panel_maybe_upgrade', 1 );
add_action( 'init', 'prowp_panel_flush_rewrites_once', 99 );
add_action( 'admin_notices', 'prowp_panel_coexistence_notice' );
