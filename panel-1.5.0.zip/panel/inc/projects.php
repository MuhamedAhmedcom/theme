<?php
/**
 * Project featured/priority meta, shared query args, and admin list columns.
 *
 * Loaded even when the standalone mah-content plugin is still active, so a
 * zip overwrite does not depend on deactivating the old plugin first.
 *
 * @package ProWPSite
 */

defined( 'ABSPATH' ) || exit;

/**
 * Whether the current user may edit this project's meta via REST.
 *
 * @param bool   $allowed  Incoming.
 * @param string $meta_key Meta key.
 * @param int    $post_id  Post id.
 * @return bool
 */
function mah_project_meta_auth( $allowed, $meta_key, $post_id ) {
	unset( $allowed, $meta_key );

	return current_user_can( 'edit_post', (int) $post_id );
}

/**
 * Sanitize the featured flag to a REST boolean.
 *
 * @param mixed $value Raw value.
 * @return bool
 */
function mah_sanitize_featured_meta( $value ) {
	return (bool) rest_sanitize_boolean( $value );
}

/**
 * Sanitize priority to a non-negative integer.
 *
 * @param mixed $value Raw value.
 * @return int
 */
function mah_sanitize_priority_meta( $value ) {
	return absint( $value );
}

/**
 * Register Featured and Priority on mah_project for REST and sanitize_callback.
 *
 * @return void
 */
function mah_register_featured_priority_meta() {
	register_post_meta(
		'mah_project',
		'_mah_featured',
		array(
			'type'              => 'boolean',
			'single'            => true,
			'show_in_rest'      => true,
			'sanitize_callback' => 'mah_sanitize_featured_meta',
			'auth_callback'     => 'mah_project_meta_auth',
			'default'           => false,
		)
	);

	register_post_meta(
		'mah_project',
		'_mah_priority',
		array(
			'type'              => 'integer',
			'single'            => true,
			'show_in_rest'      => true,
			'sanitize_callback' => 'mah_sanitize_priority_meta',
			'auth_callback'     => 'mah_project_meta_auth',
			'default'           => 0,
		)
	);

	$case_keys = array( '_mah_role', '_mah_challenge', '_mah_outcome', '_mah_services' );

	foreach ( $case_keys as $meta_key ) {
		register_post_meta(
			'mah_project',
			$meta_key,
			array(
				'type'              => 'string',
				'single'            => true,
				'show_in_rest'      => true,
				'sanitize_callback' => 'sanitize_textarea_field',
				'auth_callback'     => 'mah_project_meta_auth',
				'default'           => '',
			)
		);
	}
}
add_action( 'init', 'mah_register_featured_priority_meta', 11 );

/**
 * Shared WP_Query args: featured first, then priority, menu_order, date.
 *
 * Missing meta is treated as featured=0, priority=0 via NOT EXISTS clauses.
 *
 * @param array<string,mixed> $args Overrides.
 * @return array<string,mixed>
 */
function muhamedahmed_projects_query_args( $args = array() ) {
	$defaults = array(
		'post_type'           => 'mah_project',
		'post_status'         => 'publish',
		'ignore_sticky_posts' => true,
		'suppress_filters'    => false,
		'meta_query'          => array(
			'relation'             => 'AND',
			'mah_featured_clause'  => array(
				'relation' => 'OR',
				array(
					'key'     => '_mah_featured',
					'compare' => 'NOT EXISTS',
				),
				array(
					'key'     => '_mah_featured',
					'type'    => 'NUMERIC',
					'compare' => 'EXISTS',
				),
			),
			'mah_priority_clause'  => array(
				'relation' => 'OR',
				array(
					'key'     => '_mah_priority',
					'compare' => 'NOT EXISTS',
				),
				array(
					'key'     => '_mah_priority',
					'type'    => 'NUMERIC',
					'compare' => 'EXISTS',
				),
			),
		),
		'orderby'             => array(
			'mah_featured_clause' => 'DESC',
			'mah_priority_clause' => 'ASC',
			'menu_order'          => 'ASC',
			'date'                => 'DESC',
		),
		'mah_project_order'   => 1,
	);

	if ( ! is_array( $args ) ) {
		$args = array();
	}

	return array_merge( $defaults, $args );
}

/**
 * COALESCE missing featured/priority to 0 so NOT EXISTS rows sort as 0, not NULL.
 *
 * @param array<string,string> $clauses Query clauses.
 * @param WP_Query             $query   Query.
 * @return array<string,string>
 */
function muhamedahmed_projects_posts_clauses( $clauses, $query ) {
	if ( ! $query instanceof WP_Query || ! $query->get( 'mah_project_order' ) ) {
		return $clauses;
	}

	global $wpdb;

	$clauses['join'] .= " LEFT JOIN {$wpdb->postmeta} AS mah_feat ON ({$wpdb->posts}.ID = mah_feat.post_id AND mah_feat.meta_key = '_mah_featured') ";
	$clauses['join'] .= " LEFT JOIN {$wpdb->postmeta} AS mah_prio ON ({$wpdb->posts}.ID = mah_prio.post_id AND mah_prio.meta_key = '_mah_priority') ";
	$clauses['orderby'] = "CAST(COALESCE(mah_feat.meta_value,0) AS SIGNED) DESC, CAST(COALESCE(mah_prio.meta_value,0) AS SIGNED) ASC, {$wpdb->posts}.menu_order ASC, {$wpdb->posts}.post_date DESC";
	$clauses['groupby'] = "{$wpdb->posts}.ID";

	return $clauses;
}
add_filter( 'posts_clauses', 'muhamedahmed_projects_posts_clauses', 10, 2 );

/**
 * Whether any published project has _mah_featured truthy.
 *
 * @return bool
 */
function muhamedahmed_projects_has_featured_flag() {
	$query = new WP_Query(
		array(
			'post_type'              => 'mah_project',
			'post_status'            => 'publish',
			'posts_per_page'         => 1,
			'fields'                 => 'ids',
			'no_found_rows'          => true,
			'ignore_sticky_posts'    => true,
			'update_post_meta_cache' => false,
			'update_post_term_cache' => false,
			'meta_query'             => array(
				array(
					'key'     => '_mah_featured',
					'value'   => 1,
					'type'    => 'NUMERIC',
					'compare' => '=',
				),
			),
		)
	);

	return $query->have_posts();
}

/**
 * Featured project id: lowest _mah_priority among featured, else panel fallback.
 *
 * @return int
 */
function muhamedahmed_projects_featured_id() {
	if ( muhamedahmed_projects_has_featured_flag() ) {
		$query = new WP_Query(
			muhamedahmed_projects_query_args(
				array(
					'posts_per_page'         => 1,
					'fields'                 => 'ids',
					'no_found_rows'          => true,
					'update_post_meta_cache' => false,
					'update_post_term_cache' => false,
				)
			)
		);

		if ( ! empty( $query->posts[0] ) ) {
			$id = absint( $query->posts[0] );

			return function_exists( 'muhamedahmed_object_id' )
				? muhamedahmed_object_id( $id, 'mah_project', true )
				: $id;
		}
	}

	$fallback = absint( get_option( 'mah_home_featured_project', 0 ) );

	if ( function_exists( 'muhamedahmed_object_id' ) ) {
		$fallback = muhamedahmed_object_id( $fallback, 'mah_project', true );
	}

	return $fallback;
}

/**
 * Published projects in home/archive order.
 *
 * @param int $count Max posts.
 * @return array<int,WP_Post>
 */
function muhamedahmed_projects_ordered( $count = 20 ) {
	$count = max( 1, min( 40, (int) $count ) );
	$posts = get_posts(
		muhamedahmed_projects_query_args(
			array(
				'posts_per_page' => $count,
				'no_found_rows'  => true,
			)
		)
	);

	return is_array( $posts ) ? $posts : array();
}

/**
 * Apply the shared order to the main projects archive query.
 *
 * @param WP_Query $query Query.
 * @return void
 */
function muhamedahmed_projects_pre_get_posts( $query ) {
	if ( ! $query instanceof WP_Query ) {
		return;
	}

	if ( is_admin() ) {
		if ( ! $query->is_main_query() ) {
			return;
		}

		$screen_type = $query->get( 'post_type' );

		if ( 'mah_project' !== $screen_type ) {
			return;
		}

		if ( 'mah_priority' === $query->get( 'orderby' ) ) {
			$order = strtoupper( (string) $query->get( 'order' ) );
			$order = 'DESC' === $order ? 'DESC' : 'ASC';
			$query->set( 'meta_key', '_mah_priority' );
			$query->set(
				'orderby',
				array(
					'meta_value_num' => $order,
					'menu_order'     => 'ASC',
				)
			);
		}

		return;
	}

	if ( ! $query->is_main_query() ) {
		return;
	}

	$is_archive = $query->is_post_type_archive( 'mah_project' );
	$is_tax     = $query->is_tax( 'mah_project_cat' );
	$is_type    = 'mah_project' === $query->get( 'post_type' );

	if ( ! $is_archive && ! $is_tax && ! $is_type ) {
		return;
	}

	$shared = muhamedahmed_projects_query_args();
	$query->set( 'meta_query', $shared['meta_query'] );
	$query->set( 'orderby', $shared['orderby'] );
	$query->set( 'mah_project_order', 1 );
}
add_action( 'pre_get_posts', 'muhamedahmed_projects_pre_get_posts' );

/**
 * Admin list columns.
 *
 * @param array<string,string> $columns Columns.
 * @return array<string,string>
 */
function mah_project_posts_columns( $columns ) {
	$out = array();

	foreach ( $columns as $key => $label ) {
		$out[ $key ] = $label;

		if ( 'title' === $key ) {
			$out['mah_featured'] = __( 'Featured', 'prowpsite-panel' );
			$out['mah_priority'] = __( 'Priority', 'prowpsite-panel' );
		}
	}

	if ( ! isset( $out['mah_featured'] ) ) {
		$out['mah_featured'] = __( 'Featured', 'prowpsite-panel' );
		$out['mah_priority'] = __( 'Priority', 'prowpsite-panel' );
	}

	return $out;
}
add_filter( 'manage_mah_project_posts_columns', 'mah_project_posts_columns' );

/**
 * Admin list cell output.
 *
 * @param string $column  Column id.
 * @param int    $post_id Post id.
 * @return void
 */
function mah_project_posts_custom_column( $column, $post_id ) {
	if ( 'mah_featured' === $column ) {
		$flag = rest_sanitize_boolean( get_post_meta( (int) $post_id, '_mah_featured', true ) );
		echo $flag ? esc_html( '★' ) : esc_html( '—' );
		return;
	}

	if ( 'mah_priority' === $column ) {
		$raw = get_post_meta( (int) $post_id, '_mah_priority', true );
		echo esc_html( (string) absint( '' === $raw ? 0 : $raw ) );
	}
}
add_action( 'manage_mah_project_posts_custom_column', 'mah_project_posts_custom_column', 10, 2 );

/**
 * Sortable Priority column. menu_order remains the drag-order tie-breaker.
 *
 * @param array<string,string> $columns Columns.
 * @return array<string,string>
 */
function mah_project_sortable_columns( $columns ) {
	$columns['mah_priority'] = 'mah_priority';

	return $columns;
}
add_filter( 'manage_edit-mah_project_sortable_columns', 'mah_project_sortable_columns' );

/**
 * Write 0 for missing featured/priority so queries stay numeric.
 *
 * @param int     $post_id Post id.
 * @param WP_Post $post    Post.
 * @return void
 */
function mah_project_backfill_order_meta( $post_id, $post ) {
	if ( ! $post instanceof WP_Post || 'mah_project' !== $post->post_type ) {
		return;
	}

	if ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) {
		return;
	}

	if ( ! metadata_exists( 'post', $post_id, '_mah_featured' ) ) {
		update_post_meta( $post_id, '_mah_featured', 0 );
	}

	if ( ! metadata_exists( 'post', $post_id, '_mah_priority' ) ) {
		update_post_meta( $post_id, '_mah_priority', 0 );
	}
}
add_action( 'save_post_mah_project', 'mah_project_backfill_order_meta', 20, 2 );
