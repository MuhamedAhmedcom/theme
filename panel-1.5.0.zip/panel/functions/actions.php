<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access directly.
/**
 *
 * Get icons from admin ajax
 *
 * @since 1.0.0
 * @version 1.0.0
 *
 */
if ( ! function_exists( 'csf_get_icons' ) ) {
  function csf_get_icons() {

    $nonce = ( ! empty( $_POST[ 'nonce' ] ) ) ? sanitize_text_field( wp_unslash( $_POST[ 'nonce' ] ) ) : '';

    if ( ! wp_verify_nonce( $nonce, 'csf_icon_nonce' ) ) {
      wp_send_json_error( array( 'error' => esc_html__( 'Error: Invalid nonce verification.', 'csf' ) ) );
    }
    if ( ! current_user_can( 'manage_options' ) ) {
      wp_send_json_error( array( 'error' => esc_html__( 'Error: Insufficient permissions.', 'csf' ) ) );
    }

    ob_start();

    $icon_library = ( apply_filters( 'csf_fa4', false ) ) ? 'fa4' : 'fa5';

    CSF::include_plugin_file( 'fields/icon/'. $icon_library .'-icons.php' );

    $icon_lists = apply_filters( 'csf_field_icon_add_icons', csf_get_default_icons() );

    if ( ! empty( $icon_lists ) ) {

      foreach ( $icon_lists as $list ) {

        echo ( count( $icon_lists ) >= 2 ) ? '<div class="csf-icon-title">'. esc_attr( $list['title'] ) .'</div>' : '';

        foreach ( $list['icons'] as $icon ) {
          echo '<i title="'. esc_attr( $icon ) .'" class="'. esc_attr( $icon ) .'"></i>';
        }

      }

    } else {

      echo '<div class="csf-error-text">'. esc_html__( 'No data available.', 'csf' ) .'</div>';

    }

    $content = ob_get_clean();

    wp_send_json_success( array( 'content' => $content ) );

  }
  add_action( 'wp_ajax_csf-get-icons', 'csf_get_icons' );
}

/**
 *
 * Export
 *
 * @since 1.0.0
 * @version 1.0.0
 *
 */
if ( ! function_exists( 'csf_export' ) ) {
  function csf_export() {

    $nonce  = ( ! empty( $_GET[ 'nonce' ] ) ) ? sanitize_text_field( wp_unslash( $_GET[ 'nonce' ] ) ) : '';
    $unique = ( ! empty( $_GET[ 'unique' ] ) ) ? sanitize_text_field( wp_unslash( $_GET[ 'unique' ] ) ) : '';

    if ( ! wp_verify_nonce( $nonce, 'csf_backup_nonce' ) ) {
      die( esc_html__( 'Error: Invalid nonce verification.', 'csf' ) );
    }

    if ( ! current_user_can( apply_filters( 'csf_backup_capability', 'manage_options' ) ) ) {
      die( esc_html__( 'Error: You do not have permission to do that.', 'csf' ) );
    }

    if ( empty( $unique ) || ! csf_backup_unique_is_allowed( $unique ) ) {
      die( esc_html__( 'Error: Invalid key.', 'csf' ) );
    }

    // Export
    header('Content-Type: application/json');
    header('Content-disposition: attachment; filename=backup-'. gmdate( 'd-m-Y' ) .'.json');
    header('Content-Transfer-Encoding: binary');
    header('Pragma: no-cache');
    header('Expires: 0');

    echo json_encode( get_option( $unique ) );

    die();

  }
  add_action( 'wp_ajax_csf-export', 'csf_export' );
}

/**
 * Option keys registered as Codestar admin option uniques.
 *
 * Import/Export may only read these keys. Arbitrary options such as siteurl
 * stay rejected. The list is derived from CSF::$args, not a hardcoded literal.
 *
 * @return array<int,string>
 */
if ( ! function_exists( 'csf_backup_allowed_uniques' ) ) {
  function csf_backup_allowed_uniques() {
    $registered = array();

    if ( class_exists( 'CSF' ) && isset( CSF::$args['admin_options'] ) && is_array( CSF::$args['admin_options'] ) ) {
      foreach ( array_keys( CSF::$args['admin_options'] ) as $key ) {
        $key = (string) $key;
        if ( $key === '' || ! preg_match( '/^[a-zA-Z0-9_\-]+$/', $key ) ) {
          continue;
        }
        $registered[] = $key;
      }
    }

    $allowed = apply_filters( 'csf_backup_allowed_unique', $registered );

    if ( ! is_array( $allowed ) ) {
      return array();
    }

    $clean = array();

    foreach ( $allowed as $key ) {
      $key = (string) $key;
      if ( $key === '' || ! preg_match( '/^[a-zA-Z0-9_\-]+$/', $key ) ) {
        continue;
      }
      $clean[] = $key;
    }

    return array_values( array_unique( $clean ) );
  }
}

/**
 * Whether a Codestar backup action may access an option key.
 *
 * @param string $unique Option key.
 * @return bool
 */
if ( ! function_exists( 'csf_backup_unique_is_allowed' ) ) {
  function csf_backup_unique_is_allowed( $unique ) {
    return in_array( (string) $unique, csf_backup_allowed_uniques(), true );
  }
}

/**
 * Decode and validate a bounded Codestar backup payload.
 *
 * Import values are deliberately not recursively KSES-filtered here. Codestar's
 * save filter still runs before storage and fields escape/sanitize at their
 * normal trust boundaries. Avoiding a second full-tree traversal prevents large
 * valid backups from exhausting the AJAX request.
 *
 * @param string $raw    Raw JSON.
 * @param string $unique Option key.
 * @return array{success:bool,data?:array,error?:string}
 */
if ( ! function_exists( 'csf_prepare_import_data' ) ) {
  function csf_prepare_import_data( $raw, $unique ) {
    if ( ! csf_backup_unique_is_allowed( $unique ) ) {
      return array( 'success' => false, 'error' => esc_html__( 'Error: Invalid key.', 'csf' ) );
    }

    // Length-check against the raw string (may still be magic-quoted).
    $raw_for_len = is_string( $raw ) ? $raw : '';
    $max_bytes   = (int) apply_filters( 'csf_backup_import_max_bytes', 5 * 1024 * 1024 );
    if ( '' === trim( $raw_for_len ) || $max_bytes < strlen( $raw_for_len ) ) {
      return array( 'success' => false, 'error' => esc_html__( 'Error: The backup is empty or exceeds the 5 MB import limit.', 'csf' ) );
    }

    // Prefer ProWP decoder (slash-safe) when available; fall back to json_decode.
    if ( class_exists( 'ProWP_Options_Import' ) && method_exists( 'ProWP_Options_Import', 'decode_backup_json' ) ) {
      $data = ProWP_Options_Import::decode_backup_json( $raw_for_len );
      if ( null === $data ) {
        return array( 'success' => false, 'error' => esc_html__( 'Error: The response is not a valid JSON backup.', 'csf' ) );
      }
      return array( 'success' => true, 'data' => $data );
    }

    $candidate = function_exists( 'wp_unslash' ) ? trim( (string) wp_unslash( $raw_for_len ) ) : trim( $raw_for_len );
    $data      = json_decode( $candidate, true, 512 );
    if ( JSON_ERROR_NONE !== json_last_error() || ! is_array( $data ) ) {
      $data = json_decode( trim( $raw_for_len ), true, 512 );
    }
    if ( JSON_ERROR_NONE !== json_last_error() || ! is_array( $data ) ) {
      return array( 'success' => false, 'error' => esc_html__( 'Error: The response is not a valid JSON backup.', 'csf' ) );
    }

    return array( 'success' => true, 'data' => $data );
  }
}

/**
 *
 * Import Ajax
 *
 * @since 1.0.0
 * @version 1.0.0
 *
 */
if ( ! function_exists( 'csf_import_ajax' ) ) {
  function csf_import_ajax() {

    $nonce  = ( ! empty( $_POST[ 'nonce' ] ) ) ? sanitize_text_field( wp_unslash( $_POST[ 'nonce' ] ) ) : '';
    $unique = ( ! empty( $_POST[ 'unique' ] ) ) ? sanitize_text_field( wp_unslash( $_POST[ 'unique' ] ) ) : '';

    if ( ! wp_verify_nonce( $nonce, 'csf_backup_nonce' ) ) {
      wp_send_json_error( array( 'error' => esc_html__( 'Error: Invalid nonce verification.', 'csf' ) ) );
    }

    if ( ! current_user_can( apply_filters( 'csf_backup_capability', 'manage_options' ) ) ) {
      wp_send_json_error( array( 'error' => esc_html__( 'Error: You do not have permission to do that.', 'csf' ) ) );
    }

    $raw      = isset( $_POST['data'] ) ? $_POST['data'] : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- decoded in csf_prepare_import_data / ProWP_Options_Import::decode_backup_json.
    $prepared = csf_prepare_import_data( $raw, $unique );
    if ( empty( $prepared['success'] ) ) {
      wp_send_json_error( array( 'error' => $prepared['error'] ) );
    }

    // Soft time budget for large homepage_sections backups on Ampps/local PHP.
    if ( function_exists( 'set_time_limit' ) ) {
      // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
      @set_time_limit( 120 );
    }

    if ( class_exists( 'ProWP_Options_Import' ) ) {
      ProWP_Options_Import::begin();
    }

    $data = apply_filters( "csf_{$unique}_save", $prepared['data'], null );
    // Large option trees should not autoload on every front request.
    update_option( $unique, $data, false );
    if ( class_exists( 'ProWP_Options_Import' ) && method_exists( 'ProWP_Options_Import', 'invalidate_caches' ) ) {
      ProWP_Options_Import::invalidate_caches();
    }
    do_action( "csf_{$unique}_save_after", $data, null );
    do_action( "csf_{$unique}_saved", $data, null );

    if ( class_exists( 'ProWP_Options_Import' ) ) {
      ProWP_Options_Import::finish();
    }

    wp_send_json_success();

  }
  add_action( 'wp_ajax_csf-import', 'csf_import_ajax' );
}

/**
 *
 * Reset Ajax
 *
 * @since 1.0.0
 * @version 1.0.0
 *
 */
if ( ! function_exists( 'csf_reset_ajax' ) ) {
  function csf_reset_ajax() {

    $nonce  = ( ! empty( $_POST[ 'nonce' ] ) ) ? sanitize_text_field( wp_unslash( $_POST[ 'nonce' ] ) ) : '';
    $unique = ( ! empty( $_POST[ 'unique' ] ) ) ? sanitize_text_field( wp_unslash( $_POST[ 'unique' ] ) ) : '';

    if ( ! wp_verify_nonce( $nonce, 'csf_backup_nonce' ) ) {
      wp_send_json_error( array( 'error' => esc_html__( 'Error: Invalid nonce verification.', 'csf' ) ) );
    }

    if ( ! current_user_can( apply_filters( 'csf_backup_capability', 'manage_options' ) ) ) {
      wp_send_json_error( array( 'error' => esc_html__( 'Error: You do not have permission to do that.', 'csf' ) ) );
    }

    if ( ! csf_backup_unique_is_allowed( $unique ) ) {
      wp_send_json_error( array( 'error' => esc_html__( 'Error: Invalid key.', 'csf' ) ) );
    }

    // Success
    delete_option( $unique );

    wp_send_json_success();

  }
  add_action( 'wp_ajax_csf-reset', 'csf_reset_ajax' );
}

/**
 *
 * Chosen Ajax
 *
 * @since 1.0.0
 * @version 1.0.0
 *
 */
if ( ! function_exists( 'csf_chosen_ajax' ) ) {
  function csf_chosen_ajax() {

    $nonce = ( ! empty( $_POST[ 'nonce' ] ) ) ? sanitize_text_field( wp_unslash( $_POST[ 'nonce' ] ) ) : '';
    $type  = ( ! empty( $_POST[ 'type' ] ) ) ? sanitize_text_field( wp_unslash( $_POST[ 'type' ] ) ) : '';
    $term  = ( ! empty( $_POST[ 'term' ] ) ) ? sanitize_text_field( wp_unslash( $_POST[ 'term' ] ) ) : '';
    $query = ( ! empty( $_POST[ 'query_args' ] ) ) ? wp_kses_post_deep( $_POST[ 'query_args' ] ) : array();

    if ( ! wp_verify_nonce( $nonce, 'csf_chosen_ajax_nonce' ) ) {
      wp_send_json_error( array( 'error' => esc_html__( 'Error: Invalid nonce verification.', 'csf' ) ) );
    }

    if ( empty( $type ) || empty( $term ) ) {
      wp_send_json_error( array( 'error' => esc_html__( 'Error: Invalid term ID.', 'csf' ) ) );
    }

    $capability = apply_filters( 'csf_chosen_ajax_capability', 'manage_options' );

    if ( ! current_user_can( $capability ) ) {
      wp_send_json_error( array( 'error' => esc_html__( 'Error: You do not have permission to do that.', 'csf' ) ) );
    }

    // Success
    $options = CSF_Fields::field_data( $type, $term, $query );

    wp_send_json_success( $options );

  }
  add_action( 'wp_ajax_csf-chosen', 'csf_chosen_ajax' );
}
