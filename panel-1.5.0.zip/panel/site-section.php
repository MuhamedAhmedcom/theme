<?php
/**
 * Site Content section for the Muhamed Ahmed panel.
 *
 * The panel could create post types and meta boxes but had nowhere to edit the
 * homepage copy. This adds one section, and a save handler that copies the
 * values into the option keys the blocks already read, so the page changes when
 * the panel is saved.
 *
 * Nothing else in the panel is touched.
 *
 * @package MuhamedAhmed
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The option key Codestar saves this panel under.
 *
 * Matches the prefix admin-options.php already uses, so both write to the same
 * place and neither can overwrite the other.
 *
 * @return string
 */
function mah_panel_prefix() {
	return 'muhamed_ahmed_panel';
}

/**
 * Read the stored panel values, or an empty array.
 *
 * @return array
 */
function mah_panel_values() {
	$stored = get_option( mah_panel_prefix(), array() );

	return is_array( $stored ) ? $stored : array();
}

/**
 * Split a textarea into trimmed, non-empty lines.
 *
 * @param string $raw Raw textarea value.
 * @return array
 */
function mah_panel_lines( $raw ) {
	$lines = preg_split( '/\r\n|\r|\n/', (string) $raw );

	return array_values( array_filter( array_map( 'trim', $lines ), 'strlen' ) );
}

/**
 * Build the field list. Kept in one function so the defaults are readable next
 * to the names they belong to.
 *
 * @return array
 */
function mah_panel_site_fields() {
	return array(

		array(
			'type'    => 'heading',
			'content' => __( 'Everything on the homepage is editable here. Saving updates the page.', 'prowpsite-panel' ),
		),
		array(
			'type'    => 'content',
			'content' => function_exists( 'muhamedahmed_languages_status_html' )
				? muhamedahmed_languages_status_html()
				: '',
		),

		// ---- About you -------------------------------------------------
		array(
			'type'    => 'heading',
			'content' => __( 'About you', 'prowpsite-panel' ),
			'subheading' => __( 'This is the section that answers why someone should hire you.', 'prowpsite-panel' ),
		),
		array(
			'id'    => 'mah_about_eyebrow',
			'type'  => 'text',
			'title' => __( 'About section eyebrow', 'prowpsite-panel' ),
		),
		array(
			'id'    => 'mah_about_heading',
			'type'  => 'text',
			'title' => __( 'About section heading', 'prowpsite-panel' ),
		),
		array(
			'id'    => 'mah_about_body',
			'type'  => 'textarea',
			'title' => __( 'Your story', 'prowpsite-panel' ),
			'desc'  => __( 'Plain words. What you do, who you do it for, what changed for them.', 'prowpsite-panel' ),
		),
		array(
			'id'      => 'mah_about_points',
			'type'    => 'textarea',
			'title'   => __( 'Three reasons to work with you', 'prowpsite-panel' ),
			'desc'    => __( 'One per line. Three is enough.', 'prowpsite-panel' ),
		),
		array(
			'id'       => 'mah_portrait_id',
			'type'     => 'media',
			'title'    => __( 'Portrait', 'prowpsite-panel' ),
			'library'  => 'all',
			'preview'  => 'medium',
			'desc'     => __( 'A transparent PNG looks best on the dark hero.', 'prowpsite-panel' ),
		),
		array(
			'id'       => 'mah_logo_id',
			'type'     => 'media',
			'title'    => __( 'Logo', 'prowpsite-panel' ),
			'library'  => 'image',
			'preview'  => 'medium',
			'default'  => (int) get_option( 'mah_logo_id', 0 ),
			'desc'     => __( 'Shown in the header and footer. Empty uses the name as a wordmark.', 'prowpsite-panel' ),
		),

		// ---- Your details -----------------------------------------------
		array(
			'type'    => 'heading',
			'content' => __( 'Your details', 'prowpsite-panel' ),
			'subheading' => __( 'These appear in the header, the footer and the contact block.', 'prowpsite-panel' ),
		),
		array(
			'id'      => 'mah_full_name',
			'type'    => 'text',
			'title'   => __( 'Name', 'prowpsite-panel' ),
			'default' => 'Muhamed Ahmed',
		),
		array(
			'id'    => 'mah_role',
			'type'  => 'text',
			'title' => __( 'Role line', 'prowpsite-panel' ),
		),
		array(
			'id'    => 'mah_tagline',
			'type'  => 'text',
			'title' => __( 'Tagline', 'prowpsite-panel' ),
		),
		array(
			'id'    => 'mah_bio',
			'type'  => 'textarea',
			'title' => __( 'Short bio', 'prowpsite-panel' ),
		),
		array(
			'id'    => 'mah_email',
			'type'  => 'text',
			'title' => __( 'Email', 'prowpsite-panel' ),
		),
		array(
			'id'      => 'mah_phone',
			'type'    => 'text',
			'title'   => __( 'Phone', 'prowpsite-panel' ),
			'desc'    => __( 'Include the country code.', 'prowpsite-panel' ),
		),
		array(
			'id'      => 'mah_whatsapp',
			'type'    => 'text',
			'title'   => __( 'WhatsApp', 'prowpsite-panel' ),
			'desc'    => __( 'Digits only, with country code.', 'prowpsite-panel' ),
		),
		array(
			'id'    => 'mah_location',
			'type'  => 'text',
			'title' => __( 'Location', 'prowpsite-panel' ),
		),
		array(
			'id'    => 'mah_years_experience',
			'type'  => 'text',
			'title' => __( 'Years of experience', 'prowpsite-panel' ),
			'desc'  => __( 'Owner-entered. Empty hides this proof-strip item. Not computed.', 'prowpsite-panel' ),
		),
		array(
			'id'    => 'mah_years_experience_label',
			'type'  => 'text',
			'title' => __( 'Years label', 'prowpsite-panel' ),
			'desc'  => __( 'Shown under the years value. Empty shows the value only.', 'prowpsite-panel' ),
		),
		array(
			'id'    => 'mah_working_worldwide',
			'type'  => 'text',
			'title' => __( 'Working worldwide text', 'prowpsite-panel' ),
			'desc'  => __( 'Owner-entered. Empty hides this proof-strip item.', 'prowpsite-panel' ),
		),
		array(
			'id'    => 'mah_proof_projects_label',
			'type'  => 'text',
			'title' => __( 'Published projects label', 'prowpsite-panel' ),
			'desc'  => __( 'Shown beside the live published project count. Empty shows the number only. Count 0 hides the item.', 'prowpsite-panel' ),
		),
		array(
			'id'    => 'mah_proof_reviews_label',
			'type'  => 'text',
			'title' => __( 'Published reviews label', 'prowpsite-panel' ),
			'desc'  => __( 'Shown beside the live review count. Average rating is appended only when at least one review has a rating.', 'prowpsite-panel' ),
		),
		array(
			'id'    => 'mah_response_time',
			'type'  => 'text',
			'title' => __( 'Response time', 'prowpsite-panel' ),
		),
		array(
			'id'      => 'mah_availability',
			'type'    => 'text',
			'title'   => __( 'Availability pill', 'prowpsite-panel' ),
			'desc'    => __( 'Empty hides it.', 'prowpsite-panel' ),
		),

		// ---- Buttons ----------------------------------------------------
		array(
			'type'    => 'heading',
			'content' => __( 'Buttons', 'prowpsite-panel' ),
		),
		array(
			'id'    => 'mah_cta_label',
			'type'  => 'text',
			'title' => __( 'Primary button text', 'prowpsite-panel' ),
		),
		array(
			'id'         => 'mah_cta_action',
			'type'       => 'select',
			'title'      => __( 'Primary button goes to', 'prowpsite-panel' ),
			'options'    => array(
				'mailto' => __( 'Email address', 'prowpsite-panel' ),
				'tel'    => __( 'Phone number', 'prowpsite-panel' ),
				''       => __( 'No link', 'prowpsite-panel' ),
			),
			'default'   => 'mailto',
		),
		array(
			'id'    => 'mah_cta_target',
			'type'  => 'text',
			'title' => __( 'Or a full link', 'prowpsite-panel' ),
			'desc'  => __( 'Used when the option above is a URL.', 'prowpsite-panel' ),
		),
		array(
			'id'      => 'mah_cta_secondary',
			'type'    => 'text',
			'title'   => __( 'Secondary button text', 'prowpsite-panel' ),
			'default' => 'Explore selected work',
			'desc'    => __( 'Editable default. Anchors to the work section. Empty hides the button.', 'prowpsite-panel' ),
		),

		// ---- Numbers ----------------------------------------------------
		array(
			'type'    => 'heading',
			'content' => __( 'Numbers', 'prowpsite-panel' ),
		),
		array(
			'id'      => 'mah_stats',
			'type'    => 'group',
			'button_title'          => __( 'Add number', 'prowpsite-panel' ),
			'accordion_title_prefix' => '',
			'fields'   => array(
				array(
					'id'    => '0',
					'type'  => 'text',
					'title' => __( 'Value', 'prowpsite-panel' ),
				),
				array(
					'id'    => '1',
					'type'  => 'text',
					'title' => __( 'Explanation', 'prowpsite-panel' ),
				),
			),
		),

		// ---- How you work ----------------------------------------------
		array(
			'type'    => 'heading',
			'content' => __( 'How you work', 'prowpsite-panel' ),
		),
		array(
			'id'      => 'mah_process',
			'type'    => 'group',
			'button_title'          => __( 'Add step', 'prowpsite-panel' ),
			'accordion_title_prefix' => '',
			'fields'   => array(
				array(
					'id'    => '0',
					'type'  => 'text',
					'title' => __( 'Step', 'prowpsite-panel' ),
				),
				array(
					'id'    => '1',
					'type'  => 'textarea',
					'title' => __( 'What happens', 'prowpsite-panel' ),
				),
			),
		),

		// ---- Scrolling band ---------------------------------------------
		array(
			'type'    => 'heading',
			'content' => __( 'Scrolling band', 'prowpsite-panel' ),
		),
		array(
			'id'    => 'mah_marquee_phrases',
			'type'  => 'textarea',
			'title' => __( 'Phrases, one per line', 'prowpsite-panel' ),
		),

		// ---- Footer -----------------------------------------------------
		array(
			'type'    => 'heading',
			'content' => __( 'Footer', 'prowpsite-panel' ),
		),
		array(
			'id'    => 'mah_footer_headline',
			'type'  => 'text',
			'title' => __( 'Big footer line', 'prowpsite-panel' ),
		),
		array(
			'id'                     => 'mah_section_links',
			'type'                   => 'group',
			'button_title'           => __( 'Add link', 'prowpsite-panel' ),
			'accordion_title_prefix' => '',
			'title'                  => __( 'Section links', 'prowpsite-panel' ),
			'desc'                   => __( 'Header and footer navigation. Empty hides the menu.', 'prowpsite-panel' ),
			'default'                => get_option( 'mah_section_links', array() ),
			'fields'                 => array(
				array(
					'id'    => 'label',
					'type'  => 'text',
					'title' => __( 'Label', 'prowpsite-panel' ),
				),
				array(
					'id'    => 'href',
					'type'  => 'text',
					'title' => __( 'URL', 'prowpsite-panel' ),
				),
			),
		),

		// ---- Projects and reviews ---------------------------------------
		array(
			'type'    => 'heading',
			'content' => __( 'Projects and reviews', 'prowpsite-panel' ),
			'subheading' => __( 'These are post types. Edit each one in the sidebar for its image and full description.', 'prowpsite-panel' ),
		),
		array(
			'type'    => 'button',
			'title'   => __( 'Open Projects', 'prowpsite-panel' ),
			'link'    => admin_url( 'edit.php?post_type=mah_project' ),
			'target'  => '_self',
		),
		array(
			'type'    => 'button',
			'title'   => __( 'Open Reviews', 'prowpsite-panel' ),
			'link'    => admin_url( 'edit.php?post_type=mah_review' ),
			'target'  => '_self',
		),
		array(
			'type'    => 'button',
			'title'   => __( 'Open Services', 'prowpsite-panel' ),
			'link'    => admin_url( 'edit.php?post_type=mah_service' ),
			'target'  => '_self',
		),
	);
}

/**
 * Home layout fields: order, per-section copy, work/review counts.
 *
 * @return array
 */
function mah_panel_home_layout_fields() {
	$labels = function_exists( 'muhamedahmed_home_section_labels' )
		? muhamedahmed_home_section_labels()
		: array(
			'hero'     => __( 'Hero', 'prowpsite-panel' ),
			'marquee'  => __( 'Marquee', 'prowpsite-panel' ),
			'stats'    => __( 'Stats', 'prowpsite-panel' ),
			'services' => __( 'Services', 'prowpsite-panel' ),
			'work'     => __( 'Work', 'prowpsite-panel' ),
			'process'  => __( 'Process', 'prowpsite-panel' ),
			'about'    => __( 'About', 'prowpsite-panel' ),
			'reviews'  => __( 'Reviews', 'prowpsite-panel' ),
			'contact'  => __( 'Contact', 'prowpsite-panel' ),
		);

	$status = function_exists( 'muhamedahmed_home_renderer_status' )
		? muhamedahmed_home_renderer_status()
		: array(
			'active' => function_exists( 'muhamedahmed_render_home' ),
			'label'  => function_exists( 'muhamedahmed_render_home' ) ? __( 'active', 'prowpsite-panel' ) : __( 'inactive', 'prowpsite-panel' ),
			'why'    => __( 'Status is available after the home renderer file loads.', 'prowpsite-panel' ),
		);

	$fields = array(
		array(
			'type'       => 'heading',
			'content'    => __( 'Home layout', 'prowpsite-panel' ),
			'subheading' => __( 'Section order and copy for the front page. An empty heading is not shown.', 'prowpsite-panel' ),
		),
		array(
			'type'    => 'content',
			'content' => '<p><strong>' . esc_html( sprintf( __( 'Home renderer: %s', 'prowpsite-panel' ), $status['label'] ) ) . '</strong> ' . esc_html( $status['why'] ) . '</p>',
		),
		array(
			'id'             => 'mah_home_layout',
			'type'           => 'sorter',
			'title'          => __( 'Section order', 'prowpsite-panel' ),
			'enabled_title'  => __( 'On', 'prowpsite-panel' ),
			'disabled_title' => __( 'Off', 'prowpsite-panel' ),
			'default'        => array(
				'enabled'  => $labels,
				'disabled' => array(),
			),
		),
	);

	foreach ( $labels as $key => $label ) {
		$fields[] = array(
			'type'    => 'heading',
			'content' => $label,
		);
		$fields[] = array(
			'id'    => 'mah_home_' . $key . '_eyebrow',
			'type'  => 'text',
			'title' => __( 'Eyebrow', 'prowpsite-panel' ),
		);
		$heading_field = array(
			'id'    => 'mah_home_' . $key . '_heading',
			'type'  => 'text',
			'title' => __( 'Heading', 'prowpsite-panel' ),
		);

		if ( 'hero' === $key ) {
			$heading_field['title']   = __( 'Value statement (H1)', 'prowpsite-panel' );
			$heading_field['default'] = 'WordPress websites that look sharp, load fast, and convert.';
			$heading_field['desc']    = __( 'Editable default proposal. This is the H1. Empty hides the statement (name stays in the header).', 'prowpsite-panel' );
		}

		$fields[] = $heading_field;
		$fields[] = array(
			'id'    => 'mah_home_' . $key . '_intro',
			'type'  => 'textarea',
			'title' => __( 'Intro', 'prowpsite-panel' ),
		);

		if ( 'work' === $key ) {
			$choices = function_exists( 'muhamedahmed_project_choices' )
				? muhamedahmed_project_choices()
				: array( '0' => __( 'First published project', 'prowpsite-panel' ) );

			$fields[] = array(
				'id'      => 'mah_home_featured_project',
				'type'    => 'select',
				'title'   => __( 'Featured project', 'prowpsite-panel' ),
				'desc'    => __( 'Fallback only. Prefer the Featured checkbox on the project itself (Projects → edit). Used when no project is marked Featured.', 'prowpsite-panel' ),
				'options' => $choices,
				'default' => '0',
			);
			$fields[] = array(
				'id'      => 'mah_home_work_rail',
				'type'    => 'number',
				'title'   => __( 'Projects in the rail', 'prowpsite-panel' ),
				'default' => 6,
				'min'     => 1,
				'max'     => 20,
			);
			$fields[] = array(
				'id'      => 'mah_home_work_case_label',
				'type'    => 'text',
				'title'   => __( 'View case study label', 'prowpsite-panel' ),
				'default' => 'View case study',
				'desc'    => __( 'Editable default. The link is output only when the project has a URL or permalink.', 'prowpsite-panel' ),
			);
		}

		if ( 'hero' === $key ) {
			$fields[] = array(
				'id'      => 'mah_home_hero_chips',
				'type'    => 'switcher',
				'title'   => __( 'Hero proof chips', 'prowpsite-panel' ),
				'desc'    => __( 'Off by default. The numbers band already shows these figures.', 'prowpsite-panel' ),
				'default' => false,
			);
			$fields[] = array(
				'id'      => 'mah_home_hero_show_image',
				'type'    => 'switcher',
				'title'   => __( 'Show hero image', 'prowpsite-panel' ),
				'default' => true,
			);
			$fields[] = array(
				'id'      => 'mah_home_hero_image',
				'type'    => 'media',
				'title'   => __( 'Hero image', 'prowpsite-panel' ),
				'library' => 'image',
				'preview' => 'medium',
				'desc'    => __( 'Owner photo. Empty uses the Portrait field under About you.', 'prowpsite-panel' ),
			);
			$fields[] = array(
				'id'    => 'mah_home_hero_alt',
				'type'  => 'text',
				'title' => __( 'Hero image alt text', 'prowpsite-panel' ),
				'desc'  => __( 'Empty uses the site/owner name from identity.', 'prowpsite-panel' ),
			);
			$fields[] = array(
				'id'      => 'mah_home_hero_focal_x',
				'type'    => 'number',
				'title'   => __( 'Focal point X', 'prowpsite-panel' ),
				'desc'    => __( '0–100. Applied as object-position.', 'prowpsite-panel' ),
				'default' => 50,
				'min'     => 0,
				'max'     => 100,
			);
			$fields[] = array(
				'id'      => 'mah_home_hero_focal_y',
				'type'    => 'number',
				'title'   => __( 'Focal point Y', 'prowpsite-panel' ),
				'desc'    => __( '0–100. Default 35 (slightly above centre).', 'prowpsite-panel' ),
				'default' => 35,
				'min'     => 0,
				'max'     => 100,
			);
			$fields[] = array(
				'id'      => 'mah_home_hero_kicker_on',
				'type'    => 'switcher',
				'title'   => __( 'Show availability kicker', 'prowpsite-panel' ),
				'default' => true,
			);
			$fields[] = array(
				'id'    => 'mah_home_hero_kicker',
				'type'  => 'text',
				'title' => __( 'Kicker text', 'prowpsite-panel' ),
				'desc'  => __( 'Empty uses the Availability pill under Your details. Empty there hides the kicker.', 'prowpsite-panel' ),
			);
			$fields[] = array(
				'id'    => 'mah_home_hero_cta_label',
				'type'  => 'text',
				'title' => __( 'Primary CTA label', 'prowpsite-panel' ),
				'desc'  => __( 'Empty uses the primary button text under Buttons.', 'prowpsite-panel' ),
			);
			$fields[] = array(
				'id'    => 'mah_home_hero_cta_url',
				'type'  => 'text',
				'title' => __( 'Primary CTA URL', 'prowpsite-panel' ),
				'desc'  => __( 'Empty uses the existing contact setting (email / phone / link).', 'prowpsite-panel' ),
			);
			$fields[] = array(
				'id'      => 'mah_home_hero_visual',
				'type'    => 'select',
				'title'   => __( 'Hero visual', 'prowpsite-panel' ),
				'options' => array(
					'both'    => __( 'Both', 'prowpsite-panel' ),
					'photo'   => __( 'Photo', 'prowpsite-panel' ),
					'preview' => __( 'Project preview', 'prowpsite-panel' ),
				),
				'default' => 'both',
			);
		}

		if ( 'marquee' === $key ) {
			$fields[] = array(
				'id'      => 'mah_home_strip_style',
				'type'    => 'select',
				'title'   => __( 'Strip style', 'prowpsite-panel' ),
				'options' => array(
					'facts'   => __( 'Facts', 'prowpsite-panel' ),
					'marquee' => __( 'Marquee', 'prowpsite-panel' ),
					'off'     => __( 'Off', 'prowpsite-panel' ),
				),
				'default' => 'facts',
				'desc'    => __( 'Facts uses live project/review counts plus owner-entered years, location, and worldwide text. Empty values are hidden.', 'prowpsite-panel' ),
			);
		}

		if ( 'reviews' === $key ) {
			$fields[] = array(
				'id'      => 'mah_home_reviews_order',
				'type'    => 'select',
				'title'   => __( 'Order', 'prowpsite-panel' ),
				'options' => array(
					'priority' => __( 'Priority', 'prowpsite-panel' ),
					'random'   => __( 'Random', 'prowpsite-panel' ),
					'newest'   => __( 'Newest', 'prowpsite-panel' ),
				),
				'default' => 'priority',
				'desc'    => __( 'Random: the server still outputs Priority order so cached HTML stays valid; the cards shuffle in the browser once per page load.', 'prowpsite-panel' ),
			);
			$fields[] = array(
				'id'      => 'mah_home_reviews_count',
				'type'    => 'number',
				'title'   => __( 'How many', 'prowpsite-panel' ),
				'default' => 6,
				'min'     => 1,
				'max'     => 20,
			);
			$fields[] = array(
				'id'      => 'mah_home_reviews_home_only',
				'type'    => 'switcher',
				'title'   => __( 'Only reviews marked Show on home', 'prowpsite-panel' ),
				'default' => true,
			);
		}
	}

	$fields[] = array(
		'type'       => 'heading',
		'content'    => __( 'Motion', 'prowpsite-panel' ),
		'subheading' => __( 'Each effect has an on/off switch and intensity. All motion stops when the visitor prefers reduced motion.', 'prowpsite-panel' ),
	);

	$motion = array(
		'hero'     => __( 'Hero entrance, name reveal, portrait parallax', 'prowpsite-panel' ),
		'reveals'  => __( 'Section heading and card rise-in', 'prowpsite-panel' ),
		'stats'    => __( 'Stats count-up (off: no pin)', 'prowpsite-panel' ),
		'work'     => __( 'Work frame pan, rail hover, rail progress', 'prowpsite-panel' ),
		'process'  => __( 'Process line draw and step dots', 'prowpsite-panel' ),
		'marquee'  => __( 'Marquee speed from scroll', 'prowpsite-panel' ),
		'header'   => __( 'Header compact and colour after scroll', 'prowpsite-panel' ),
		'magnetic' => __( 'Magnetic primary CTA and card glow (fine pointer only)', 'prowpsite-panel' ),
	);

	foreach ( $motion as $key => $label ) {
		$fields[] = array(
			'id'      => 'mah_home_motion_' . $key,
			'type'    => 'switcher',
			'title'   => $label,
			'default' => ( 'stats' === $key ) ? false : true,
		);
		$fields[] = array(
			'id'      => 'mah_home_motion_' . $key . '_intensity',
			'type'    => 'select',
			'title'   => __( 'Intensity', 'prowpsite-panel' ),
			'options' => array(
				'subtle'   => __( 'Subtle', 'prowpsite-panel' ),
				'standard' => __( 'Standard', 'prowpsite-panel' ),
			),
			'default' => 'standard',
		);
	}

	$fields[] = array(
		'type'       => 'heading',
		'content'    => __( 'Navigation and theme', 'prowpsite-panel' ),
		'subheading' => __( 'Items whose section is off are hidden. Empty labels are hidden.', 'prowpsite-panel' ),
	);
	$fields[] = array(
		'id'      => 'mah_nav_work',
		'type'    => 'text',
		'title'   => __( 'Nav: Work', 'prowpsite-panel' ),
		'default' => 'Work',
	);
	$fields[] = array(
		'id'      => 'mah_nav_services',
		'type'    => 'text',
		'title'   => __( 'Nav: Services', 'prowpsite-panel' ),
		'default' => 'Services',
	);
	$fields[] = array(
		'id'      => 'mah_nav_process',
		'type'    => 'text',
		'title'   => __( 'Nav: Process', 'prowpsite-panel' ),
		'default' => 'Process',
	);
	$fields[] = array(
		'id'      => 'mah_nav_about',
		'type'    => 'text',
		'title'   => __( 'Nav: About', 'prowpsite-panel' ),
		'default' => 'About',
	);
	$fields[] = array(
		'id'      => 'mah_nav_reviews',
		'type'    => 'text',
		'title'   => __( 'Nav: Reviews', 'prowpsite-panel' ),
		'default' => 'Reviews',
	);
	$fields[] = array(
		'id'      => 'mah_home_theme_toggle',
		'type'    => 'switcher',
		'title'   => __( 'Show theme toggle', 'prowpsite-panel' ),
		'default' => true,
	);
	$fields[] = array(
		'id'      => 'mah_lang_switcher',
		'type'    => 'switcher',
		'title'   => __( 'Show language switcher', 'prowpsite-panel' ),
		'desc'    => __( 'Renders nothing when WPML is inactive or only one language exists.', 'prowpsite-panel' ),
		'default' => true,
	);
	$fields[] = array(
		'id'      => 'mah_lang_switcher_position',
		'type'    => 'select',
		'title'   => __( 'Language switcher position', 'prowpsite-panel' ),
		'options' => array(
			'header' => __( 'Header', 'prowpsite-panel' ),
			'footer' => __( 'Footer', 'prowpsite-panel' ),
			'both'   => __( 'Header and footer', 'prowpsite-panel' ),
		),
		'default' => 'header',
	);

	return $fields;
}

/**
 * The design fields, built from the controls plugin schema.
 *
 * Reading the schema rather than repeating the list means the panel can never
 * drift from the values the page actually uses. If the plugin is missing the
 * tab falls back to a short note instead of showing fields that would do
 * nothing.
 *
 * @return array
 */
function mah_panel_design_fields() {
	if ( ! function_exists( 'mah_controls_schema' ) ) {
		return array(
			array(
				'type'    => 'content',
				'content' => __( 'The Design Controls plugin is not active, so there is nothing to edit here yet.', 'prowpsite-panel' ),
			),
		);
	}

	$fields = array(
		array(
			'type'    => 'heading',
			'content' => __( 'Design', 'prowpsite-panel' ),
			'subheading' => __( 'These change every designed page. Each value is published as a CSS variable, so they take effect on save.', 'prowpsite-panel' ),
		),
	);

	foreach ( mah_controls_schema() as $group ) {
		$fields[] = array(
			'type'  => 'heading',
			'content' => $group['label'],
		);

		foreach ( $group['fields'] as $field ) {
			$default = mah_controls_value( $field, $field['key'] );

			$definition = array(
				'id'      => $field['key'],
				'type'    => 'color' === $field['type'] ? 'color' : ( 'number' === $field['type'] ? 'number' : 'text' ),
				'title'   => $field['label'],
				'default' => $default,
			);

			if ( 'number' === $field['type'] ) {
				$definition['min'] = $field['min'];
				$definition['max'] = $field['max'];
			}

			// The panel stores everything in one option, so the current value is
			// read back out to fill the field.
			$fields[] = $definition;
		}
	}

	return $fields;
}

/**
 * Copy the design values into the option keys the controls plugin reads.
 *
 * @return void
 */
function mah_panel_sync_design() {
	if ( ! function_exists( 'mah_controls_schema' ) ) {
		return;
	}

	$v = mah_panel_values();

	foreach ( mah_controls_schema() as $group ) {
		foreach ( $group['fields'] as $field ) {
			if ( ! isset( $v[ $field['key'] ] ) ) {
				continue;
			}

			update_option(
				$field['key'],
				mah_controls_sanitize( $v[ $field['key'] ] )
			);
		}
	}
}
add_action( 'csf_' . mah_panel_prefix() . '_saved', 'mah_panel_sync_design', 5 );

/**
 * Register the section on the existing panel.
 *
 * Hooked to plugins_loaded rather than csf_loaded, because this file is required
 * before Codestar exists. If the framework is somehow absent the section is
 * skipped and the rest of the plugin still loads.
 *
 * @return void
 */
function mah_panel_site_section() {
	if ( ! class_exists( 'CSF' ) ) {
		return;
	}

	CSF::createSection(
		mah_panel_prefix(),
		array(
			'id'     => 'mah_site_content',
			'title'  => __( 'Site Content', 'prowpsite-panel' ),
			'icon'   => 'fas fa-pen-nib',
			'fields' => array_merge( mah_panel_site_fields(), mah_panel_home_layout_fields() ),
		)
	);

	CSF::createSection(
		mah_panel_prefix(),
		array(
			'id'     => 'mah_design',
			'title'  => __( 'Design', 'prowpsite-panel' ),
			'icon'   => 'fas fa-palette',
			'fields' => mah_panel_design_fields(),
		)
	);
}
/*
 * CSF::setup() runs on after_setup_theme and freezes sections. This file
 * loads after Codestar, so the sections must be registered immediately.
 */
if ( class_exists( 'CSF' ) ) {
	mah_panel_site_section();
} else {
	add_action( 'after_setup_theme', 'mah_panel_site_section', 0 );
}

/**
 * Attachment id from a Codestar media field (array or integer).
 *
 * @param mixed $raw Stored field value.
 * @return int
 */
function mah_panel_attachment_id( $raw ) {
	if ( is_array( $raw ) ) {
		return isset( $raw['id'] ) ? absint( $raw['id'] ) : 0;
	}

	return absint( $raw );
}

/**
 * Copy panel values into the option keys the blocks read.
 *
 * Runs after the framework saves, so the page sees the new values immediately.
 * Only keys the panel actually owns are written, so nothing else is disturbed.
 *
 * @return void
 */
function mah_panel_sync_to_blocks() {
	$v = mah_panel_values();

	// ---- Identity ------------------------------------------------------
	$identity_map = array(
		'full_name'     => 'mah_full_name',
		'role'          => 'mah_role',
		'tagline'       => 'mah_tagline',
		'bio'           => 'mah_bio',
		'email'         => 'mah_email',
		'phone'         => 'mah_phone',
		'whatsapp'      => 'mah_whatsapp',
		'location'      => 'mah_location',
		'response_time' => 'mah_response_time',
		'availability'  => 'mah_availability',
		'cta_label'     => 'mah_cta_label',
		'cta_action'    => 'mah_cta_action',
		'cta_target'    => 'mah_cta_target',
	);

	$identity = get_option( 'mah_identity', array() );
	$identity = is_array( $identity ) ? $identity : array();

	foreach ( $identity_map as $key => $field ) {
		if ( isset( $v[ $field ] ) ) {
			$identity[ $key ] = sanitize_text_field( $v[ $field ] );
		}
	}

	// An empty availability line hides the pill.
	$identity['available'] = '' === trim( (string) ( $identity['availability'] ?? '' ) ) ? 0 : 1;

	update_option( 'mah_identity', $identity );

	// ---- Lists ---------------------------------------------------------
	foreach ( array( 'mah_stats', 'mah_process' ) as $option ) {
		if ( ! isset( $v[ $option ] ) || ! is_array( $v[ $option ] ) ) {
			continue;
		}

		$rows = array();

		foreach ( $v[ $option ] as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}

			$row = array_map( 'sanitize_text_field', $row );

			// Drop a row the editor left half empty.
			if ( '' === trim( implode( '', $row ) ) ) {
				continue;
			}

			$rows[] = $row;
		}

		update_option( $option, $rows );
	}

	// ---- Marquee --------------------------------------------------------
	if ( isset( $v['mah_marquee_phrases'] ) ) {
		update_option( 'mah_marquee_phrases', mah_panel_lines( $v['mah_marquee_phrases'] ) );
	}

	// ---- About section --------------------------------------------------
	if ( isset( $v['mah_about_points'] ) ) {
		update_option( 'mah_about_points', mah_panel_lines( $v['mah_about_points'] ) );
	}

	// ---- Single values --------------------------------------------------
	$direct = array(
		'mah_footer_headline'          => 'sanitize_text_field',
		'mah_about_eyebrow'            => 'sanitize_text_field',
		'mah_about_heading'            => 'sanitize_text_field',
		'mah_about_body'               => 'sanitize_textarea_field',
		'mah_years_experience'         => 'sanitize_text_field',
		'mah_years_experience_label'   => 'sanitize_text_field',
		'mah_working_worldwide'        => 'sanitize_text_field',
		'mah_proof_projects_label'     => 'sanitize_text_field',
		'mah_proof_reviews_label'      => 'sanitize_text_field',
		'mah_home_hero_kicker'         => 'sanitize_text_field',
		'mah_home_hero_cta_label'      => 'sanitize_text_field',
		'mah_home_hero_cta_url'        => 'esc_url_raw',
		'mah_home_work_case_label'     => 'sanitize_text_field',
		'mah_nav_work'                 => 'sanitize_text_field',
		'mah_nav_services'             => 'sanitize_text_field',
		'mah_nav_process'              => 'sanitize_text_field',
		'mah_nav_about'                => 'sanitize_text_field',
		'mah_nav_reviews'              => 'sanitize_text_field',
	);

	foreach ( $direct as $field => $sanitiser ) {
		if ( isset( $v[ $field ] ) ) {
			update_option( $field, call_user_func( $sanitiser, (string) $v[ $field ] ) );
		}
	}

	if ( isset( $v['mah_cta_secondary'] ) ) {
		update_option( 'mah_cta_secondary', sanitize_text_field( $v['mah_cta_secondary'] ) );
	}

	if ( isset( $v['mah_portrait_id'] ) ) {
		update_option( 'mah_portrait_id', mah_panel_attachment_id( $v['mah_portrait_id'] ) );
	}

	if ( isset( $v['mah_logo_id'] ) ) {
		update_option( 'mah_logo_id', mah_panel_attachment_id( $v['mah_logo_id'] ) );
	}

	if ( isset( $v['mah_section_links'] ) && is_array( $v['mah_section_links'] ) ) {
		$links = array();

		foreach ( $v['mah_section_links'] as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}

			$label = isset( $row['label'] ) ? sanitize_text_field( $row['label'] ) : '';
			$href  = isset( $row['href'] ) ? esc_url_raw( $row['href'] ) : '';

			if ( '' === $label ) {
				continue;
			}

			$links[] = array(
				'label' => $label,
				'href'  => $href,
			);
		}

		update_option( 'mah_section_links', $links );
	}

	if ( isset( $v['mah_home_layout'] ) ) {
		$layout = function_exists( 'muhamedahmed_sanitize_home_layout' )
			? muhamedahmed_sanitize_home_layout( $v['mah_home_layout'] )
			: $v['mah_home_layout'];
		update_option( 'mah_home_layout', $layout );
	}

	$sections = array( 'hero', 'marquee', 'stats', 'services', 'work', 'process', 'about', 'reviews', 'contact' );

	foreach ( $sections as $section ) {
		foreach ( array( 'eyebrow', 'heading' ) as $piece ) {
			$field = 'mah_home_' . $section . '_' . $piece;

			if ( isset( $v[ $field ] ) ) {
				update_option( $field, sanitize_text_field( (string) $v[ $field ] ) );
			}
		}

		$intro = 'mah_home_' . $section . '_intro';

		if ( isset( $v[ $intro ] ) ) {
			update_option( $intro, sanitize_textarea_field( (string) $v[ $intro ] ) );
		}
	}

	if ( isset( $v['mah_home_featured_project'] ) ) {
		update_option( 'mah_home_featured_project', absint( $v['mah_home_featured_project'] ) );
	}

	if ( isset( $v['mah_home_work_rail'] ) ) {
		update_option( 'mah_home_work_rail', max( 1, min( 20, absint( $v['mah_home_work_rail'] ) ) ) );
	}

	if ( isset( $v['mah_home_reviews_count'] ) ) {
		update_option( 'mah_home_reviews_count', max( 1, min( 20, absint( $v['mah_home_reviews_count'] ) ) ) );
	}

	if ( isset( $v['mah_home_reviews_order'] ) ) {
		$order = function_exists( 'muhamedahmed_reviews_normalize_order' )
			? muhamedahmed_reviews_normalize_order( $v['mah_home_reviews_order'] )
			: 'priority';
		update_option( 'mah_home_reviews_order', $order );
	}

	if ( isset( $v['mah_home_reviews_home_only'] ) ) {
		update_option( 'mah_home_reviews_home_only', $v['mah_home_reviews_home_only'] ? 1 : 0 );
	}

	if ( isset( $v['mah_home_hero_chips'] ) ) {
		update_option( 'mah_home_hero_chips', $v['mah_home_hero_chips'] ? 1 : 0 );
	}

	if ( isset( $v['mah_home_hero_show_image'] ) ) {
		update_option( 'mah_home_hero_show_image', $v['mah_home_hero_show_image'] ? 1 : 0 );
	}

	if ( isset( $v['mah_home_hero_image'] ) ) {
		update_option( 'mah_home_hero_image', mah_panel_attachment_id( $v['mah_home_hero_image'] ) );
	}

	if ( isset( $v['mah_home_hero_alt'] ) ) {
		update_option( 'mah_home_hero_alt', sanitize_text_field( (string) $v['mah_home_hero_alt'] ) );
	}

	if ( isset( $v['mah_home_hero_focal_x'] ) ) {
		$focal_x = function_exists( 'muhamedahmed_focal_percent' )
			? muhamedahmed_focal_percent( $v['mah_home_hero_focal_x'], 50 )
			: max( 0, min( 100, absint( $v['mah_home_hero_focal_x'] ) ) );
		update_option( 'mah_home_hero_focal_x', $focal_x );
	}

	if ( isset( $v['mah_home_hero_focal_y'] ) ) {
		$focal_y = function_exists( 'muhamedahmed_focal_percent' )
			? muhamedahmed_focal_percent( $v['mah_home_hero_focal_y'], 35 )
			: max( 0, min( 100, absint( $v['mah_home_hero_focal_y'] ) ) );
		update_option( 'mah_home_hero_focal_y', $focal_y );
	}

	if ( isset( $v['mah_home_hero_kicker_on'] ) ) {
		update_option( 'mah_home_hero_kicker_on', $v['mah_home_hero_kicker_on'] ? 1 : 0 );
	}

	if ( isset( $v['mah_home_hero_visual'] ) ) {
		$visual = sanitize_key( (string) $v['mah_home_hero_visual'] );
		update_option( 'mah_home_hero_visual', in_array( $visual, array( 'photo', 'preview', 'both' ), true ) ? $visual : 'both' );
	}

	if ( isset( $v['mah_home_strip_style'] ) ) {
		$strip = sanitize_key( (string) $v['mah_home_strip_style'] );
		update_option( 'mah_home_strip_style', in_array( $strip, array( 'facts', 'marquee', 'off' ), true ) ? $strip : 'facts' );
	}

	if ( isset( $v['mah_home_theme_toggle'] ) ) {
		update_option( 'mah_home_theme_toggle', $v['mah_home_theme_toggle'] ? 1 : 0 );
	}

	if ( isset( $v['mah_lang_switcher'] ) ) {
		update_option( 'mah_lang_switcher', $v['mah_lang_switcher'] ? 1 : 0 );
	}

	if ( isset( $v['mah_lang_switcher_position'] ) ) {
		$lang_pos = sanitize_key( (string) $v['mah_lang_switcher_position'] );
		update_option(
			'mah_lang_switcher_position',
			in_array( $lang_pos, array( 'header', 'footer', 'both' ), true ) ? $lang_pos : 'header'
		);
	}

	if ( function_exists( 'muhamedahmed_i18n_register_all' ) ) {
		$GLOBALS['muhamedahmed_i18n_registry'] = array();
		muhamedahmed_i18n_register_all( true );
	}

	$motion_keys = function_exists( 'muhamedahmed_home_motion_keys' )
		? muhamedahmed_home_motion_keys()
		: array( 'hero', 'reveals', 'stats', 'work', 'process', 'marquee', 'header', 'magnetic' );

	foreach ( $motion_keys as $motion_key ) {
		$switch = 'mah_home_motion_' . $motion_key;
		$level  = 'mah_home_motion_' . $motion_key . '_intensity';

		if ( isset( $v[ $switch ] ) ) {
			update_option( $switch, $v[ $switch ] ? 1 : 0 );
		}

		if ( isset( $v[ $level ] ) ) {
			$intensity = sanitize_key( (string) $v[ $level ] );
			update_option( $level, in_array( $intensity, array( 'subtle', 'standard' ), true ) ? $intensity : 'standard' );
		}
	}
}
add_action( 'csf_' . mah_panel_prefix() . '_saved', 'mah_panel_sync_to_blocks' );

/**
 * Seed the panel from the current option values the first time it is opened, so
 * the fields are not blank when the page already has content.
 *
 * Only runs while the panel option is still absent. Nothing is overwritten.
 *
 * @return void
 */
function mah_panel_seed_defaults() {
	if ( get_option( 'mah_panel_seeded' ) ) {
		return;
	}

	$identity = get_option( 'mah_identity', array() );
	$identity = is_array( $identity ) ? $identity : array();

	$seed = array(
		'mah_full_name'       => $identity['full_name'] ?? '',
		'mah_role'            => $identity['role'] ?? '',
		'mah_tagline'         => $identity['tagline'] ?? '',
		'mah_bio'             => $identity['bio'] ?? '',
		'mah_email'           => $identity['email'] ?? '',
		'mah_phone'           => $identity['phone'] ?? '',
		'mah_whatsapp'        => $identity['whatsapp'] ?? '',
		'mah_location'        => $identity['location'] ?? '',
		'mah_response_time'   => $identity['response_time'] ?? '',
		'mah_availability'    => $identity['availability'] ?? '',
		'mah_cta_label'       => $identity['cta_label'] ?? '',
		'mah_cta_action'      => $identity['cta_action'] ?? 'mailto',
		'mah_cta_target'      => $identity['cta_target'] ?? '',
	);

	$stats = get_option( 'mah_stats', array() );

	if ( is_array( $stats ) ) {
		$seed['mah_stats'] = $stats;
	}

	$process = get_option( 'mah_process', array() );

	if ( is_array( $process ) ) {
		$seed['mah_process'] = $process;
	}

	$phrases = get_option( 'mah_marquee_phrases', array() );

	if ( is_array( $phrases ) ) {
		$seed['mah_marquee_phrases'] = implode( "\n", $phrases );
	}

	$about_body = get_option( 'mah_about_body', '' );

	if ( is_scalar( $about_body ) && '' !== trim( (string) $about_body ) ) {
		$seed['mah_about_body'] = (string) $about_body;
	}

	$about_points = get_option( 'mah_about_points', array() );

	if ( is_array( $about_points ) && $about_points ) {
		$seed['mah_about_points'] = implode( "\n", $about_points );
	}

	foreach ( array( 'mah_about_eyebrow', 'mah_about_heading', 'mah_footer_headline', 'mah_cta_secondary' ) as $copy_key ) {
		$copy_value = get_option( $copy_key, '' );

		if ( is_scalar( $copy_value ) && '' !== (string) $copy_value ) {
			$seed[ $copy_key ] = (string) $copy_value;
		}
	}

	$portrait = (int) get_option( 'mah_portrait_id', 0 );

	if ( $portrait ) {
		$seed['mah_portrait_id'] = $portrait;
	}

	$links = get_option( 'mah_section_links', array() );

	if ( is_array( $links ) && $links ) {
		$seed['mah_section_links'] = $links;
	}

	$layout = get_option( 'mah_home_layout', array() );

	if ( is_array( $layout ) && $layout ) {
		$seed['mah_home_layout'] = $layout;
	}

	$sections = array( 'hero', 'marquee', 'stats', 'services', 'work', 'process', 'about', 'reviews', 'contact' );

	foreach ( $sections as $section ) {
		foreach ( array( 'eyebrow', 'heading', 'intro' ) as $piece ) {
			$field = 'mah_home_' . $section . '_' . $piece;
			$value = get_option( $field, '' );

			if ( is_scalar( $value ) && '' !== (string) $value ) {
				$seed[ $field ] = (string) $value;
			}
		}
	}

	$featured = (int) get_option( 'mah_home_featured_project', 0 );

	if ( $featured ) {
		$seed['mah_home_featured_project'] = $featured;
	}

	$rail = get_option( 'mah_home_work_rail', '' );

	if ( '' !== $rail && null !== $rail ) {
		$seed['mah_home_work_rail'] = absint( $rail );
	}

	$reviews = get_option( 'mah_home_reviews_count', '' );

	if ( '' !== $reviews && null !== $reviews ) {
		$seed['mah_home_reviews_count'] = absint( $reviews );
	}

	$reviews_order = get_option( 'mah_home_reviews_order', '' );

	if ( '' !== $reviews_order && null !== $reviews_order ) {
		$seed['mah_home_reviews_order'] = function_exists( 'muhamedahmed_reviews_normalize_order' )
			? muhamedahmed_reviews_normalize_order( $reviews_order )
			: 'priority';
	}

	$home_only = get_option( 'mah_home_reviews_home_only', '' );

	if ( '' !== $home_only && null !== $home_only ) {
		$seed['mah_home_reviews_home_only'] = ( '0' === (string) $home_only ) ? false : true;
	}

	$seed['mah_home_hero_chips']      = absint( get_option( 'mah_home_hero_chips', 0 ) );
	$seed['mah_home_hero_show_image'] = ( '0' === (string) get_option( 'mah_home_hero_show_image', '1' ) ) ? false : true;

	$hero_image = absint( get_option( 'mah_home_hero_image', 0 ) );

	if ( $hero_image ) {
		$seed['mah_home_hero_image'] = $hero_image;
	}

	$hero_alt = get_option( 'mah_home_hero_alt', '' );

	if ( is_scalar( $hero_alt ) && '' !== (string) $hero_alt ) {
		$seed['mah_home_hero_alt'] = (string) $hero_alt;
	}

	$seed['mah_home_hero_focal_x'] = function_exists( 'muhamedahmed_focal_percent' )
		? muhamedahmed_focal_percent( get_option( 'mah_home_hero_focal_x', 50 ), 50 )
		: 50;
	$seed['mah_home_hero_focal_y'] = function_exists( 'muhamedahmed_focal_percent' )
		? muhamedahmed_focal_percent( get_option( 'mah_home_hero_focal_y', 35 ), 35 )
		: 35;

	$text_seed = array(
		'mah_years_experience',
		'mah_years_experience_label',
		'mah_working_worldwide',
		'mah_proof_projects_label',
		'mah_proof_reviews_label',
		'mah_home_hero_kicker',
		'mah_home_hero_cta_label',
		'mah_home_hero_cta_url',
		'mah_home_work_case_label',
		'mah_nav_work',
		'mah_nav_services',
		'mah_nav_process',
		'mah_nav_about',
		'mah_nav_reviews',
	);

	foreach ( $text_seed as $text_key ) {
		$text_value = get_option( $text_key, '' );

		if ( is_scalar( $text_value ) && '' !== (string) $text_value ) {
			$seed[ $text_key ] = (string) $text_value;
		}
	}

	$seed['mah_home_hero_kicker_on'] = function_exists( 'muhamedahmed_option_is_on' )
		? muhamedahmed_option_is_on( 'mah_home_hero_kicker_on', true )
		: true;
	$seed['mah_home_theme_toggle'] = function_exists( 'muhamedahmed_option_is_on' )
		? muhamedahmed_option_is_on( 'mah_home_theme_toggle', true )
		: true;

	$visual_seed = sanitize_key( (string) get_option( 'mah_home_hero_visual', 'both' ) );
	$seed['mah_home_hero_visual'] = in_array( $visual_seed, array( 'photo', 'preview', 'both' ), true ) ? $visual_seed : 'both';

	$strip_seed = sanitize_key( (string) get_option( 'mah_home_strip_style', 'facts' ) );
	$seed['mah_home_strip_style'] = in_array( $strip_seed, array( 'facts', 'marquee', 'off' ), true ) ? $strip_seed : 'facts';

	$motion_keys = function_exists( 'muhamedahmed_home_motion_keys' )
		? muhamedahmed_home_motion_keys()
		: array( 'hero', 'reveals', 'stats', 'work', 'process', 'marquee', 'header', 'magnetic' );

	foreach ( $motion_keys as $motion_key ) {
		$switch = 'mah_home_motion_' . $motion_key;
		$level  = 'mah_home_motion_' . $motion_key . '_intensity';
		$on     = get_option( $switch, '1' );
		$seed[ $switch ] = ( '0' === (string) $on ) ? false : true;
		$intensity       = get_option( $level, 'standard' );
		$seed[ $level ]  = in_array( $intensity, array( 'subtle', 'standard' ), true ) ? $intensity : 'standard';
	}

	$stored = get_option( mah_panel_prefix(), array() );
	$stored = is_array( $stored ) ? $stored : array();

	update_option( mah_panel_prefix(), array_merge( $stored, $seed ) );
	update_option( 'mah_panel_seeded', 1 );
}
add_action( 'admin_init', 'mah_panel_seed_defaults' );
