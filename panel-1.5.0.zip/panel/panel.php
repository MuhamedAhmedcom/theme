<?php
/**
 * Plugin Name: ProWPSite Panel Framework
 * Plugin URI: https://prowpsite.com/
 * Description: Advanced WordPress Control Panel with Custom Post Types and Fields Management
 * Version: 1.5.0
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * Author: Muhamed Ahmed
 * Author URI: https://prowpsite.com/
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: prowpsite-panel
 * Domain Path: /languages
 *
 * @package ProWPSite
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
if (!defined('PROWP_VERSION')) {
    define('PROWP_VERSION', '1.5.0');
}

if (!defined('PROWP_FILE')) {
    define('PROWP_FILE', __FILE__);
}

if (!defined('PROWP_PATH')) {
    define('PROWP_PATH', plugin_dir_path(__FILE__));
}

if (!defined('PROWP_URL')) {
    define('PROWP_URL', plugin_dir_url(__FILE__));
}

if (!defined('PROWP_BASENAME')) {
    define('PROWP_BASENAME', plugin_basename(__FILE__));
}



if (!defined('PROWP_PATH')) {
    define('PROWP_PATH', plugin_dir_path(__FILE__));
}

if (!defined('PROWP_URL')) {
    define('PROWP_URL', plugin_dir_url(__FILE__));
}

// Load required files
require_once PROWP_PATH . 'classes/setup.class.php';

if ( class_exists( 'CSF_Fields' ) && is_readable( PROWP_PATH . 'fields/button/button.php' ) ) {
	require_once PROWP_PATH . 'fields/button/button.php';
}

$prowp_admin_options = is_readable( PROWP_PATH . 'options/admin-options.php' )
	? PROWP_PATH . 'options/admin-options.php'
	: PROWP_PATH . 'admin-options.php';
$prowp_site_section  = is_readable( PROWP_PATH . 'options/site-section.php' )
	? PROWP_PATH . 'options/site-section.php'
	: PROWP_PATH . 'site-section.php';

require_once $prowp_admin_options;

if ( is_readable( PROWP_PATH . 'inc/i18n.php' ) ) {
	require_once PROWP_PATH . 'inc/i18n.php';
}

/*
 * Adds the Site Content tab, which writes to the option keys the homepage
 * blocks read. Kept in its own file so the panel can be reverted without
 * touching admin-options.php.
 */
require_once $prowp_site_section;

require_once PROWP_PATH . 'inc/modules.php';
register_activation_hook( PROWP_FILE, 'prowp_panel_activate' );

add_action(
	'init',
	static function () {
		load_plugin_textdomain( 'prowpsite-panel', false, dirname( PROWP_BASENAME ) . '/languages' );
	},
	0
);
