<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access directly.
/**
 *
 * Field: svg_select
 *
 * Thin variant of image_select that renders inline SVG markup
 * instead of <img src="">. Inherits the full image_select pipeline
 * (constructor, save, form naming, JS init) so 'type' => 'svg_select'
 * uses the same save path as image_select.
 *
 * @since 1.0.0
 * @version 1.1.0
 *
 */
if ( ! class_exists( 'CSF_Field_svg_select' ) ) {
  class CSF_Field_svg_select extends CSF_Field_image_select {

    public function __construct( $field, $value = '', $unique = '', $where = '', $parent = '' ) {
      parent::__construct( $field, $value, $unique, $where, $parent );
    }

    public function render() {

      $args = wp_parse_args( $this->field, array(
        'multiple' => false,
        'inline'   => false,
        'options'  => array(),
      ) );

      $inline = ( $args['inline'] ) ? ' csf--inline-list' : '';

      $value = ( is_array( $this->value ) ) ? $this->value : array_filter( (array) $this->value );

      echo $this->field_before();

      if ( ! empty( $args['options'] ) ) {

        echo '<div class="csf-siblings csf--image-group'. esc_attr( $inline ) .'" data-multiple="'. esc_attr( $args['multiple'] ) .'">';

        $num = 1;

        foreach ( $args['options'] as $key => $option ) {

          $type    = ( $args['multiple'] ) ? 'checkbox' : 'radio';
          $extra   = ( $args['multiple'] ) ? '[]' : '';
          $active  = ( in_array( $key, $value ) ) ? ' csf--active' : '';
          $checked = ( in_array( $key, $value ) ) ? ' checked' : '';
          $labels  = ( ! empty( $this->field['option_labels'] ) && is_array( $this->field['option_labels'] ) ) ? $this->field['option_labels'] : array();
          $aria    = isset( $labels[ $key ] ) ? (string) $labels[ $key ] : ucwords( str_replace( array( '-', '_' ), ' ', (string) $key ) );

          echo '<div class="csf--sibling csf--image'. esc_attr( $active ) .'" role="presentation">';
            echo '<figure>';
              // Detect raw SVG markup vs URL; emit accordingly so this class
              // accepts both shapes without breaking image_select's contract.
              if ( is_string( $option ) && strpos( ltrim( $option ), '<' ) === 0 ) {
                echo $option; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- trusted SVG from prowp_svg_* helpers.
              } else {
                echo '<img src="'. esc_url( $option ) .'" alt="'. esc_attr( $aria ) .'" />';
              }
              $num++;
              echo '<input type="'. esc_attr( $type ) .'" name="'. esc_attr( $this->field_name( $extra ) ) .'" value="'. esc_attr( $key ) .'" aria-label="'. esc_attr( $aria ) .'"'. $this->field_attributes() . esc_attr( $checked ) .'/>';
              if ( '' !== $aria ) {
                echo '<figcaption class="csf--svg-caption">'. esc_html( $aria ) .'</figcaption>';
              }
            echo '</figure>';
          echo '</div>';

        }

        echo '</div>';

      }

      echo $this->field_after();

    }

    public function output() {

      $output    = '';
      $important = ( ! empty( $this->field['output_important'] ) ) ? '!important' : '';
      $elements  = ( is_array( $this->field['output'] ) ) ? join( ',', $this->field['output'] ) : $this->field['output'];

      if ( ! empty( $elements ) && isset( $this->value ) && $this->value !== '' ) {
        $output = $elements .'{'. $this->value . $important .';}';
      }

      $this->parent->output_css .= $output;

      return $output;

    }

  }
}
