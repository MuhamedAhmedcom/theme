<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access directly.
/**
 *
 * Field: button
 *
 * Admin link control used by Site Content. Codestar 2.2.9 has no stock
 * button type, so this field is local to the panel.
 *
 * @since 1.2.1
 * @version 1.2.1
 *
 */
if ( ! class_exists( 'CSF_Field_button' ) ) {
  class CSF_Field_button extends CSF_Fields {

    public function __construct( $field, $value = '', $unique = '', $where = '', $parent = '' ) {
      parent::__construct( $field, $value, $unique, $where, $parent );
    }

    public function render() {

      $label  = '';
      if ( ! empty( $this->field['content'] ) ) {
        $label = $this->field['content'];
      } elseif ( ! empty( $this->field['title'] ) ) {
        $label = $this->field['title'];
      }

      $url    = ( ! empty( $this->field['link'] ) ) ? $this->field['link'] : '';
      $target = ( ! empty( $this->field['target'] ) ) ? $this->field['target'] : '_self';

      echo $this->field_before();

      if ( $url && $label ) {
        echo '<a class="button button-secondary" href="'. esc_url( $url ) .'" target="'. esc_attr( $target ) .'">'. esc_html( $label ) .'</a>';
      }

      echo $this->field_after();

    }

  }
}
