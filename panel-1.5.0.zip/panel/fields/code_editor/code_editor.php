<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access directly.
/**
 *
 * Field: code_editor (ProwpCommerce override)
 *
 * Replaces the stock Codestar Framework CodeMirror field with
 * WordPress core's own `wp.codeEditor` (CodeMirror + bundled modes
 * + linters). This avoids the upstream CDN URLs that get rewritten
 * to an insecure `http://` host on HTTPS pages, and avoids a 404 on
 * the missing `addon/mode/loadmode.min.js`.
 *
 * @since 1.0.0
 * @version 1.0.0
 *
 */
if ( ! class_exists( 'CSF_Field_code_editor' ) ) {
  class CSF_Field_code_editor extends CSF_Fields {

    public $version = '1.0.0';
    public $cdn_url = '';

    public function __construct( $field, $value = '', $unique = '', $where = '', $parent = '' ) {
      parent::__construct( $field, $value, $unique, $where, $parent );
    }

    public function render() {

      $default_settings = array(
        'mode'        => 'htmlmixed',
        'lineNumbers' => true,
        'lineWrapping' => true,
        'tabSize'     => 2,
        'indentUnit'  => 2,
      );

      $settings = ( ! empty( $this->field['settings'] ) ) ? $this->field['settings'] : array();
      $settings = wp_parse_args( $settings, $default_settings );

      // Set data-editor to empty to prevent CSF's main.js from running its CodeMirror init.
      // Our wp.codeEditor will attach later.
      $editor_id = 'prowp-ce-' . wp_unique_id();

      echo $this->field_before();
      echo '<textarea id="'. esc_attr( $editor_id ) .'" class="prowp-wp-code-editor" name="'. esc_attr( $this->field_name() ) .'"'. $this->field_attributes() .' data-editor="" data-codemirror="'. esc_attr( json_encode( $settings ) ) .'">'. $this->value .'</textarea>';
      echo $this->field_after();

    }

    public function enqueue() {

      $page = ( ! empty( $_GET[ 'page' ] ) ) ? sanitize_text_field( wp_unslash( $_GET[ 'page' ] ) ) : '';

      // Do not load code editor in revslider page.
      if ( in_array( $page, array( 'revslider' ) ) ) { return; }

      // Use WordPress core's code editor — already localized and bundled
      // with all modes (htmlmixed, css, javascript, php, xml, etc.).
      wp_enqueue_code_editor( array( 'type' => 'text/html' ) );
      wp_enqueue_style( 'code-editor' );

      // Inline bootstrap: turn every .prowp-wp-code-editor into wp.codeEditor.
      wp_add_inline_script( 'code-editor', $this->bootstrap_js() );

    }

    private function bootstrap_js() {
      return <<<JS
(function($){
  function prowpInitCodeEditors(){
    $('.prowp-wp-code-editor:not(.prowp-inited)').each(function(){
      var \$t = $(this);
      var cm = \$t.data('codemirror') || {};
      // Add mode from settings if present.
      var codeMirrorOptions = cm.mode ? { mode: cm.mode } : {};
      Object.keys(cm).forEach(function(k){
        if (k !== 'mode') codeMirrorOptions[k] = cm[k];
      });
      try {
        if (typeof wp.codeEditor !== 'undefined' && wp.codeEditor.initialize) {
          var instance = wp.codeEditor.initialize(this, { codemirror: codeMirrorOptions });
          // Save CodeMirror instance on textarea for external access.
          \$t.data('prowp-codeMirror-instance', instance.codemirror);
          \$t.addClass('prowp-inited');
        }
      } catch (e) { console.error('ProwpCommerce code_editor init failed', e); }
    });
  }

  // Init on page load and after CSF renders new fields.
  $(function(){ prowpInitCodeEditors(); });
  $(document).on('csf_field_added csf_tab_activated', function(){ prowpInitCodeEditors(); });

})(jQuery);
JS;
    }

  }
}