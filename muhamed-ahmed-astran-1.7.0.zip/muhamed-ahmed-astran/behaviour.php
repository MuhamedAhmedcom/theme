<?php
/**
 * Front-end behaviour for the designed pages.
 *
 * Deliberately tiny. Progressive enhancement only: the page is fully usable
 * with JavaScript disabled. The mobile menu is a panel toggled by
 * aria-expanded, and the header scrim is a single scroll listener.
 *
 * @package MuhamedAhmed_Astran
 */

defined( 'ABSPATH' ) || exit;

/**
 * Is the current request a designed page?
 *
 * Checked on early hooks, before wp fires, so both the enqueue and the title
 * suppression can rely on it.
 *
 * @return bool
 */
function mah_is_designed_request() {
	if ( ! is_page() ) {
		return false;
	}

	$post = get_post();

	return $post && has_block( 'muhamedahmed/section', $post );
}

/**
 * Enqueue the chrome script and stylesheet on designed pages only.
 *
 * @return void
 */
function mah_enqueue_chrome_script() {
	$designed = function_exists( 'muhamedahmed_astran_is_designed_page' )
		? muhamedahmed_astran_is_designed_page()
		: mah_is_designed_request();

	if ( ! $designed ) {
		return;
	}

	wp_enqueue_script(
		'mah-chrome',
		MUHAMEDAHMED_ASTRAN_URI . '/chrome.js',
		array(),
		MUHAMEDAHMED_ASTRAN_VERSION,
		true
	);

	wp_localize_script(
		'mah-chrome',
		'mahChromeI18n',
		array(
			'theme'      => array(
				'system' => __( 'System', 'muhamed-ahmed-astran' ),
				'light'  => __( 'Light', 'muhamed-ahmed-astran' ),
				'dark'   => __( 'Dark', 'muhamed-ahmed-astran' ),
			),
			/* translators: %s: current theme mode (System, Light, or Dark). */
			'themeAria'  => __( 'Colour theme: %s', 'muhamed-ahmed-astran' ),
			'openMenu'   => __( 'Open menu', 'muhamed-ahmed-astran' ),
			'closeMenu'  => __( 'Close menu', 'muhamed-ahmed-astran' ),
		)
	);

	/*
	 * chrome.css is enqueued once, by functions.php, together with the other
	 * design sheets. Enqueueing it here as well loaded it twice and the
	 * second copy arrived with no dependencies, so it could override rules
	 * that were meant to come after it.
	 */
}
add_action( 'wp_enqueue_scripts', 'mah_enqueue_chrome_script', 30 );

/**
 * Add a marker class so CSS can target designed pages.
 *
 * @param array $classes Body classes.
 * @return array
 */
function mah_body_class( $classes ) {
	if ( mah_is_designed_request() ) {
		$classes[] = 'mah-has-chrome';
	}

	return $classes;
}
add_filter( 'body_class', 'mah_body_class' );

/**
 * Remove the title from Astra's page banner.
 *
 * Astra builds the banner from a structure list read from its own option,
 * then loops it printing an element per entry. The hero renders the h1, so the
 * title entry is dropped here, leaving the rest of the banner intact.
 *
 * @param array $structure Element keys, for example array( 'ast-dynamic-single-page-title' ).
 * @return array
 */
function mah_banner_structure( $structure ) {
	if ( ! mah_is_designed_request() ) {
		return $structure;
	}

	return array_values(
		array_filter(
			(array) $structure,
			static function ( $key ) {
				return 'title' !== $key && 'title' !== astra_get_last_meta_word( (string) $key );
			}
		)
	);
}
add_filter( 'astra_banner_elements_structure', 'mah_banner_structure' );

/**
 * Suppress Astra's page title on designed pages.
 *
 * Kept as a second line of defence for older Astra builds that gate the same
 * output behind a filter rather than the structure list.
 *
 * @return void
 */
function mah_hide_astra_title() {
	if ( ! mah_is_designed_request() ) {
		return;
	}

	add_filter( 'astra_show_default_page_title', '__return_false' );
	add_filter( 'astra_get_page_title', '__return_empty_string' );
}
add_action( 'wp', 'mah_hide_astra_title', 30 );

/**
 * Publish the header height as a custom property.
 *
 * Anchors and the fixed header both need it, and CSS cannot measure the bar.
 *
 * @return void
 */
function mah_scroll_offset() {
	echo '<style id="mah-scroll-offset">:root{--mah-header-h:80px}</style>';
}
add_action( 'wp_head', 'mah_scroll_offset', 20 );