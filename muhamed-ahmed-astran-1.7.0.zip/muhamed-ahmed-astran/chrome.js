/**
 * Header behaviour for the designed pages.
 *
 * Progressive enhancement. With JavaScript off the page still works: the
 * mobile panel is hidden via [hidden] and the header is simply transparent
 * until the first scroll event.
 */
( function () {
	'use strict';

	var header = document.querySelector( '[data-mah-header]' );
	if ( ! header ) {
		return;
	}

	/* ---- Scroll scrim -------------------------------------------------
	 * Toggles a single attribute rather than writing inline styles, so the
	 * transition stays in CSS and respects reduced-motion.
	 */

	var ticking = false;

	function onScroll() {
		if ( ticking ) {
			return;
		}

		ticking = true;

		window.requestAnimationFrame( function () {
			var scrolled = window.scrollY > 24;
			if ( scrolled ) {
				header.setAttribute( 'data-scrolled', '' );
			} else {
				header.removeAttribute( 'data-scrolled' );
			}
			ticking = false;
		} );
	}

	window.addEventListener( 'scroll', onScroll, { passive: true } );
	onScroll();

	var reduce = window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches;
	var progress = header.querySelector( '.mah-progress' );
	var progressFill = progress ? progress.querySelector( 'span' ) : null;

	if ( progress && ! reduce ) {
		progress.removeAttribute( 'hidden' );
	}

	function setProgress() {
		if ( ! progressFill || reduce ) {
			return;
		}
		var max = document.documentElement.scrollHeight - window.innerHeight;
		var p = max > 0 ? window.scrollY / max : 0;
		header.style.setProperty( '--mah-scroll-progress', String( p ) );
	}

	window.addEventListener( 'scroll', function () {
		window.requestAnimationFrame( setProgress );
	}, { passive: true } );
	setProgress();

	var THEME_KEY = 'mah-theme';
	var THEME_ORDER = [ 'system', 'light', 'dark' ];
	var i18n = window.mahChromeI18n || {};
	var THEME_LABEL = ( i18n.theme && typeof i18n.theme === 'object' ) ? i18n.theme : {};

	function readTheme() {
		try {
			var stored = window.localStorage.getItem( THEME_KEY );
			if ( stored === 'light' || stored === 'dark' || stored === 'system' ) {
				return stored;
			}
		} catch ( err ) {
			return 'system';
		}
		return 'system';
	}

	function applyTheme( mode ) {
		document.documentElement.setAttribute( 'data-theme', mode );
		try {
			window.localStorage.setItem( THEME_KEY, mode );
		} catch ( err ) {
			/* Storage can be blocked; theme still applies for this document. */
		}
		var buttons = document.querySelectorAll( '[data-mah-theme]' );
		var i;
		for ( i = 0; i < buttons.length; i++ ) {
			var state = buttons[ i ].querySelector( '.mah-theme__state' );
			var label = THEME_LABEL[ mode ] || THEME_LABEL.system || mode;
			var aria = i18n.themeAria ? String( i18n.themeAria ).replace( '%s', label ) : label;
			buttons[ i ].setAttribute( 'aria-label', aria );
			buttons[ i ].setAttribute( 'aria-pressed', mode === 'dark' ? 'true' : 'false' );
			if ( state ) {
				state.textContent = label;
			}
		}
	}

	( function bindTheme() {
		var buttons = document.querySelectorAll( '[data-mah-theme]' );
		var i;
		applyTheme( readTheme() );
		function onClick() {
			var current = readTheme();
			var index = THEME_ORDER.indexOf( current );
			var next = THEME_ORDER[ ( index + 1 ) % THEME_ORDER.length ];
			applyTheme( next );
		}
		for ( i = 0; i < buttons.length; i++ ) {
			buttons[ i ].addEventListener( 'click', onClick );
		}
	}() );

	( function currentSection() {
		if ( ! ( 'IntersectionObserver' in window ) ) {
			return;
		}
		var links = document.querySelectorAll( '[data-mah-nav-target]' );
		if ( ! links.length ) {
			return;
		}
		var map = {};
		var n;
		for ( n = 0; n < links.length; n++ ) {
			var id = links[ n ].getAttribute( 'data-mah-nav-target' );
			if ( id ) {
				map[ id ] = map[ id ] || [];
				map[ id ].push( links[ n ] );
			}
		}
		function setCurrent( id ) {
			var key;
			for ( key in map ) {
				if ( ! Object.prototype.hasOwnProperty.call( map, key ) ) {
					continue;
				}
				var list = map[ key ];
				var j;
				for ( j = 0; j < list.length; j++ ) {
					if ( key === id ) {
						list[ j ].setAttribute( 'aria-current', 'true' );
					} else {
						list[ j ].removeAttribute( 'aria-current' );
					}
				}
			}
		}
		var observer = new IntersectionObserver(
			function ( entries ) {
				var e;
				for ( e = 0; e < entries.length; e++ ) {
					if ( entries[ e ].isIntersecting ) {
						setCurrent( entries[ e ].target.id );
					}
				}
			},
			{ rootMargin: '-40% 0px -50% 0px', threshold: 0 }
		);
		var sectionId;
		for ( sectionId in map ) {
			if ( Object.prototype.hasOwnProperty.call( map, sectionId ) ) {
				var node = document.getElementById( sectionId );
				if ( node ) {
					observer.observe( node );
				}
			}
		}
	}() );

	/* ---- Mobile navigation --------------------------------------------
	 * A button with aria-expanded controlling a panel. Escape closes it and
	 * returns focus, per WAI-ARIA disclosure guidance.
	 */

	var toggle = document.querySelector( '[data-mah-nav-toggle]' );
	var panel = document.querySelector( '[data-mah-nav]' );

	if ( ! toggle || ! panel ) {
		return;
	}

	function focusables() {
		return panel.querySelectorAll( 'a[href], button:not([disabled])' );
	}

	function trap( event ) {
		var nodes, first, last;

		if ( 'Tab' !== event.key || panel.hidden ) {
			return;
		}

		nodes = focusables();

		if ( ! nodes.length ) {
			return;
		}

		first = nodes[ 0 ];
		last = nodes[ nodes.length - 1 ];

		if ( event.shiftKey && event.target === first ) {
			event.preventDefault();
			last.focus();
		} else if ( ! event.shiftKey && event.target === last ) {
			event.preventDefault();
			first.focus();
		}
	}

	function setOpen( open ) {
		var label = open
			? ( toggle.getAttribute( 'data-mah-label-close' ) || i18n.closeMenu || '' )
			: ( toggle.getAttribute( 'data-mah-label-open' ) || i18n.openMenu || '' );
		toggle.setAttribute( 'aria-expanded', open ? 'true' : 'false' );
		toggle.setAttribute( 'aria-label', label );
		panel.hidden = ! open;
		document.body.classList.toggle( 'mah-nav-open', open );

		var sr = toggle.querySelector( '.screen-reader-text' );
		if ( sr ) {
			sr.textContent = label;
		}

		if ( open ) {
			document.addEventListener( 'keydown', trap );
		} else {
			document.removeEventListener( 'keydown', trap );
		}
	}

	setOpen( false );

	toggle.addEventListener( 'click', function () {
		setOpen( toggle.getAttribute( 'aria-expanded' ) !== 'true' );
	} );

	// Any in-page link closes the panel.
	panel.addEventListener( 'click', function ( event ) {
		if ( event.target.closest( 'a' ) ) {
			setOpen( false );
		}
	} );

	document.addEventListener( 'keydown', function ( event ) {
		if ( 'Escape' === event.key && 'true' === toggle.getAttribute( 'aria-expanded' ) ) {
			setOpen( false );
			toggle.focus();
		}
	} );

	// Reset if the viewport grows past the mobile breakpoint.
	var desktop = window.matchMedia( '(min-width: 900px)' );

	function onChange( e ) {
		if ( e.matches ) {
			setOpen( false );
		}
	}

	if ( typeof desktop.addEventListener === 'function' ) {
		desktop.addEventListener( 'change', onChange );
	} else if ( typeof desktop.addListener === 'function' ) {
		desktop.addListener( onChange );
	}
} )();