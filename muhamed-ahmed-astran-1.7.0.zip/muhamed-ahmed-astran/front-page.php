<?php
/**
 * Front page. Renders the panel home layout when the function exists.
 *
 * @package MuhamedAhmed_Astran
 */

defined( 'ABSPATH' ) || exit;

get_header();

if ( function_exists( 'muhamedahmed_render_home' ) ) {
	$GLOBALS['mah_home_rendered'] = true;
	echo muhamedahmed_render_home(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- renderer escapes.
} elseif ( have_posts() ) {
	while ( have_posts() ) {
		the_post();
		the_content();
	}
}

get_footer();
