<?php
/**
 * Front-end font loading.
 *
 * theme.json can only reference a font family. WordPress does not emit a
 * @font-face or a Google Fonts request from theme.json alone, so the two
 * display faces the design depends on were silently falling back to the
 * parent's Open Sans. This loads them explicitly and preconnects so they do
 * not block paint.
 *
 * @return void
 */
add_action(
	'wp_enqueue_scripts',
	static function () {
		$uri = MUHAMEDAHMED_ASTRAN_URI;

		// Preconnect before the request is issued.
		add_filter(
			'wp_resource_hints',
			static function ( $urls, $relation ) {
				if ( 'preconnect' === $relation ) {
					$urls[] = array( 'href' => 'https://fonts.googleapis.com' );
					$urls[] = array( 'href' => 'https://fonts.gstatic.com', 'crossorigin' );
				}

				return $urls;
			},
			10,
			2
		);

		/*
		 * The design needs a heavy display face for headings and a neutral
		 * text face for body. Both are SIL Open Font License 1.1.
		 */
		wp_enqueue_style(
			'muhamed-ahmed-fonts',
			'https://fonts.googleapis.com/css2?family=K2D:wght@500;700&family=Inter:wght@400;500;600;700&display=swap',
			array(),
			null // Let Google cache-bust; the query string already carries the versions.
		);

		wp_style_add_data( 'muhamed-ahmed-fonts', 'preload', true );

		/*
		 * Astra's own font stack fights the design. Both K2D and Inter are
		 * loaded above, so declare them on body and headings.
		 */
		$css = <<<'CSS'
/* Load the faces theme.json references. */
body,
.editor-styles-wrapper {
	font-family: "Inter", system-ui, -apple-system, "Segoe UI", sans-serif;
}

/*
 * Astra sets a grey on bare h1 with a type-scale rule. The designed pages
 * need the accent colour and the display face, and this has to out-specify
 * both the parent stylesheet and the entry-title rule.
 */
.muhamedahmed-root h1,
.muhamedahmed-root h2,
.muhamedahmed-root h3,
.is-muhamedahmed-page h1,
.is-muhamedahmed-page h2,
.is-muhamedahmed-page h3,
body .wp-block-heading {
	font-family: "K2D", "Arial Black", system-ui, sans-serif;
}

.is-muhamedahmed-page .entry-title {
	display: none;
}

.muhamedahmed-root h1,
.is-muhamedahmed-page h1.wp-block-heading {
	color: #81ff28;
}

/*
 * Stop words breaking mid-word. Astra's global rule allows breaks anywhere,
 * which is what produced "WordPres s developmen t" in the services grid.
 */
.muhamedahmed-root :is(h1, h2, h3, h4, p, li, span, a, strong) {
	overflow-wrap: break-word;
	word-break: normal;
	hyphens: manual;
}

html[lang^="ar"] body,
html[lang^="ar"] .editor-styles-wrapper,
html[lang^="ar"] .muhamedahmed-root h1,
html[lang^="ar"] .muhamedahmed-root h2,
html[lang^="ar"] .muhamedahmed-root h3,
html[lang^="ar"] .is-muhamedahmed-page h1,
html[lang^="ar"] .is-muhamedahmed-page h2,
html[lang^="ar"] .is-muhamedahmed-page h3,
html[lang^="ar"] body .wp-block-heading {
	font-family: "IBM Plex Sans Arabic", "Noto Naskh Arabic", "Noto Sans Arabic", "Segoe UI", Tahoma, sans-serif;
	letter-spacing: 0;
}

/*
 * Columns sized with flex-basis in percent overflowed once padding and gap
 * were added, forcing the browser to crush the text. Capping the basis lets
 * flex shrink properly instead.
 */
.muhamedahmed-root .wp-block-columns {
	align-items: stretch;
}

.muhamedahmed-root .wp-block-column {
	min-inline-size: 0;
}
CSS;

		/*
		 * style.css is loaded by theme.json, so the handle is
		 * "muhamed-ahmed-astran" via the stylesheet path. Attach the
		 * corrections to that instead of a handle registered here.
		 */
		wp_add_inline_style( 'muhamed-ahmed-astran', $css );

		unset( $uri );
	},
	20
);