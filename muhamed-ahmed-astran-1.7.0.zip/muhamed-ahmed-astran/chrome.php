<?php
/**
 * Chrome bridge.
 *
 * The header and footer markup now lives in the Content plugin, because it is
 * built from stored values. This file only decides when to swap Astra's chrome
 * for the plugin's, and what to show in the editor.
 *
 * @package MuhamedAhmed_Astran
 */

defined( 'ABSPATH' ) || exit;

/**
 * Use the plugin's header and footer on designed pages.
 *
 * Returns without doing anything if the plugin is absent, so the theme still
 * works if it is deactivated: Astra's own header and footer remain in place.
 *
 * @return void
 */
function mah_replace_chrome() {
	if ( ! muhamedahmed_astran_is_designed_page() ) {
		return;
	}

	if ( ! function_exists( 'mah_content_header' ) ) {
		return;
	}

	remove_all_actions( 'astra_header' );
	remove_all_actions( 'astra_footer' );
	remove_all_actions( 'astra_footer_bottom' );

	add_action( 'astra_header', 'mah_content_header', 5 );
	add_action( 'astra_footer', 'mah_content_footer', 5 );
}
add_action( 'wp', 'mah_replace_chrome', 20 );

/**
 * Show the designed header and footer inside the editor.
 *
 * Without this the editor canvas shows Astra's chrome, which is not what the
 * visitor sees, and it makes the editor disagree with the front end.
 *
 * @param string $context The editor context.
 * @return string
 */
add_filter(
	'block_editor_settings_all',
	static function ( $settings ) {
		$post = get_post();

		if ( $post && muhamedahmed_astran_is_designed_page() ) {
			$settings['mah_designed_page'] = true;
		}

		return $settings;
	},
	10,
	1
);

/**
 * Register the editor stylesheet so the canvas matches the front end.
 *
 * @return void
 */
add_action(
	'enqueue_block_editor_assets',
	static function () {
		$post = get_post();

		if ( ! $post || ! muhamedahmed_astran_is_designed_page() ) {
			return;
		}

		wp_enqueue_style(
			'mah-editor-preview',
			MUHAMEDAHMED_ASTRAN_URI . '/editor.css',
			array(),
			MUHAMEDAHMED_ASTRAN_VERSION
		);
	}
);